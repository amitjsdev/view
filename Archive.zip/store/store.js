import { createStore, applyMiddleware, combineReducers, compose } from "redux";

import authReducer from "./reducers/authReducer";
import thunk from "redux-thunk";

import { setCurrentUser } from "./actions/authActions";
import jwt from "jwt-decode";

const composeEnhancers = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose;

const rootReducer = combineReducers({
  auth: authReducer,
});

const store = createStore(
  rootReducer,
  composeEnhancers(applyMiddleware(thunk))
);

// setAuthToken(store);

if (localStorage.token) {
  store.dispatch(setCurrentUser(jwt(localStorage.token)));
}

export default store;
