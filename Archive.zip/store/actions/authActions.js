import APIUtil from "../../api";
import * as actionTypes from "./actionTypes";
import { toast } from "react-toastify";
import jwt_decode from "jwt-decode";
import history from "../helpers/history";

const api = new APIUtil();

export const authStart = () => {
  return {
    type: actionTypes.AUTH_START,
  };
};

export const authSuccess = (token) => {
  return {
    type: actionTypes.AUTH_SUCCESS,
    token: token,
  };
};

export const authFail = (error) => {
  return {
    type: actionTypes.AUTH_FAIL,
    error: error,
  };
};

export const logout = () => {
  return {
    type: actionTypes.AUTH_LOGOUT,
  };
};

export const auth = (form) => {
  return (dispatch) => {
    dispatch(authStart());
    api
      .post("users/login", form)
      .then((response) => {
        localStorage.setItem("token", response.data.data);
        const user = jwt_decode(response.data.data);
        dispatch(authSuccess(response.data.data), user);
        dispatch(setCurrentUser(user));
      })
      .catch((err) => {
        toast.error(err.response.data.message);
        dispatch(authFail(err.response));
      });
  };
};

export const authCheckState = () => {
  return (dispatch) => {
    const token = localStorage.getItem("token");
    if (!token) {
      dispatch(logout());
    } else {
      const user = jwt_decode(token);
      const currentTime = Date.now() / 1000;
      if (user.exp < currentTime) {
        toast.error("Token expired, please log in again!");
        // Logout user
        dispatch(logout());
      } else {
        dispatch(authSuccess(token));
        dispatch(setCurrentUser(user));
      }
    }
  };
};

export const setCurrentUser = (user) => {
  return {
    type: actionTypes.SET_CURRENT_USER,
    user,
  };
};

export const createForm = (form) => {
  return (dispatch) => {
    api
      .post("users/register", form)
      .then((response) => {
        toast.success("You have SucessFul Registred");
        history.push("/login");
      })
      .catch((err) => {
        toast.error(err.response.data.message);
        if (err === "Error: Request failed with status code 500") {
          toast.error(" Your Email is Already Exist !!");
        }
      });
  };
};
