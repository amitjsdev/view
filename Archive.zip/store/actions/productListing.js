import APIUtil from "../../api";
import * as actionTypes from "./actionTypes";

const api = new APIUtil();

export const fetchStart = () => {
  return {
    type: actionTypes.FETCH_PRODUCT_LIST,
  };
};

export const fetchSuccess = () => {
  return {
    type: actionTypes.FETCH_PRODUCT_SUCCESS,
  };
};
