import APIUtil from "../../../api";

const api = new APIUtil();

export const fetchMinMaxApi = () => {
  return api.get("engagementrings/minMaxPrice").then((res) => res.data.data);
};

// export const ringFilter = (values) => {
//   values.map((val,i) => {

//   })
//   return api.get(`engagementrings/filter`);
// };
