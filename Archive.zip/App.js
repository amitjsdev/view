import React from "react";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { Router, Route, Switch, Redirect } from "react-router-dom";
import "./App.css";
import GlobalStyle from "./css/global";
import History from "./store/helpers/history";
import "react-responsive-carousel/lib/styles/carousel.min.css";
import ScrollToTop from "./common/ScrollToTop";

const loading = () => (
  <div className="animated fadeIn pt-3 text-center">
    <div className="sk-spinner sk-spinner-pulse"></div>
  </div>
);

// Pages
const Layout = React.lazy(() => import("./hoc"));

function App() {
  const routes = (
    <Switch>
      <Route path="/" render={(props) => <Layout {...props} />} />
      <Redirect to="/" />
    </Switch>
  );

  return (
    <>
      <ToastContainer position="top-center" autoClose={5000} />
      <GlobalStyle />
      <Router history={History}>
        <ScrollToTop />
        <React.Suspense fallback={loading()}>{routes}</React.Suspense>
      </Router>
    </>
  );
}

export default App;
