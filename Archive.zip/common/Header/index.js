import React, { useContext, useEffect, useState } from "react";
import {
  Nav,
  NavItem,
  NavLink,
  Dropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
  Container,
} from "reactstrap";
import { CartContext } from "../../context/CartContext";
import { Tooltip } from "@material-ui/core";
import * as actions from "../../store/actions";
import { connect } from "react-redux";
import { motion } from "framer-motion";
import { Authentication, UserDetails } from "../../constant";
import { Link, useHistory, withRouter } from "react-router-dom";

// images
import MainLogo from "../../assets/images/rlogo.png";
import { ReactComponent as Call } from "../../assets/images/call.svg";
import { ReactComponent as Chat } from "../../assets/images/chat.svg";
import { ReactComponent as Dollar } from "../../assets/images/dollar.svg";
import { ReactComponent as Search } from "../../assets/images/search.svg";
import { ReactComponent as User } from "../../assets/images/user.svg";
import { ReactComponent as Wishlist } from "../../assets/images/wishlist.svg";
import { ReactComponent as Cart } from "../../assets/images/cart.svg";

// css
import { Header } from "../../css/header";

const MainHeader = (props) => {
  const { cartItems, wishLists, wishProduct, addProduct } = useContext(
    CartContext
  );
  const history = useHistory();
  const toggle = () => setDropdownOpen((prevState) => !prevState);
  const toggleOne = () => setDropdownOpenOne((prevState) => !prevState);
  const toggleTwo = () => setDropdownOpenTwo((prevState) => !prevState);
  const toggle3 = () => setDropdownOpenThree((prevState) => !prevState);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [dropdownOpenOne, setDropdownOpenOne] = useState(false);
  const [dropdownOpenTwo, setDropdownOpenTwo] = useState(false);
  const [dropdownOpenThree, setDropdownOpenThree] = useState(false);

  const [myLoad, setMyLoad] = useState(false);

  var userId = UserDetails();
  var isAuth = Authentication();

  const Logout = () => {
    props.onLogout();
    localStorage.removeItem("token");
    setMyLoad(!myLoad);
    history.push("/");
    window.location.reload();
  };

  const cartHandle = () => {
    isAuth && history.push("/addtocart");
  };

  const wishHandle = () => {
    isAuth && history.push("/wishcart");
  };

  useEffect(() => {
    isAuth && userId && userId._id &&
      addProduct(userId._id.toString(), wishProduct(userId._id.toString()));
  }, [myLoad, isAuth]);

  return (
    <Header>
      <motion.div className="mainHead">
        <Container>
          <div className="top-header d-flex justify-content-between align-items-center">
            <div className="left">
              <Link to="/">
                <img src={`${MainLogo}`} alt="" />
              </Link>
            </div>

            <div className="right">
              <ul className="list d-flex align-items-center">
                <li>
                  <Call width="17px" height="17px" />
                  <i className="fa fa-phone" aria-hidden="true"></i>{" "}
                  <a href="tel:+1-800-242-2728">+1-800-242-2728</a>
                </li>
                <li>
                  <Chat width="16px" height="15px" />
                  Live Chat
                </li>
                <li>
                  <Dropdown isOpen={dropdownOpen} toggle={toggle}>
                    <DropdownToggle caret>
                      <Dollar width="18px" height="18px" /> USD
                    </DropdownToggle>
                    <DropdownMenu>
                      <DropdownItem>CA</DropdownItem>
                      <DropdownItem>Euro</DropdownItem>
                    </DropdownMenu>
                  </Dropdown>
                </li>
                <li>
                  <User width="20px" height="20px" />{" "}
                </li>
                <li style={{ marginLeft: "0px", padding: "0px" }}>
                  {!isAuth ? (
                    <Link to="/login">Login</Link>
                  ) : (
                    <>
                      <Dropdown isOpen={dropdownOpenThree} toggle={toggle3}>
                        <DropdownToggle nav caret>
                          {userId.first_name}
                        </DropdownToggle>
                        <DropdownMenu>
                          <DropdownItem>
                            {" "}
                            <Link to="/account">My Profile </Link>{" "}
                          </DropdownItem>
                          <DropdownItem><Link to="/Orders">Orders </Link>{" "}  </DropdownItem>
                          <DropdownItem> Wishlist </DropdownItem>
                          <DropdownItem> Returns </DropdownItem>

                          <DropdownItem onClick={Logout}> Logout</DropdownItem>
                        </DropdownMenu>
                      </Dropdown>
                    </>
                  )}
                </li>
                <li className="cursor" onClick={wishHandle}>
                  <Tooltip title={isAuth ? "" : "Login First "}>
                    <div>
                      <Wishlist width="20px" height="24px" />
                      <button className="count"> {wishLists.length}</button>
                    </div>
                  </Tooltip>
                </li>
                <li className="cursor" onClick={cartHandle}>
                  <Tooltip title={isAuth ? "" : "Login First "}>
                    <div>
                      <Cart width="24px" height="22px" />
                      <button className="count">{cartItems.length} </button>
                    </div>
                  </Tooltip>
                </li>
              </ul>
            </div>
          </div>
        </Container>
        <div className="bottomHeader">
          <Container>
            <div className="left d-flex align-items-center justify-content-between">
              <Nav pills>
                <NavItem>
                  <NavLink href="/engagement-rings" active>
                    Engagement Rings
                  </NavLink>
                </NavItem>
                <NavItem>
                  <NavLink href="/">Wedding Rings</NavLink>
                </NavItem>

                <NavItem>
                  <Dropdown isOpen={dropdownOpenTwo} toggle={toggleTwo}>
                    <DropdownToggle caret>Diamonds</DropdownToggle>
                    <DropdownMenu>
                      <DropdownItem>
                        {" "}
                        <Link to="/diamonds"> Diamonds </Link>
                      </DropdownItem>
                      <DropdownItem>
                        {" "}
                        <Link to="/diamond-search">
                          {" "}
                          Shop diamonds by Shape{" "}
                        </Link>
                      </DropdownItem>
                    </DropdownMenu>
                  </Dropdown>
                </NavItem>
                <NavItem>
                  <Dropdown isOpen={dropdownOpenOne} toggle={toggleOne}>
                    <DropdownToggle caret>Fine Jewellery</DropdownToggle>
                    <DropdownMenu>
                      <DropdownItem>
                        {" "}
                        <Link to="/earring"> Diamond Studs </Link>
                      </DropdownItem>
                      <DropdownItem>
                        {" "}
                        <Link to="/hoops"> Hoops </Link>
                      </DropdownItem>
                      <DropdownItem>
                        <Link to="/drops/listing"> Drops </Link>
                      </DropdownItem>
                      <DropdownItem>
                        <Link to="/fashion/listing"> Fashion earrings </Link>
                      </DropdownItem>
                    </DropdownMenu>
                  </Dropdown>
                </NavItem>
                <NavItem>
                  <NavLink href="/">Education</NavLink>
                </NavItem>
                <NavItem>
                  <NavLink href="/">Gifts</NavLink>
                </NavItem>
              </Nav>
              <div className="search">
                <input type="search" placeholder="I Dream of..." />
                <Search width="44px" height="42px" />
              </div>
            </div>
          </Container>
        </div>
      </motion.div>
    </Header>
  );
};

const mapDispatchToProps = (dispatch) => {
  return {
    onLogout: () => dispatch(actions.logout()),
  };
};

export default withRouter(connect(null, mapDispatchToProps)(MainHeader));
