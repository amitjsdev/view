import React from "react";
import { Container, Row, Col } from "reactstrap";
import {FooterWrap} from '../../css/footer';

export default function Footer() {
  return (
    <FooterWrap>
      <footer>
        <Container>
          <Row>
            <Col md={3}>
              <h2>About Diamonds</h2>
              <ul className="list">
              <li><a href="javascript:void(0)">Contact us</a></li>
                <li><a href="javascript:void(0)">FAQ</a></li>
                <li><a href="javascript:void(0)">Testimonials</a></li>
                <li><a href="javascript:void(0)">Press</a></li>
                <li><a href="javascript:void(0)">Become an Affiliate</a></li>
                <li><a href="javascript:void(0)">Order Status</a></li>
                <li><a href="javascript:void(0)">Return</a></li>
                <li><a href="javascript:void(0)">Give us your Feedback</a></li>
              </ul>
            </Col>
            <Col md={3}>
              <h2>Why Radix</h2>
              <ul className="list">
                <li><a href="javascript:void(0)">Contact us</a></li>
                <li><a href="javascript:void(0)">FAQ</a></li>
                <li><a href="javascript:void(0)">Testimonials</a></li>
                <li><a href="javascript:void(0)">Press</a></li>
                <li><a href="javascript:void(0)">Become an Affiliate</a></li>
                <li><a href="javascript:void(0)">Order Status</a></li>
                <li><a href="javascript:void(0)">Return</a></li>
                <li><a href="javascript:void(0)">Give us your Feedback</a></li>
              </ul>
            </Col>

            <Col md={3}>
              <h2>About Radix</h2>
              <ul className="list">
                <li><a href="javascript:void(0)">Contact us</a></li>
                <li><a href="javascript:void(0)">FAQ</a></li>
                <li><a href="javascript:void(0)">Testimonials</a></li>
                <li><a href="javascript:void(0)">Press</a></li>
                <li><a href="javascript:void(0)">Become an Affiliate</a></li>
                <li><a href="javascript:void(0)">Order Status</a></li>
                <li><a href="javascript:void(0)">Return</a></li>
                <li><a href="javascript:void(0)">Give us your Feedback</a></li>
              </ul>
            </Col>
            <Col md={3}>
              <h2>Guides & Education</h2>
              <ul className="list">
                <li><a href="javascript:void(0)">Contact us</a></li>
                <li><a href="javascript:void(0)">FAQ</a></li>
                <li><a href="javascript:void(0)">Testimonials</a></li>
                <li><a href="javascript:void(0)">Press</a></li>
                <li><a href="javascript:void(0)">Become an Affiliate</a></li>
                <li><a href="javascript:void(0)">Order Status</a></li>
                <li><a href="javascript:void(0)">Return</a></li>
                <li><a href="javascript:void(0)">Give us your Feedback</a></li>
              </ul>
            </Col>
          </Row>
        </Container>
      </footer>

      <div className="copyRight">
        <p>Copyright</p>
      </div>
    </FooterWrap>
  );
}
