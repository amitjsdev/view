import styled from "styled-components";

import Filterimg from "../assets/images/hoops/landing/filters-sprite.png";
import Arrowimg from "../assets/images/hoops/landing/btm-arrow.png";

export const Filters = styled.div`
  .metalFilter {
    height: 100%;
    .dropdown-menu {
      padding: 10px;
    }
    .list {
      li {
        display: flex;
        justify-content: space-between;
        margin: 0 0 10px;
        label {
          margin: 0;
        }
        .boxes {
          display: flex;
          li {
            margin: 0;
          }
        }
      }
    }
  }
  .card {
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
    transition: 0.3s;
    width: 40%;
  }
  .container {
    padding: 2px 16px;
  }
  .filterSection {
    margin-left: 0;
    & > h4 {
      font-family: var(--prist-font);
      color: var(--primary);
      font-size: 28px;
      span {
        font-size: 80px;
      }
    }
    .filter-paragraph {
      color: #707070;
      font-family: var(--sort-font);
      font-size: 26px;
      line-height: 50px;
      h4,
      h2 {
        padding: 0 50px 0 10px;
        position: relative;
        cursor: pointer;
        font-family: var(--dance-font);
        color: var(--primary);
        margin: 0;
        font-size: 28px;
        &:after {
          content: "";
          position: absolute;
          right: 10px;
          top: 10px;
          background: url(${Arrowimg}) no-repeat;
          width: 20px;
          height: 12px;
          background-size: cover;
          pointer-events: none;
        }
      }
      .dropdown {
        border-bottom: 1px solid #c1c1c1;
        .dropdown-menu {
          left: 50%;
          transform: translateX(-50%);
          -webkit-transform: translateX(-50%);
          -moz-transform: translateX(-50%);
          -ms-transform: translateX(-50%);
          padding: 20px;
          width: 300px;
          border: 0;
          border-radius: 0;
          box-shadow: 0px 0px 10px 1px #f5f5f5;
          .form-group {
            margin: 0 20px;
            width: 100%;
            position: relative;
            label {
              position: absolute;
              top: 0;
              bottom: 0;
              margin: auto 0;
              height: 100%;
              display: flex;
              align-items: center;
              justify-content: center;
              left: 10px;
              font-size: 12px;
              font-weight: 700;
            }
          }
        }
        &.price_dwn {
          .input-range__track {
            height: 3px;
            position: relative;

            &:before,
            &:after {
              content: "";
              border-radius: 50%;
              background: #cbcbcb;
              width: 7px;
              height: 7px;
              position: absolute;
              left: 0;
              top: -2px;
            }
            &:after {
              left: auto;
              right: 0;
            }
            .input-range__slider {
              z-index: 1;
            }
          }

          .list {
            margin: 20px 0 0 0;
            li {
              .d-flex {
                margin: 0 -20px;

                input[type="number"] {
                  border: 1px solid var(--primary);
                  border-radius: 0;
                  box-shadow: none;
                  padding: 4px 10px;
                  line-height: 1;
                  height: auto;
                  text-align: right;
                  font-size: 14px;
                  color: #000;
                  margin: 0;
                }
              }
            }
          }
        }

        &.metalFilter {
          .list {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            li {
              display: flex;
              flex-direction: column-reverse;
              justify-content: flex-end;

              align-items: center;
              &.Platinum {
                display: none;
              }

              &:last-child {
                margin: 0;
                & > label {
                  display: flex;
                }
              }
              & > label {
                width: 100%;
                line-height: normal;
                position: relative;
                padding: 0 0 0 25px;
                display: none;
                span {
                  position: absolute;
                  left: 0;
                  top: 0;
                  width: 18px;
                  height: 18px;
                  border: 1px solid #000;
                  cursor: pointer;
                }
                input[type="checkbox"] {
                  width: 18px;
                  height: 18px;
                  position: absolute;
                  left: 0;
                  top: 0;
                  appearance: none;
                  -webkit-appearance: none;
                  -moz-appearance: none;
                  -ms-appearance: none;

                  &:checked ~ span:after {
                    content: "";
                    background: #000;
                    width: 12px;
                    height: 12px;
                    position: absolute;
                    left: 2px;
                    top: 2px;
                  }
                }
              }
              ul {
                display: flex;
                grid-gap: 15px;
                li {
                  width: 50%;
                  line-height: normal;

                  label {
                    font-size: 0;
                    position: relative;
                    width: 30px;
                    height: 30px;
                    float: left;
                    padding: 0;
                    display: block;
                    span {
                      position: absolute;
                      left: 0;
                      top: 0;
                      width: 100%;
                      height: 100%;
                      background: url(${Filterimg}) no-repeat;
                      border: 0;

                      &:before {
                        content: "";
                        width: calc(100% + 4px);
                        height: calc(100% + 4px);
                        left: -2px;
                        top: -2px;
                        border: 2px solid transparent;
                        position: absolute;
                        border-radius: 50%;
                      }
                      &:after {
                        display: none;
                      }
                    }
                    input[type="checkbox"] {
                      position: absolute;
                      left: 0;
                      top: 0;
                      width: 100%;
                      height: 100%;
                      appearance: none;
                      -webkit-appearance: none;
                      -moz-appearance: none;
                      -ms-appearance: none;
                      cursor: pointer;
                      z-index: 1;
                      &:checked ~ span:before {
                        border-color: var(--primary);
                      }
                    }
                  }
                  &.Rose span {
                    background-position: -10px -0px;
                  }
                  &.Rose[value="18"] span {
                    background-position: -50px -0px;
                  }
                  &.White span {
                    background-position: -10px -40px;
                  }
                  &.White[value="18"] span {
                    background-position: -50px -40px;
                  }
                  &.Yellow span {
                    background-position: -10px -80px;
                  }
                  &.Yellow[value="18"] span {
                    background-position: -50px -80px;
                  }
                  &.Platinum span {
                    background-position: -10px -120px;
                  }
                }
              }
            }
          }
        }
      }
    }
  }

  .d-md-flex {
    display: block !important;
    padding: 0 10px;
    width: 26%;
    .examples {
      .multiselect-container {
        width: auto;
      }
      .search-wrapper {
        border: 0;
        border-radius: 0;
        min-height: 1px;
        line-height: normal;
        padding: 0 50px 0 10px;
        position: relative;
        border-bottom: 1px solid #c1c1c1;
        &:after {
          content: "";
          position: absolute;
          right: 10px;
          top: 10px;
          background: url(${Arrowimg}) no-repeat;
          width: 20px;
          height: 12px;
          background-size: cover;
          cursor: pointer;
        }
        .searchBox {
          margin: 0;
          padding: 0;
          font-family: var(--dance-font);
          color: var(--primary);
          font-size: 28px;

          &::-webkit-input-placeholder {
            /* Chrome/Opera/Safari */
            color: var(--primary);
          }
          &::-moz-placeholder {
            /* Firefox 19+ */
            color: var(--primary);
          }
          &:-ms-input-placeholder {
            /* IE 10+ */
            color: var(--primary);
          }
          &:-moz-placeholder {
            /* Firefox 18- */
            color: var(--primary);
          }
        }
      }
      .optionListContainer {
        border-radius: 0;
        box-shadow: 0px 0px 10px 1px #f5f5f5;
        left: 50%;
        -webkit-transform: translateX(-50%);
        -ms-transform: translateX(-50%);
        transform: translateX(-50%);
        -webkit-transform: translateX(-50%);
        -moz-transform: translateX(-50%);
        -ms-transform: translateX(-50%);
        width: 300px;
        .optionContainer {
          border: 0;
          border-radius: 0;
          padding: 10px 15px;
          li {
            background: transparent;
            padding: 0;
            line-height: normal;
            color: #000;
            font-size: 16px;
            margin: 5px 0;
            input[type="checkbox"] {
              cursor: pointer;
            }
          }
        }
      }
    }
  }
`;
