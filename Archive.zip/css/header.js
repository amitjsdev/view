import styled from "styled-components";
export const Header = styled.div`
  .mainHead {
    position: relative;
    z-index: 9;
    width: 100%;
  }
  .top-header {
    position: relative;

    .right {
      position: relative;
      z-index: 9;
      display: flex;
      justify-content: flex-end;
      align-items: self-start;
      flex: 1;
      .dropdown {
        button {
          background: none;
          border: none;
          color: #000;
          padding: 0;
        }
      }
      .list {
        li {
          margin-left: 15px;
          position: relative;
          display: flex;
          align-items: baseline;
          &.cursor {
            cursor: pointer;
          }
          a {
            color: #000;
          }
          svg {
            margin-right: 5px;
          }
          button.count {
            border: 1px solid #cb9274;
            background: #fff;
            font-size: 10px;
            border-radius: 50px;
            position: absolute;
            top: -4px;
            left: -7px;
            padding: 0px;
            width: 15px;
            height: 15px;
          }
          svg {
            path {
              fill: var(--primary);
            }
          }
        }
      }
    }

    .left {
      position: relative;
      z-index: 9;

      img {
        width: 120px;
        height: auto;
      }
    }
  }
  .bottomHeader {
    position: sticky;
    top: 0;
    flex: 1;
    display: flex;
    justify-content: space-between;
    width: 100%;
    background: #fff;
    margin: 0 auto;
    padding: 10px 0;

    .left {
      .nav {
        flex: 1;
        justify-content: space-around;
        .nav-item {
          padding: 0 15px;
          a,
          .dropdown button {
            background: none;
            color: #000;
            font-weight: 500;
            font-size: 14px;
            border: none;
            padding: 0;
            position: relative;
            cursor: pointer;
            text-transform: uppercase;
          }
          &:first-child {
            padding-left: 0;
          }
        }
      }
    }
    .search {
      border: 1px solid var(--primary);
      position: relative;
      border-radius: 10px;
      input {
        border: none;
        color: #000;
        font-size: 14px;
        padding: 0 10px;
        background: none;
        outline: none;
      }
      svg {
        cursor: pointer;
      }
    }
  }
  .dropdown {
    button {
      outline: none !important;
      box-shadow: none !important;
    }
  }
  .dropdown-menu.show {
    padding: 10px 20px;
    button {
      padding: 5px 0 !important;
    }
  }

  /*****************media queries*********/

  @media (max-width: 1024px) {
    .container {
      max-width: 100%;
    }
    .bottomHeader {
      .left {
        .nav {
          .nav-item {
            padding: 0 10px;
          }
        }
      }
    }
  }

  @media (max-width: 767px) {
    .topbar,
    .bottomHeader {
      display: none;
    }
    .top-header {
      .right {
        .list {
          li {
            display: none;
            &.cursor {
              display: inline-block;
            }
          }
        }
      }
    }
  }
`;