import styled from "styled-components";
import GalleryBg from "../assets/images/engagementRing/gallerybg.png";

export const RingWrap = styled.div`
  .ring-style {
    padding: 0 0 80px;
    .style-list {
      .list {
        display: grid;
        grid-template-columns: 1fr 1fr 1fr 1fr;
        grid-gap: 40px;
        li {
          cursor: pointer;
          display: flex;
          align-items: center;
          background: rgba(203, 146, 116, 0.15);
          padding: 12px 0 10px;
          border-left: 30px solid #f6f4f2;
          span {
            width: 120px;
            margin-left: -50px;
          }
          h4 {
            margin: 0;
            color: var(--primary);
            font-size: 20px;
            padding-left: 20px;
          }
        }
      }
    }
  }
  .metal-type {
    padding: 0 0 80px;
    h2 {
      color: var(--primary);
      position: relative;
      margin-right: 40px;
      &:after {
        content: "";
        position: absolute;
        bottom: 0;
        width: 100%;
        background: #fff;
        height: 15px;
        left: 0;
        z-index: -1;
      }
    }
  }

  .ring-by {
    padding: 100px 0;
    .gallery-selection {
      position: relative;
      .white-stripe {
        background: #fff;
        height: 60px;
        width: 100%;
        display: inline-block;
        position: absolute;
        z-index: -1;
        &:before {
          content: "";
          border-left: 9999px solid #fff;
          position: absolute;
          left: -9999px;
          height: 100%;
          top: 0;
        }
        &:before {
          content: "";
          border-right: 9999px solid #fff;
          position: absolute;
          right: 9999px;
          height: 100%;
          top: 0;
        }
      }
      .list {
        display: flex;
        li {
          text-align: center;
          cursor: pointer;
          span {
            width: 180px;
            display: inline-block;
            padding: 0 0 10px;
          }
          p {
            font-style: italic;
            font-size: 14px;
            font-weight: 500;
            color: #000;
            width: 80%;
            display: inline-block;
          }
        }
      }
    }
  }

  .engagement-story {
    padding: 100px 0;
    text-align: center;

    h2 {
      color: var(--primary);
      font-size: 30px;
      font-weight: 600;
    }
    p {
      color: #707070;
      font-size: 14px;
      width: 80%;
      display: inline-block;
    }
    .gallery {
      padding: 50px 0;
      ul {
        li {
          position: relative;
          cursor: pointer;
          .overlay {
            position: absolute;
            top: 0;
            bottom: 0;
            right: 0;
            left: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            h4 {
              background: url(${GalleryBg}) no-repeat scroll 0 0 / 100% 100%;
              margin: 0;
              padding: 10px 40px;
            }
          }
        }
      }
    }
  }
`;
