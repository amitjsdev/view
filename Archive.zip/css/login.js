import styled from "styled-components";
import Email from "../assets/images/email.svg";
import Lock from "../assets/images/padlock.svg";

export const LoginWrap = styled.div`
  .form {
    position: relative;
    padding: 0;

    &:before {
      content: "";
      border-left: 9999px solid rgba(203, 146, 116, 0.22);
      position: absolute;
      top: 0;
      right: 40%;
      z-index: -1;
      bottom: 0;
      height: 100%;
    }

    .formWrap {
      background: #fff;
      padding: 68px 90px;
      margin: 40px 0;
      box-shadow: 8px 8px 6px rgb(0 0 0 / 16%);
      height: 90%;
    }

    h2 {
      font-family: var(--sort-font);
      margin: 0 0 20px;
      font-size: 35px;
    }

    form {
      padding: 0 0 50px;

      ul.list {
        li {
          margin-left: 30px;

          svg {
            width: 50px;
            cursor: pointer;

            path {
              fill: var(--primary);
            }
          }
        }
      }
    }

    p {
      font-size: 20px;
      padding: 0 0 50px;
    }

    h6 {
      color: #8a8a8a;
      font-size: 17px;
    }

    .form-group {
      position: relative;

      svg {
        position: absolute;
      }
      &.email {
        .icon {
          background: url(${Email}) no-repeat;
        }
      }
      &.pass {
        .icon {
          background: url(${Lock}) no-repeat;
        }
      }
      .icon {
        height: 26px;
        position: absolute;
        left: 0;
        width: 23px;
        top: 34px;
      }

      input {
        width: 100%;
        border: none;
        padding: 0 10px 8px 30px;
        box-shadow: none;
        font-size: 15px;
        border-radius: 0;
        outline: none;
        border-bottom: 1px solid var(--primary);
      }

      &.forget {
        color: #000;
        font-size: 14px;
        font-weight: 500;
        background: none;
        border: none;
        box-shadow: none;
        padding: 0;
        text-align: right;
        cursor: pointer;
      }
    }

    &.register {
      label {
        font-size: 18px;
        color: #8a8a8a;
        align-items: center;
        position: relative;
        span {
          color: #e80303;
        }
        input {
          width: 100%;
          height: 100%;
          opacity: 0;
          position: absolute;

          & + span {
            border: 1px solid #919191;
            width: 20px;
            height: 20px;
            border-radius: 50%;
            position: relative;
            margin-right: 5px;
            display: flex;
            align-items: center;
            justify-content: center;
            &:before {
              content: "";
              border: 1px solid #919191;
              border-radius: 50px;
              width: 10px;
              height: 10px;
              background: #fff;
            }
          }
          &:checked {
            & + span {
              &:before {
                content: "";
                border: 5px solid #051f34;
                border-radius: 50px;
              }
            }
          }
        }
      }
    }
  }

  .benefits {
    margin: 40px 0 0;
    h2 {
      color: var(--primary);
      position: relative;
      line-height: 110px;
      font-family: var(--sort-font);
      font-size: 36px;
      padding-left: 60px;
      &:after {
        content: "Benefits";
        position: absolute;
        left: 0;
        color: rgba(0, 0, 0, 0.04);
        top: 0;
        font-size: 97px;
      }
    }
    li {
      display: flex;
      align-items: center;
      color: #000;
      font-size: 19px;
      margin: 0 0 35px;

      svg {
        background: #fff;
        padding: 15px;
        border-radius: 50%;
        width: 55px;
        height: 55px;
        display: flex;
        margin-right: 10px;
        align-items: center;
        justify-content: center;
        path {
          fill: #051f34;
        }
      }

      p {
        flex: 1;
      }
    }
  }

  .newAccount {
    background: none;
    border: none;
    padding: 0;
    font-size: 22px;
    color: #1900ff;
    font-weight: 600;
  }
`;
