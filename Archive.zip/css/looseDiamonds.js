import styled from "styled-components";
import ConflictBg from "../assets/images/looseDiamonds/conflictFree.png";

export const LooseDiamondsWrap = styled.div`
  .diamond-Category {
    padding: 100px 0;
    h2 {
      font-family: var(--sort-font);
      font-size: 50px;
      color: #051f34;
      display: flex;
      align-items: center;
      span {
        font-family: var(--prist-font);
        font-size: 214px;
        color: var(--primary);
        line-height: 130px;
      }
    }
    .list {
      justify-content: space-evenly;
      li {
        text-align: center;
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        a {
          font-weight: 500;
          color: #000;
          padding-top: 10px;
          width: 100%;
          display: flex;
          flex-direction: column;
          justify-content: center;
          align-items: center;
        }
        svg {
          min-height: 80px;
        }
      }
    }
  }
  .how-to-choose-diamond {
    padding: 30px 0;
    .right {
      p {
        font-size: 24px;
        color: #707070;
      }
      .consultation {
        padding-top: 40px;
        h6 {
          color: #707070;
          font-weight: 600;
          margin: 0 0 10px;
        }
        ul {
          display: flex;
          justify-content: space-between;
          align-items: center;
          svg {
            padding-right: 10px;
          }
          a {
            font-size: 20px;
            color: #000;
          }
        }
      }
    }
  }
  .conflict-free-diamond {
    background: url(${ConflictBg}) no-repeat scroll center center / cover;
    .left,
    .right {
      background: rgba(255, 255, 255, 0.25);
      padding: 40px;
      position: relative;
      min-height: 60vh;
      display: flex;
      flex-direction: column;
      justify-content: center;
      h4 {
        font-size: 35px;
        font-weight: 900;
        margin: 0 0 30px;
        color: #fff;
        @media (max-width: 1700px) {
          font-size: 26px;
        }
      }
      p {
        color: #fff;
        font-size: 24px;
        line-height: 50px;
        @media (max-width: 1700px) {
          font-size: 16px;
          line-height: 40px;
        }
      }
    }
    .left {
      flex: 0 0 33%;
      margin-bottom: auto;
      &:after {
        content: "";
        position: absolute;
        background: rgba(255, 128, 0, 0.3);
        right: -10px;
        height: 90%;
        width: 10px;
        bottom: 0%;
      }
      &:before {
        content: "";
        position: absolute;
        right: 0%;
        background: rgba(255, 128, 0, 0.3);
        height: 10px;
        width: 90%;
        bottom: -10px;
      }
    }
    .right {
      flex: 0 0 33%;
      margin-top: 40px;
      &:after {
        content: "";
        position: absolute;
        background: rgba(255, 128, 0, 0.3);
        left: -10px;
        height: 90%;
        width: 10px;
        top: 0%;
      }
      &:before {
        content: "";
        position: absolute;
        left: 0%;
        background: rgba(255, 128, 0, 0.3);
        height: 10px;
        width: 90%;
        top: -10px;
      }
    }
  }
  .learning-center {
    padding: 80px 0;
    text-align: center;
    .common-heading {
      h3 {
        justify-content: center;
      }
    }
    .guide-list {
      padding-top: 40px;
      li {
        padding: 0 40px;
        span {
          margin-bottom: 20px;
          border: 1px solid #cb9274;
          padding-left: 9px;
          padding-bottom: 9px;
          display: inline-block;
          img {
            margin-top: -15px;
            margin-right: -4px;
          }
        }
        h4 {
          font-size: 31px;
          font-weight: 700;
          color: #051f34;
          margin: 0;
          @media (max-width: 1700px) {
            font-size: 21px;
          }
        }
      }
    }
  }
`;

export const DiamondListWrap = styled.div`
  .diamond-filters {
    padding: 80px 0;
    .slider-values {
      justify-content: center;
      & > div {
        background: #051f34;
        padding: 5px 0;
        font-size: 12px;
        color: #fff;
        font-weight: 600;
        margin: 0 1px;
        cursor: pointer;
        flex: 1;
        align-items: center;
        display: flex;
        justify-content: center;
        text-align: center;
        &.unselected {
          background: rgba(5, 31, 52, 0.25);
        }
      }
    }
    .d-grid {
      grid-template-columns: 1fr 1fr 1fr;
      grid-gap: 30px;
      & > div {
        text-align: center;
        background: #fff;
        box-shadow: 20px 20px 40px rgba(0, 0, 0, 0.16);
        display: inline-block;
        padding: 6px;
        position: relative;
        min-height: 170px;
        &:after {
          content: "";
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          background: rgba(203, 146, 116, 0.18);
          height: 12px;
          width: 30%;
          margin: 0 auto;
        }
        h4 {
          margin-top: -22px;
          text-shadow: 15px 8px 6px rgb(0 0 0 / 10%);
        }
        .shape-list {
          display: grid;
          grid-template-columns: 1fr 1fr 1fr 1fr 1fr;
          text-align: center;
          grid-column-gap: 10px;
          grid-row-gap: 10px;
          li {
            &.active {
              svg {
                & > g {
                  path {
                    fill: var(--primary);
                  }
                }
                circle {
                  fill: var(--primary);
                }
                g {
                  path,
                  line,
                  ellipse,
                  rect {
                    stroke: #fff;
                  }
                  g circle {
                    stroke: #fff;
                  }
                  g path {
                    fill: none;
                  }
                }
              }
            }
            button {
              background: none;
              border: none;
              p {
                color: #cb9274;
                font-size: 12px;
                font-weight: 500;
                text-transform: capitalize;
              }
              svg {
                width: 35px;
              }
            }
          }
        }
      }
    }
    .diamonds {
      h2 {
        pointer-events: none;
      }
      .dropdown-menu.open {
        position: static;
        border: none;
        padding: 0 30px;
        width: 100%;
        display: flex;
        flex-direction: column;
        justify-content: center;
        height: 100%;
        background: none;
        .input-range {
          margin: 0 0 30px;
        }
        .form-control {
          border: 1px solid #cb9274;
          border-radius: 0;
          font-size: 14px;
          padding: 5px 10px;
          margin: 0 0;
          color: #000;
          font-weight: 600;
          line-height: normal;
          height: auto;
          text-align: right;
          outline: none;
          box-shadow: none;
        }
        .form-group {
          margin: 0 20px;
          width: 100%;
          position: relative;
          label {
            position: absolute;
            top: 0;
            bottom: 0;
            margin: auto 0;
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            left: 10px;
            font-size: 12px;
            font-weight: 700;
          }
        }
      }
    }
  }
  .list-view {
    display: table;
    width: 100%;
    border-spacing: 0 15px;
    .listview-title {
      display: table-header-group;

      .header {
        display: table-row;
        table-layout: fixed;
        li {
          display: table-cell;
          background: rgba(234, 216, 207, 1);
          color: #0073f6;
          font-weight: 500;
          font-size: 20px;
          padding: 20px;
          position: sticky;
          top: 0;
          cursor: pointer;
          @media (max-width: 1700px) {
            font-size: 16px;
            padding: 10px;
          }
        }
      }
    }
    .product {
      display: table-row-group;
      li {
        display: table-row;
        background: rgba(255, 255, 255, 0.7);
        p,
        span {
          display: table-cell;
          font-weight: 500;
          font-size: 20px;
          vertical-align: middle;
          padding: 20px;
          @media (max-width: 1700px) {
            font-size: 14px;
            padding: 10px;
          }
          img {
            display: none;
            &:first-child {
              display: block;
              width: 60px;
            }
          }
        }
        button {
          font-weight: 500;
          font-size: 20px;
          padding: 20px;
          display: table-cell;
          vertical-align: middle;
          background: none;
          border: none;
          color: #0273f6;
          @media (max-width: 1700px) {
            font-size: 14px;
            padding: 10px;
          }
        }
      }
      &.hover {
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      }
    }
  }
  .comparison {
    width: 100%;
    .header,
    .body {
      .list {
        li {
          text-align: right;
          padding: 10px 30px;
          color: rgba(0, 0, 0, 0.5);
          min-height: 40px;
          &:first-child {
            background: #fff !important;
          }
          &:empty {
            display: none;
          }
          span {
            padding: 30px 20px;
            display: inline-block;
          }
          &:nth-child(odd) {
            background: #ead8cf;
          }
          &:nth-child(even) {
            background: #fff;
          }
          &.dropdownBtn {
            padding: 0;
            display: flex;
            .dropdown {
              width: 100%;
              display: flex;
              &.show {
                background: #fff;
                .dropdown-toggle {
                  background: none;
                  color: #051f34;
                  &:after {
                    transform: rotate(180deg);
                  }
                }
              }
              .dropdown-toggle {
                background: #051f34;
                width: 100%;
                border-radius: 0;
                border: none;
                font-weight: 600;
                outline: none !important;
                box-shadow: none !important;
              }
              .dropdown-menu {
                width: 100%;
                border: none;
                border-radius: 0;
                padding: 0;
                button {
                  text-align: center;
                  background: rgba(0, 0, 0, 0.06);
                  margin: 5px 0;
                  font-weight: 600;
                }
              }
            }
          }
        }
      }
    }
    .header {
      margin-top: auto;
      margin-right: 30px;
    }
    .body {
      display: flex;
      flex-wrap: nowrap;
      width: 100%;
      overflow-x: auto;
      .list {
        margin-right: 30px;
        li {
          text-align: center;
          color: #000;
          font-weight: 600;
        }
      }
    }
  }
  .grid-view {
    grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
    grid-gap: 40px;
    .product {
      background: #fff;
      text-align: center;

      span {
        cursor: pointer;
        img {
          display: none;
          &:first-child {
            display: block;
          }
        }
      }
      .desc {
        background: rgba(203, 146, 116, 0.17);
        padding: 20px;
        h4 {
          color: #cb9274;
          font-size: 19px;
          font-weight: 500;
          margin: 0;
          cursor: pointer;
          text-align: center;
          @media (max-width: 1700px) {
            font-size: 16px;
          }
        }
        h5 {
          color: #000;
          font-size: 26px;
          font-weight: 600;
          padding-top: 20px;
          @media (max-width: 1700px) {
            font-size: 20px;
            padding-top: 10px;
          }
        }
      }
      &.hover {
        box-shadow: 0 0 20px rgb(0 0 0 / 30%);
      }
    }
  }
  .title {
    border-bottom: 1px solid rgba(112, 112, 112, 0.5);
  }
  .nav {
    border: none;
    .nav-item {
      margin: 0;
      a {
        color: #afafaf;
        font-size: 20px;
        border: none;
        cursor: pointer;
        @media (max-width: 1700px) {
          font-size: 16px;
        }
        &.active {
          border-radius: 30px 30px 0 0;
          background: rgb(234, 216, 207);
          color: #000;
          font-weight: 500;
          padding: 10px 30px;
        }
      }
    }
  }
  .view {
    label {
      margin: 0 10px;
      font-size: 20px;
      font-weight: 500;
      color: var(--primary);
      @media (max-width: 1700px) {
        font-size: 16px;
      }
    }
    svg {
      cursor: pointer;
      &.active {
        pointer-events: none;
        #Rectangle_1603 {
          fill: #ead8cf;
        }
      }
    }
  }
  .diamond-filters-dropdown {
    .inner-filter {
      display: flex;
      align-items: center;
      label {
        font-size: 20px;
        font-weight: 500;
        margin-right: 5px;
        margin-bottom: 0;
        color: #afafaf;
        @media (max-width: 1700px) {
          font-size: 16px;
        }
      }
      &.sort {
        .dropdown-menu {
          margin-left: -100%;
        }
        .dropdown-item {
          padding: 0;
          color: #000;
          border: none;
          .min-max {
            h6 {
              color: rgba(0, 0, 0, 0.64);
              font-size: 20px;
              text-align: center;
              @media (max-width: 1700px) {
                font-size: 16px;
              }
            }
            ul {
              li {
                display: flex;
                justify-content: space-between;
                span {
                  border: none;
                  flex: 1;
                  cursor: pointer;
                  font-size: 12px;
                  padding: 2px 5px;
                  background: rgba(234, 216, 207, 0.55);
                  margin-right: 5px;
                  font-style: italic;
                  &:hover {
                    color: rgba(0, 0, 0, 1);
                  }
                }
              }
            }
          }
        }
      }
      .dropdown {
        button {
          background: none;
          color: #000;
          border: none;
          border-bottom: 1px solid #000;
          border-radius: 0;
          outline: none !important;
          box-shadow: none !important;
          @media (max-width: 1700px) {
            font-size: 14px;
          }
        }
        .dropdown-menu {
          box-shadow: 0 3px 6px rgba(0, 0, 0, 0.16);
          border: 2px solid #ead8cf;
          padding: 0;
          button {
            color: rgba(0, 0, 0, 0.64);
            font-size: 20px;
            padding: 18px 32px;
            border: none;
            @media (max-width: 1700px) {
              font-size: 14px;
              padding: 8px 22px;
            }
          }
        }
      }
    }
    .fast-shipping {
      flex: 1;
      color: #0073f6;
      font-size: 20px;
      font-weight: 500;
      @media (max-width: 1700px) {
        font-size: 16px;
      }
      label {
        margin: 0;
      }
      svg {
        margin: 0 10px;
      }
    }
  }
  .diamond-preview {
    background: #fff;
    position: sticky;
    height: auto;
    top: 0;
    h6 {
      padding: 0 20px;
      font-size: 20px;
      display: flex;
      align-items: center;
      justify-content: center;
      height: 100%;
      text-align: center;
      color: #707070;
    }
    h2 {
      background: var(--primary);
      color: #fff;
      text-align: center;
      padding: 10px 0;
      font-size: 25px;
      font-weight: 600;
    }
    svg {
      width: 95%;
      padding: 0 20px;
      height: 100%;
    }
    .list {
      display: grid;
      grid-template-columns: 1fr 1fr;
      li {
        h4 {
          margin: 0;
          padding: 10px 30px;
          font-size: 14px;
          background: rgba(203, 146, 116, 0.05);

          @media (max-width: 1700px) {
            font-size: 12px;
            padding: 10px 20px;
          }
        }
        p {
          padding: 10px 30px;
          color: rgba(0, 0, 0, 0.5);
          font-size: 14px;
          word-break: break-all;
          @media (max-width: 1700px) {
            font-size: 12px;
            padding: 10px 20px;
          }
        }
      }
    }
    .preview-inner {
      .table-size {
        left: 0;
        right: 0;
        margin: 0 auto;
        text-align: center;
        top: 8%;
        color: #707070;
        font-size: 15px;
        font-weight: 700;
        padding-right: 50px;
      }
      .depth {
        right: 2%;
        bottom: 0;
        top: 0;
        display: flex;
        align-items: center;
        color: #707070;
        font-size: 15px;
        font-weight: 700;
      }
    }
  }
`;
