import styled from "styled-components";

export const PaymentWrap = styled.div`
  position: relative;
  &:before {
    position: absolute;
    left: 0;
    width: 425px;
    background: #eddfd6;
    height: 100%;
    content: "";
    z-index: -1;
    top: 0;
  }
  .payment-method {
    background: #fff;
    padding: 30px;
  }
  .order-info {
    background: #fff;
    padding: 40px;
    h4 {
      font-size: 16px;
      color: #081148;
      margin: 0;
      &.orderno {
        margin-bottom: 20px;
      }
    }
    .products {
      .box {
        background: #fff;
        padding: 20px 15px;
        margin: 0 0 10px;

        span {
          img {
            display: none;
            &:first-child {
              display: block;
              width: 120px;
            }
          }
        }
        .right {
          display: flex;
          flex-direction: column;
          justify-content: space-between;
        }
      }
    }
    .shippingInfo {
      margin: 0 0 10px;
    }
    .addressInfo {
      & > .shipping {
        margin: 0 0 20px;
      }
    }
  }
`;
