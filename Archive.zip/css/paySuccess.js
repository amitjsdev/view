import styled from "styled-components";

export const PaySuccess = styled.div`
  .payimage {
    display: block;
    margin-left: auto;
    margin-right: auto;
    width: 30%;
  }
  .paytext1 {
    text-align: center;
    color: #002366;
    font-size: 40px;
    margin: 30px 0 0;
  }
  .paytext2 {
    text-align: center;
    color: #002366;
    font-size: 22px;
  }
  .paybuttonrel {
    height: 50px;
    position: relative;
    align-content: center;
    color: #fff;
    // background-color: #002366;
  }
  .paybuttoncen {
    margin: 0;
    position: absolute;
    top: 50%;
    border: none;
    left: 50%;
    -ms-transform: translate(-50%, -50%);
    transform: translate(-50%, -50%);
  }
  .button {
    color: #fff;
    background-color: #002366;
    border: none;
    padding: 10px 20px;
    margin-top: 30px;
  }
`;
