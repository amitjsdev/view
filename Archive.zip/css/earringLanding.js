import styled from "styled-components";

//images
import Modal from "../assets/images/model/model.jpg";
import Modal2 from "../assets/images/model/model2.jpg";

export const EarringLanding = styled.div`
  .banner {
    margin: 0 !important;
  }
  .ProductCategories {
    margin: 0 0 60px;
    &.flex-row-reverse {
      .mainslider {
        text-align: right;
      }
      .right {
        .productlist {
          padding-left: 0;
          padding-right: 120px;
        }
      }
    }
  }

  .mainslider {
    padding: 30px 0 0;
    width: 100%;
    text-align: left;
    .heading {
      h2 {
        font-size: 28px;
        @media (max-width: 1500px) {
          font-size: 24px;
        }
        .lastline {
          text-decoration: underline;
        }
      }
      &.leftSide {
        color: #000;
      }
    }
    .slider {
      padding-top: 30px;
      .carousel-inner {
        img {
          height: 160px;
        }
      }
      .carousel-indicators {
        bottom: -80px;
        li {
          width: 20px;
          height: 0;
          margin-right: 15px;
          border-radius: 50%;
          &:first-child {
            background: #aeaeae;
          }
          &:nth-child(2) {
            background: #debbab;
          }
          &:last-child {
            background: #cabe6a;
          }
        }
      }
    }
  }
  .left {
    .image {
      flex: 1;
      background: url(${Modal}) no-repeat scroll top -100px center / 100%;
      border-radius: 0 0 200px 0;
      position: relative;
      &:before {
        content: "";
        border: 6px solid rgba(203 146 116/ 30%);
        position: absolute;
        top: 2%;
        width: 100%;
        height: 100%;
        z-index: -1;
        border-radius: 0 0 200px 0;
        left: 14px;
      }
    }
    &.flex-row-reverse {
      .image {
        border-radius: 0 0 0 200px;
        background: url(${Modal2}) no-repeat scroll top -70px center / 100%;
        &:before {
          border-radius: 0 0 0 200px;
          left: -14px;
        }
      }
    }
  }
  .right {
    flex: 1;
    flex-direction: column;
    text-align: center;
    display: flex;
    padding: 0 0 40px;
    justify-content: center;
    align-items: flex-end;
    .filters {
      display: inline-block;
      width: auto;
      margin-bottom: 30px;
      padding-right: 27px;
      h3 {
        font-size: 30px;
        color: #010a43;
        margin-bottom: 10px;
        font-weight: 400;
        @media (max-width: 1500px) {
          font-size: 24px;
        }
      }
      .list {
        border-top: 1px solid rgba(112, 112, 112, 0.15);
        border-bottom: 1px solid rgba(112, 112, 112, 0.15);
        justify-content: center;
        width: auto;
        padding: 5px 0;
        align-items: center;
        cursor: pointer;
        li {
          padding: 0 15px;
          font-size: 25px;
          font-weight: 600;
          color: rgba(0, 0, 0, 0.3);
          border: none;
          background: none;
          box-shadow: none;
          @media (max-width: 1500px) {
            font-size: 22px;
          }
          &.active {
            color: #010a43;
            font-weight: 700;
            text-shadow: 4px 4px rgb(0 0 0 / 10%);
          }
          &:hover {
            color: #010a43;
            text-shadow: 4px 4px rgb(0 0 0 / 10%);
            font-weight: 700;
          }
        }
      }
    }
    .productListing {
      padding: 0;
      .productlist {
        display: flex;
        align-items: center;
        cursor: pointer;
        justify-content: space-between;
        width: 100%;
        padding-left: 120px;
        li {
          .productWrap {
            padding: 0;
            width: 100%;
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            &.active {
              padding: 24px 48px;
              img {
                width: 136px;
              }
              .price {
                font-size: 18px;
              }
              h4 {
                font-size: 24px;
              }
            }
            span {
              display: flex;
              min-height: 70px;
              align-items: center;
              justify-content: center;
            }

            h4 {
              font-size: 16px;
              font-weight: 700;
              color: var(--primary);
              margin: 15px 0 5px;
              width: 100%;
              @media (max-width: 1500px) {
                font-size: 14px;
              }
            }
            .price {
              font-size: 14px;
              color: #000;
              min-height: auto;
              font-weight: 700;
            }
          }
        }
      }
    }
  }
`;
