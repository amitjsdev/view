import styled, { createGlobalStyle, css } from "styled-components";

//images
import GiftBg from "../assets/images/hoops/landing/giftcardbg.png";
import Banner from "../assets/images/hoops/landing/hoopsBan.png";
import LooseDiamondBanner from "../assets/images/looseDiamonds/diamondBg.png";
import EngagementRingBg from "../assets/images/engagementRing/ringbg.png";
import Range from "../assets/images/diamond-range-slider.svg";
import Closeimg from "../assets/images/hoops/landing/filter-close.png";
import Arrow from "../assets/images/striparrow.svg";

// CustomButton design
export const CustomButton = styled.button`
  border: none;
  &[disabled] {
    opacity: 0.7;
    cursor: not-allowed;
  }
  ${(props) =>
    props.cursive &&
    css`
      font-size: 22px;
      border: none;
      background: none;
      box-shadow: none;
      outline: none;
      font-weight: 700;
      color: var(--primary);
      padding: 0 50px;
      font-family: var(--my-font-family) !important;
      position: relative;
      line-height: normal;
      transition: 0.6s;
      &:hover {
        color: transparent;
        transition: 0.6s;

        &:before {
          color: var(--primary);
          transition: 0.6s;
        }
      }

      &:before {
        content: "";
        position: absolute;
        left: 0;
        right: 0;
        bottom: 0;
        font-size: 50px;
        transition: 0.6s;
        top: -20px;
        font-family: var(--ed-font);
        color: rgba(227, 219, 212, 0.34);
        z-index: -1;
      }
    `}
  ${(props) =>
    props.dark &&
    css`
      padding: 10px 40px;
      text-transform: capitalize;
      font-weight: 500;
      line-height: normal;
      background: var(--heading-color);
      color: white;
      line-height: normal;
      font-size: 16px;
      overflow: hidden;
      position: relative;

      &:before {
        content: " ";
        display: block;
        width: 200px;
        height: 80px;
        background: rgba(255, 255, 255, 0.1);
        position: absolute;
        top: -10px;
        left: -200px;
        transform: rotate(-45deg);
        transition: all 0.25s ease-in-out;
      }

      &:hover:before {
        margin-left: 300%;
      }
    `}
    ${(props) =>
    props.light &&
    css`
      background: var(--primary);
      color: #fff;
      font-weight: 600;
      font-size: 20px;
      padding: 5px 28px;
      overflow: hidden;
      position: relative;

      &:before {
        content: " ";
        display: block;
        width: 200px;
        height: 80px;
        background: rgba(255, 255, 255, 0.1);
        position: absolute;
        top: -10px;
        left: -200px;
        transform: rotate(-45deg);
        transition: all 0.25s ease-in-out;
      }

      &:hover:before {
        margin-left: 300%;
      }
    `} // CustomButton design
`;

export default createGlobalStyle`:root {
    --primary: #CB9274;
    --my-font-family: 'Josefin Sans', sans-serif;
    --primary-font: 'Montserrat', sans-serif;
    --second-font-family: 'Roboto', sans-serif;
    --body-color: #F6F4F2;
    --sort-font: 'Sorts Mill Goudy', serif;
    --dance-font: 'Dancing Script', cursive;
    --heading-color: #051F34;
    --ed-font: 'edwardian_script_itcregular';
    --prist-font: 'pristinaregular';
}

body {
    font-family: var(--primary-font) !important;
    overflow-x: hidden;
    background: var(--body-color);
}

p {
    margin: 0;
}

button {
    outline: none !important;
}

ul {
    margin: 0;
    padding: 0;

    li {
        list-style: none;
    }
}

.dropdown-menu.open {
    display: block;
}



span.input-range__label-container {
    display: none;
}

input[type="number"] {
  -webkit-appearance: textfield;
     -moz-appearance: textfield;
          appearance: textfield;
}
input[type=number]::-webkit-inner-spin-button, 
input[type=number]::-webkit-outer-spin-button { 
  -webkit-appearance: none;
}

a:hover {
    text-decoration: none;
}

.topbar {
    background: var(--primary);

    p {
        color: #fff;
        font-weight: 400;
        font-size: 15px;
        padding: 10px 0;
    }
}

.d-grid{
    display:grid !important;
}

.grid-template-res{
    grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));

}

.billing-shipping-address-inner {
    display: flex;
    justify-content: space-between;
    h2 {
      font-size: 30px;
      font-family: "Sorts Mill Goudy", serif;
      color: #081148;
      margin-bottom: 50px;
    }
  }

  .billing-shipping-address {
    position: relative;
    
    .mainflex {
      flex: 1;
    }
  }

// EXPLORE MORE
.explore-more {
    position: relative;
    margin-top: 60px;
    margin-bottom: -71px;
    &.home{
        margin-bottom:0;
        &:before{
            height:80px;
            bottom:27%;
            top:auto;
        }
        .explore-more-left{
            h3{
                align-items: flex-end;
                margin-top:0;
                display: flex;
                margin-bottom:50px;
                span{
                    line-height: 150px;
                    font-size: 130px;
                }
            }
        }
        .explore-more-inner{
            flex-wrap:wrap;
            justify-content:center;
            margin:50px 0 0;
        }
        .explore-gallery{
            width:100%;
            justify-content:center;
           .explore-gallery-inner{
                grid-gap: 20px;
                grid-template-columns: repeat(auto-fit,minmax(190px,max-content));
                width: 100%;
                justify-content: center;
           }
        }
    }
    
	&::before {
		border-left: 9999px solid rgba(203,146,116,0.24);
        position: absolute;
        right: 0%;
        height: 135px;
        width: 100%;
        content: " ";
        top: 20px;
	}
    .explore-more-left{
        h3 {
            font-size: 35px;
            color: #051F34;
            font-family: var(--sort-font);
            margin-top: -70px;
            span {
                font-family: var(--prist-font);
                color: var(--primary);
                font-size: 214px;
                top: 50px;
                position: relative;
                margin-right: 5px;
            }
        }
	}
    .explore-more-inner{
        display:flex;
        justify-content:space-between;
    }
    .explore-gallery {
        display: flex;
        justify-content: flex-end;
    }
    .gallery-item {
        h6 {
            font-size: 16px;
            font-weight: bold;
            color: #000;
            margin-top: 25px;
            max-width: 50%;
        }
    }
    .explore-gallery-inner {
        
        display: grid;
        grid-template-columns: repeat(5, 190px);
        grid-gap: 10px;
    }
    .gallery-img {
        position: relative;
        padding-left: 9px;
        padding-bottom:9px;
        border: 1px solid #CB9274;
        img{
            margin-top:-15px;
            margin-right:-1px;
        }
    }
}

@media (max-width:1439px) {
	.explore-more {
		h3 {
			span {
				font-size: 150px;
			}
			font-size: 30px;
			margin-top: -55px;
		}
		&::before {
			height: 95px;
			top: 20px;
		}
	}
	.gallery-item {
		h6 {
			font-size: 14px;
			margin-top: 15px;
		}
	}
}
// EXPLORE MORE

// Filter
.ban {
    width: 50%;
}
.sorting {
    padding: 20px 0;
    select{
        margin-left:20px;
       
        &:first-child{
            background: rgba(227,219,212,0.58);
            border: none;
            padding: 10px;
        }
    }
}
.filters {
    margin: 0 0 60px;
  }
// Filter

// Common Banner
.banner {
    &.loose-diamond{
        background: url(${LooseDiamondBanner}) no-repeat scroll top 0% right -10% / 45vw;
    }
    &.ring{
      background: url(${EngagementRingBg}) no-repeat scroll top 100% right 0% / 36vw;
      .btnGroup{
        padding-top:30px;
        & > div{
          display:flex;
          flex-direction: column;
          align-items:center;
          padding-right:20px;
          span{
            min-height:110px;
          }
          ${CustomButton}{
            padding:0;
            margin:0;
          }
        }
        .ring-btn{
          padding-right:50px;
          button{
            
            &:before{
              content:"Engagement"
            }
          }
        }
        .diamond-btn{
          button{
            &:before{
              content:"Diamonds";
            }
          }
        }
      }
    }
    
    display: flex;
    align-items: center;
    width: 100%;
    background: url(${Banner}) no-repeat scroll top 50% right -20% / 54%;
    height: calc(100vh - 209px);
    h1 {
      position: absolute;
      font-size: 6rem;
      color: rgba(0, 0, 0, 0.05);
      top: -30%;
      left: 0%;
    }
    .bantext {
      h2 {
        font-family: var(--sort-font);
        font-size: 39px;
        color: var(--heading-color);
      }
      p {
        font-style: italic;
        font-size: 15px;
        width: 40%;
      }
      button {
        margin-top:30px;
        &:before {
          content: "Shop Now";
        }
      }
    }
  }
// Common Banner



// Gift card
.giftCard {
    margin: 80px 0;
    position: relative;
    background: url(${GiftBg}) no-repeat scroll top left -12vw / auto 100%;
    height: 60vh;
    width: 100%;

    &:before {
      content: "GIFT";
      position: absolute;
      top: -20px;
      left: -8%;
      color: rgba(0, 0, 0, 0.02);
      font-size: 31rem;
      letter-spacing: 10px;
      line-height: 90%;
      overflow: hidden;
    }
    .left {
      text-align: center;

      span.head {
        width: 100%;
        display: inline-block;
      }
    }

    button {
      &:before {
        content: "Shop Now";
      }
    }
  }
  // Gift card

.input-range__track--active{
  background: #CBCBCB;
}

.input-range__slider{
  background: #CBCBCB url(${Range}) no-repeat scroll 0 0;
  border: none;
  width: 25px;
  height: 25px;
  background-size: 100% 100%;
  margin-top: -15px;
  &:active{
    transform: scale(1.2);
  }
}

@media(min-width:1200px) {
    .container {
        max-width: 1300px;
    }
}

@media(min-width:1500px) {
    .container {
        max-width: 1440px;
    }
}

@media(min-width:1700px) {
    .container {
        max-width: 1600px;
    }
}

@media(min-width:2000px) {
    .container {
        max-width: 1900px;
    }
}

// Loader
.loader {
	position: relative;
	margin: auto;	
}

.middle {
	top: 0;
	left: 0;
	width: 40px;
	height: 2px;
	background: white;
	position: absolute;
	animation: middleAnimation 2s infinite linear;
	animation-delay: -100ms;
}

.bottom {
	top: 0;
	left: 0;
	position: absolute;
	height: 30px;
	width: 2px;
	background: white;
	border-radius: 2px;
	transform-origin: bottom;
	transform: rotate(45deg);
	animation: bottomAnimation 4s infinite;
}

.bottom:nth-child(1) {
		animation-delay: -1000ms;
}

.bottom:nth-child(2) {
		animation-delay: -2000ms;
}

.bottom:nth-child(3) {
		animation-delay: -3000ms;
}

.bottom-section {
	position: absolute;
	transform: translateY(-16px);	
}

.top-section {
	position: absolute;
	transform: translateY(16px);
	transform: scaleY(-1);	
}

@keyframes bottomAnimation {
	0% {transform: rotate(45deg) scaleY(1.0);}
	25% {transform: rotate(0) scaleY(0.7);}
	50%{transform: rotate(-45deg) scaleY(1.0);}
	75% {transform: rotate(0) scaleY(0.7);}
	100% {transform: rotate(45deg) scaleY(1.0);}
}

@keyframes middleAnimation {
	0% {transform: translate(-19px, -9px) scaleX(1.0);}
	25% {transform: translate(-19px, -9px) scaleX(0.6);}
	50%{transform: translate(-19px, -9px) scaleX(1.0);}
	75% {transform: translate(-19px, -9px) scaleX(0.7);}
	100% {transform: translate(-19px, -9px) scaleX(1.0);}
}

// Loader


// TO remove css at the time of autofill
input:-webkit-autofill,
input:-webkit-autofill:hover,
input:-webkit-autofill:focus,
textarea:-webkit-autofill,
textarea:-webkit-autofill:hover,
textarea:-webkit-autofill:focus,
select:-webkit-autofill,
select:-webkit-autofill:hover,
select:-webkit-autofill:focus {
    -webkit-box-shadow: 0 0 0px 1000px #fff inset;
    transition: background-color 5000s ease-in-out 0s;
}
// TO remove css at the time of autofill


// Footer
footer {
    background: rgba(203, 146, 116, 0.22);
    padding: 50px 0;
    color: #fff;

    h2 {
        font-size: 25px;
        margin: 0 0 30px;
        font-family: var(--sort-font) !important;
        color: #000;
    }

    ul {
        li {
                      margin: 0 0 10px;
    a {
      color: #000;
            font-size: 15px;
            font-weight: 300;
    }
        }
    }
}

.copyRight {
    text-align: center;
    padding: 5px 0;
}
// Footer

// For title of the pages
.mainHeading {
    .title {
        color: var(--heading-color);
        margin: 0;
        font-family:var(--sort-font);
        border: none;
        font-size:30px;
    }
}
// For title of the pages


// Recent View
.recentView {
    padding: 0 0 150px;

    h2 {
        color: var(--heading-color);
        font-family: var(--sort-font);
        font-size: 40px;
        display: flex;
        align-items: center;
        margin: 0;

        span {
            font-family: var(--prist-font);
            font-size: 174px;
            line-height: 180px;
            color: var(--primary);
        }

        b {
            margin-top: 90px;
            margin-left: -50px;
            font-weight: 400;
        }
        
    }

    .react-multi-carousel-list {
        flex: 1;
        .react-multi-carousel-item{
            margin:0 15px;
        }
        .box {
            background: #fff;
            display: inline-block;
            padding: 80px 50px;
            img{
                width:100%;
            }

            h3 {
                color: var(--primary);
                font-size: 19px;
                font-weight: 600;
            }

            h4 {
                color: var(--heading-color);
                font-size: 15px;
                font-weight: 600;
            }
        }
    }
}
// Recent View


// NewsLetter
.newsletter {
    background: rgba(203, 146, 116, .22);
    margin: 0 0 80px;

    h2 {
        font-size: 35px;
        color: var(--heading-color);
        font-family: var(--sort-font);
        margin: 0 0 20px 20px;
    }

    .left {
        margin-left: -80px;
    }

    .right {
        text-align: left;

        .form-group {
            background: #fff;
            display: inline-flex;
            justify-content: space-between;
            width: 100%;

            input {
                border: none;
                padding: 20px 10px;
                flex: 1;
            }

            button {
                border: none;
                color: var(--primary);
                background: none;
                font-family: var(--my-font-family);
                font-weight: 700;
                font-size: 18px;
            }

            .btn-group {
                display: inline-flex;
                justify-content: space-between;
                flex: 0 0 25%;
                margin-right: 20px;
            }
        }

        h6 {
            width: 100%;
            text-align: center;
            font-style: italic;
            font-size: 17px;
            padding: 0 30px;
            color: #707070;
        }
    }
}
// NewsLetter

.input-range__label--min, .input-range__label--max{
    display:none;
}

// Error Message
.errorMessage{
    color:#ff5000;
    font-size:12px;
    width: 100%;
    display: inline-block;
}
// Error Message

// Out of stock
.out {
    margin: 0;
    color: #ff0a0a;
    font-size: 23px;
    @media (max-width: 1500px) {
        font-size: 26px;
    }    
}
// Out of stock

// USP
.usp {
    background: var(--primary);
    .list {
        justify-content: space-between;
        padding: 20px 0;
        li {
        text-align: center;
        h5 {
            color: #fff;
            margin: 10px 0 0;
            font-size:16px;
            span{
                color: rgba(255,255,255,0.7);
            }
        }
        }
    }
}
// USP

// Need Help
.need-help {
    padding: 100px 0 0 0;

    h4 {
      color: #000;
      font-weight: bold;
      font-size: 45px;
    }

    p {
      font-size: 28px;
      font-weight: 500;
      color: var(--heading-color);
      margin-top: 22px;
    }
}
.need-help-info {
    background: #fff;
    height: 78px;
    line-height: 74px;
    margin-top: 27px;

    .need-help-inner {
      padding: 0 35px;
    }

    ul {
      list-style: none;
      display: flex;
      justify-content: space-evenly;

      a {
        font-size: 29px;
        color: #000;
        margin-left: 40px;
        display: inline-block;
        vertical-align: middle;
      }

      img {
        display: inline-block;
        vertical-align: middle;
      }
    }
  }
  @media(max-width:1700px){
    .need-help {
      h4 {
        font-size: 28px;
      }

      p {
        font-size: 18px;
        margin-top: 15px;
      }
    }

    .need-help {
      padding: 55px 0 0 0;

      .need-help-info {
        height: 65px;
        line-height: 65px;

        ul {
          a {
            font-size: 18px;
            margin-left: 15px;
          }

          svg {
            width: 30px;
          }
        }
      }
    }
  }
  // Need Help
   // Create Your Ring section
.create-your-ring {
    background: #fff;
    padding: 50px 0 90px 0;
  }


  .create-your-ring-inner {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  .create-your-ring-left {
    h3 {
      margin-bottom: -30px;
      display: inline-block;
    }

    p {
      font-size: 20px;
      line-height: 33px;
      font-style: italic;
      color: #707070;
      margin: 0 0 20px;
    }

    .call-expert {
      font-size: 25px;
      color: #000000;
      font-weight: bold;
      display: inline-block;

      a {
        font-size: 36px;
        color: #000;
        position: relative;
        top: 4px;
        margin-left: 22px;
      }
    }
  }
  .create-ring-right {
    display: flex;
    justify-content: space-evenly;
    width: 100%;

    .ring-options {
      margin-left: 35px;
      margin-right: 35px;
      text-align: center;

      ${CustomButton} {
        padding: 0;
        font-size: 24px;
        z-index: 9;
        &.setting {
          &:before {
            content: "Settings";
          }
        }
        &:before {
          content: "Diamonds";
          font-size: 60px;
        }
      }

      .img-container {
        min-height: 350px;
        position: relative;
        margin-bottom:30px;

        img {
          position: absolute;
          left: 50%;
          top: 50%;
          transform: translate(-50%, -50%);
        }
      }
    }
  }
  .type-list {
      display: flex;
      padding-right: 40px;
      li {
        text-align: center;
        padding-right: 20px;
        cursor: pointer;
        .position-relative {
          svg {
            width: 50px;
          }
          &.yellow {
            svg {
              path#Path_12915-2,
              path#Path_12912 {
                fill: #ffdb69;
              }
              path#Path_12913,
              path#Path_12914-2 {
                fill: #ffc813;
              }
            }
          }
          &.rose {
            svg {
              path#Path_12915-2,
              path#Path_12912 {
                fill: #ffd4e6;
              }
              path#Path_12913,
              path#Path_12914-2 {
                fill: #f7b3d0;
              }
            }
          }
          p {
            position: absolute;
            top: 12%;
            bottom: 0;
            right: 0;
            left: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 500;
            color: #000;
            font-size: 16px;
          }
        }
        h4 {
          margin: 0;
          font-size: 14px;
          font-weight: 500;
        }
      }
    }
  .create-your-ring-left {
      p {
        font-size: 18px;
        line-height: 34px;
      }

      h3 {
        margin-bottom: 0;
      }

      .call-expert {
        font-size: 16px;

        a {
          font-size: 22px;
          top: 1px;
          margin-left: 14px;
        }
      }
    }

    .create-your-ring {
      padding: 50px 0 50px 0;

      .create-ring-right {
        .ring-options {
          h4 {
            font-size: 20px;
            margin-top: 30px;
          }

          .img-container {
            min-height: 220px;

            img {
              max-width: 220px;
            }
          }
        }
      }
    }
    .common-heading {
      h3 {
        font-size: 40px;
        color: var(--heading-color);
        font-family: var(--sort-font);
        font-weight: 400;
        display: flex;
        align-items: center;
        line-height:100px;

        span {
          font-family: var(--prist-font);
          color: var(--primary);
          font-size: 174px;
          position: relative;
        }
      }
    }

    // filter tags
    .sorting-wrap {
      .sorting {
        select {
          outline: 0;
          cursor: pointer;
        }
      }
      .sorting-tags {
        margin: 0 0 30px 0;
        button {
          background: #EBEBEB;
          border: 0;
          color: #000;
          font-size: 14px;
          line-height: 1;
          padding: 5px 30px 5px 5px;
          margin: 0 15px 10px 0;
          min-height: 24px;
          vertical-align: top;
          position: relative;
          &:last-child {
            margin: 0;
          }
          &:hover {
            color: var(--primary);
          }
          &:after {
            content: "";
            background: url(${Closeimg}) no-repeat;
            position: absolute;
            right: 5px;
            top: 0;
            bottom:0;
            margin:auto;
            width: 14px;
            height: 14px;
          }
        }
      }
    }


  @media (max-width: 1700px) {
    .common-heading {
      h3 {
        font-size: 30px;

        span {
          font-size: 110px;
        }
      }
    }
  }
  // Create Your Ring section
  .productDiv {
    display: flex;\
  }
  .productName {
    margin-left: 10px;
}
li.activeShape {
  border: 1px #cb9274 solid;
}
.strip{
  position:relative;
  background:#fff;
  ul.steps {
    display: flex;
    background:#fff;
    margin: 20px 0 0;
    li {
      width: 100%;
      padding: 10px 16px;
      position:relative;
      display:flex;
      .left{
        display: flex;
        align-items: center;
        width:100%;
        span{
          position:absolute;
          left:20px;
          color:rgba(203,146,116,0.35);
          font-size:50px;
          font-weight:700;
          line-height: 44px;
          top:0;
        }
      }
      p{
        font-size:16px;
        color:#000;
        font-weight:600;
        &.stepsPrice{
          color:var(--primary);
        }
      }
      .righSection {
        z-index: 1;
        padding-right: 40px;
        display:flex;
        align-items:center;
        position: relative;
        margin-left:auto;
        .stepsPrice{
          color:var(--primary);
          font-size: 16px;
        }
        span{
          cursor:pointer;
          color: #707070;
          font-size:12px;
          text-transform: capitalize;
          padding:0 5px;
          line-height:10px;
          border-right:1px solid var(--primary);
          &:hover{
            color:#000;
          }
          &.viewRight{
            padding-right:0;
            border:none;
          }
        }
      }
      &:after{
        content:"";
        background:url(${Arrow}) no-repeat scroll 0 0;
        position: absolute;
        right: 0;
        width: 100%;
        height: 100%;
        top: 0;
        background-position: right;
      }
      &:last-child{
        &:after{
          display:none;
        }
      }
      img.stepImg {
        width: 34px;
        margin: 0 10px;
      }
    }
  }
}

.newsletter {
  margin: 0;
  padding: 20px 0 !important;
  width: 100%;
  border-bottom: 1px solid #fff;

.right {
background: #fff;
max-width: 65%;

      h2 {
        color: var(--primary);
            margin: 0;
    width: auto;
    display: inline-block;
        position: relative;
        font-size: 24px;
    padding: 0 0 0 120px;

        &:before {
          content: "";
          width: 100%;
          height: 1px;
          background: rgba(203,146,116,.22);
          position: absolute;
          top: 50%;
          left: 0;
          z-index: 0;
          margin-top: -1px;
        }
        span {
            padding: 0 15px;
    position: relative;
    z-index: 1;
    background: #fff;
    line-height: normal;
        }
      }
.form-group {
display: inline-block;
width: auto;
margin: 0;

input {
    padding: 15px 10px;
outline: 0;
min-width: 500px;
}

.btn-group {
margin: 0;
    display: inline-block;
}
}
h6 {
display: none;
}
}
}

`;
