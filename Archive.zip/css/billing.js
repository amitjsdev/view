import styled from "styled-components";
import Radio from "../assets/images/radio.png";
import Checked from "../assets/images/checked.png";

export const Billing = styled.div`
  width: 100%;

  h3 {
    color: #081148;
    font-size: 22px;
    border-bottom: 3px solid #081148;
    display: inline-block;
    margin: 0 0 30px;
  }
  .form-group {
    margin-bottom: 30px;
    input {
      border: none;
      border-bottom: 1px solid rgba(112 112 112/ 40%);
      width: 100%;
      color: #000;
      outline: none;
    }
  }
  .address {
    label {
      margin: 0 10px 0 0;
      input {
        width: auto;
        margin-right: 5px;
      }
    }
  }
  .invalid-feedback {
    display: block;
  }
  .shipping {
    h3 {
      margin: 0;
    }
    .d-flex {
      margin-bottom: 30px;
    }
    label {
      margin: 0;
      font-size: 16px;
      position: relative;
      input {
        margin-right: 5px;
      }
      &.overlay {
        cursor: no-drop;
        &:after {
          content: "";
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          width: 100%;
          height: 100%;
          background: rgba(255, 255, 255, 0.5);
        }
      }
    }
  }
  .addressList {
    .form-check {
      padding-left: 0;
      label {
        padding-right: 50px;
      }
    }
    input.form-check-input {
      margin-left: 5px;
      width: auto;
    }
  }

  .addNew {
    font-size: 12px;
    border-bottom-width: 2px;
  }

  .billing {
    .d-flex {
      margin-bottom: 30px;
      justify-content: space-between;
    }
    h3 {
      margin: 0;
    }
    h4 {
      margin: 20px 0;
      font-size: 20px;
      color: rgba(0, 0, 0, 0.7);
    }
  }
  .back {
    background: none;
    border: none;
    color: #002366;
  }
  .billing-list {
    max-height: 400px;
    min-height: 100px;
    overflow-y: auto;
    margin: 0 0 20px;
    border: 1px solid rgba(112, 112, 112, 0.27);
    padding: 20px 30px 0;
    li {
      margin-bottom: 20px;
      &:last-child {
        margin-bottom: 0;
      }
      label {
        input {
          width: auto;
          margin-right: 5px;
        }
      }
    }
  }
  .purchaseContactDetails {
    margin: 40px 0 0;
    .orderInfo {
      padding-top: 30px;
      .list {
        li {
          display: flex;
          justify-content: space-between;
          font-size: 14px;
          margin-bottom: 5px;
          label {
            margin-bottom: 0px;
          }
        }
      }
    }
  }

  // pooja
  .address-inner {
    p {
      color: #9b9b9b;
      font-size: 15px;
      font-weight: 400;
      margin-bottom: 0;
      &:last-child {
        width: 42%;
      }
      a {
        color: #9b9b9b;
      }
    }
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
  }

  .billing-shipping-div {
    padding: 15px;
    flex: 1;

    .mainHeading {
      background: rgb(5 31 52 / 3%);
      text-align: center;
      h3 {
        padding: 0 !important;
        color: #081148;
        font-size: 20px;
        font-family: "Montserrat";
        position: relative;
        top: -10px;
      }
    }
    .common-form {
      background: rgb(5 31 52 / 3%);
      padding: 0 20px 10px 20px;
      box-shadow: none;
      max-height: 400px;
      overflow: auto;
      text-align: center;

      .billingDiv {
        & > div {
          padding: 5px 0;
          margin: 0;
          /* box-shadow: 4px 4px 6px rgb(0 0 0 / 16%); */

          .billIcon {
            text-align: right !important;
            svg {
              cursor: pointer;
            }
          }
          .billData {
            color: #888;
            font-size: 12px;
            text-align: left;
            h5 {
              margin: 0;
              font-size: 14px;
              padding: 0;
              display: flex;
              font-weight: 600;
            }
            a {
              color: #888;
              &:hover {
                color: #cb9274;
              }
            }
          }
        }
      }
    }
  }
  .address_new_btn {
    text-align: center;
    padding: 0 15px;
    margin: 10px 0;
    width: 100%;
  }

  .userName.billData {
    font-size: 22px;
    font-weight: 700;
    color: #cb9274 !important;
    line-height: normal;
    float: none;
    display: inline-block;
    vertical-align: top;
  }
  .billingDiv {
    position: relative;
    background: #fff;
    box-shadow: 9px 9px 6px rgb(0 0 0 / 16%);
    padding: 3px 0px;
    margin-bottom: 10px;
  }

  .billingDiv.active {
    border: 2px #cb9274 solid;
  }

  .address-common {
    background: #edeceb;
    padding: 0 30px 30px 30px;
    position: relative;
    &:before {
      position: absolute;
      content: "";
      width: 100%;
      height: 12px;
      background: #f6f4f2;
      left: 0;
    }
    h3 {
      text-align: center;
      font-size: 23px;
      color: #081148;
      font-weight: 500;
      margin-bottom: 20px;
      z-index: 1;
      position: relative;
    }
  }
  .billing-shipping-left {
    width: calc(100% - 475px);
    &.expand {
      width: 80%;
      margin: 10px;
    }
    .row {
      margin-left: -20px;
      margin-right: -20px;
    }
    .col-lg-6 {
      padding-left: 20px;
      padding-right: 20px;
    }
    .col-lg-12 {
      padding-left: 20px;
      padding-right: 20px;
    }
    .form-container {
      .row {
        margin-left: -25px;
        margin-right: -25px;
      }
      .col-lg-6 {
        padding-left: 25px;
        padding-right: 25px;
      }
      .col-lg-12 {
        padding-left: 25px;
        padding-right: 25px;
      }
    }
  }
  .address-item {
    background: #fff;
    box-shadow: 7px 7px 6px rgba(0, 0, 0, 0.16);
    padding: 10px 20px 10px 35px;
    position: relative;
    margin-bottom: 15px;
    &:focus {
      border: 3px solid red;
    }
    &:last-child {
      margin-bottom: 0;
    }
    h4 {
      color: #cb9274;
      font-size: 18px;
      font-weight: bold;
    }
  }
  .billing-shipping-right {
    position: relative;
    padding: 50px 0;
    &:before {
      position: absolute;
      content: "";
      height: 100%;
      border-right: 9999px solid rgba(203, 146, 116, 0.2);
      left: 60%;
      top: 0;
      bottom: 0;
      z-index: -1;
    }
  }

  .checkout-div {
    background: #fff;
    box-shadow: -8px 8px 6px rgba(0, 0, 0, 0.16);
    padding: 20px 30px 10px 30px;
    .orderInfo {
      .list {
        li {
          display: flex;
          justify-content: space-between;
          color: rgba(8, 17, 72, 0.6);
          label {
            font-weight: 600;
            margin-right: 70px;
            white-space: nowrap;
            em {
              color: #0080ff;
              font-style: normal;
            }
          }
          &:last-child {
            border-top: 4px solid rgba(201, 144, 115, 0.22);
            color: var(--heading-color);
            padding: 10px 0 0px;
            font-size: 23px;
            p {
              font-size: 23px;
              color: var(--heading-color);
              font-weight: 600;
            }
          }
        }
      }
    }
    button {
      width: 100%;
      text-transform: capitalize;
      font-size: 20px;
    }
    p.need-help {
      font-size: 17px;
      text-align: center;
      margin: 20px 0 10px;
      a {
        color: #0080ff;
        font-weight: bold;
      }
    }
  }

  .payment-method-page {
    .checkout-item {
      &:last-child {
        p {
          color: #081148;
          font-size: 23px;
          font-weight: 600;
        }
      }
    }
    p.need-help {
      color: #0080ff;
      font-weight: bold;
      a {
        color: #0080ff;
        font-weight: bold;
      }
    }
    .cart-summary {
      margin-top: 5px;
    }
    .checkout-div {
      padding: 0;
      box-shadow: none;
      background: none;
    }
    .order-summary {
      border-bottom: 1px solid rgba(112, 112, 112, 0.35);
      margin-top: 20px;
      padding-bottom: 20px;
      &:last-child {
        padding-bottom: 0;
        border: none;
      }
    }
    .order-detail-item {
      .qty {
        color: #081148;
        margin-bottom: 0;
      }
    }
  }
  .common-btn {
    background: #051f34;
    height: 49px;
    line-height: 49px;
    display: inline-block;
    text-align: center;
    color: #fff;
    font-size: 20px;
    font-weight: 600;
    padding-left: 20px;
    padding-right: 20px;
    border: none;
    &:hover {
      background: #0080ff;
      color: #fff;
      text-decoration: none;
    }
  }
  .btn-groups {
    .common-btn {
      &:first-child {
        width: 147px;
      }
      &:last-child {
        width: 225px;
      }
    }
    margin-top: 20px;
  }
  .edit-icon {
    position: absolute;
    top: 10px;
    right: 20px;
  }
  .address-list {
    max-height: 474px;
    overflow-y: scroll;
  }
  .shipping-order-info {
    padding: 70px 0;
    h4 {
      font-size: 30px;
      font-weight: 600;
      color: #000;
      &:nth-of-type(2) {
        margin-top: 35px;
      }
    }
    .container {
      max-width: 1200px;
    }
    .row {
      margin-left: -30px;
      margin-right: -3px;
    }
    .col-lg-6 {
      padding-left: 30px;
      padding-right: 30px;
    }
  }
  .common-form {
    position: relative;
    h4 {
      font-size: 30px;
      font-weight: 600;
      color: #000;
    }
    background: #fff;
    box-shadow: 9px 9px 6px rgba(0, 0, 0, 0.16);
    padding: 20px 50px;
  }
  .successful-payments {
    h4 {
      font-size: 30px;
      font-weight: 600;
      color: #081148;
    }
    position: relative;
    padding: 50px 0 70px 0;
    &:before {
      position: absolute;
      left: 0;
      width: 425px;
      background: #eddfd6;
      height: 100%;
      content: "";
      z-index: -1;
      top: 0;
    }
  }
  .payment-method {
    h4 {
      font-size: 30px;
      font-weight: 600;
      color: #081148;
      margin-bottom: 40px;
    }
    button {
      margin-top: 30px;
      max-width: 360px;
      width: 100%;
    }
    background: #fff;
    padding: 50px;
    box-shadow: 6px 3px 6px rgba(0, 0, 0, 0.16);
    width: calc(100% - 740px);
    margin-left: 40px;
  }
  .information {
    p {
      font-size: 25px;
      color: #000;
      margin-bottom: 5px;
      span {
        color: #3a50dc;
        font-weight: 600;
      }
      b {
        font-weight: 600;
      }
    }
  }
  .need-help-bottom {
    a {
      color: #0080ff;
      font-size: 30px;
      font-weight: 500;
    }
  }
  .order-info-div {
    display: flex;
    justify-content: space-between;
    &:last-of-type {
      margin-bottom: 25px;
    }
  }
  input[type="radio"] {
    opacity: 0;
    position: absolute;
    + {
      label {
        position: relative;
        color: #8a8a8a;
        font-size: 22px;
        line-height: 30px;
        font-weight: 300;
        padding-left: 30px;
        vertical-align: middle;
        margin: 0;
        &::before {
          content: " ";
          position: absolute;
          width: 23px;
          height: 23px;
          left: 0;
          top: 5px;
          border: 1px solid #919191;
          border-radius: 50%;
        }
      }
    }
    &:checked {
      + {
        label {
          &::before {
            background: url(${Radio}) center center no-repeat;
          }
        }
      }
    }
  }
  input[type="checkbox"] {
    opacity: 0;
    position: absolute;
    + {
      label {
        position: relative;
        color: #8a8a8a;
        font-size: 22px;
        line-height: 30px;
        font-weight: 300;
        padding-left: 30px;
        vertical-align: middle;
        margin: 0;
        &::before {
          content: " ";
          position: absolute;
          width: 23px;
          height: 23px;
          left: 0;
          top: 5px;
          border: 2px solid #000;
        }
      }
    }
    &:checked {
      + {
        label {
          &::before {
            background: url(${Checked}) center center no-repeat;
          }
        }
      }
    }
  }
  .radio-btn {
    display: inline-block;
    margin-left: 30px;
    cursor: pointer;
  }
  .form-control {
    border: none;
    border-bottom: 1px solid rgba(0, 0, 0, 0.4);
    border-radius: 0;
    padding-left: 0;
    font-size: 22px;
    color: #8a8a8a;
    &.PhoneInput {
      border: none;
    }
    &:focus {
      outline: none;
      box-shadow: none;
      border-color: rgba(0, 0, 0, 0.4);
    }
  }
  .checkbox {
    display: inline-block;
    margin-left: 20px;
    position: absolute;
    bottom: 9.4%;
    right: 3%;
  }
  .disapbled {
    opacity: 0.5;
  }
  .select-container {
    .form-control {
      color: #000;
    }
  }
  .order-info {
    width: 100%;
    button,
    .checkout-item {
      display: none;
    }
    .orderInfo {
      .list {
        li {
          display: flex;
          justify-content: space-between;
        }
      }
    }
  }
  .invoice-number {
    font-size: 18px;
    color: rgba(8, 17, 72, 0.4);
  }
  .s-payments-inner {
    display: flex;
    justify-content: space-between;
  }
  .payment-processed-inner {
    img {
      max-width: 750px;
    }
  }
  .payment-processed {
    h5 {
      font-size: 35px;
      font-weight: 400;
      color: #000;
      margin-top: 25px;
    }
    p {
      font-size: 22px;
      color: #000;
    }
    .common-btn {
      background: #081148;
      &:hover {
        background: #0080ff;
      }
    }
  }
  .order-summary {
    h5 {
      color: #081148;
      font-size: 20px;
      font-weight: 600;
      margin-bottom: 15px;
      img {
        margin-right: 5px;
      }
    }
    margin-top: 45px;
    p {
      a {
        color: #9b9b9b;
      }
    }
    h6 {
      color: #081148;
      font-size: 15px;
      font-weight: 600;
    }
  }
  .price {
    color: #081148;
    font-size: 15px;
    font-weight: 600;
  }
  .cart-summary {
    .order-detail {
      display: flex;
      justify-content: space-between;
    }
  }
  .qty {
    color: #081148;
  }
  .billing {
    .order-detail-item {
      width: calc(50% - 2px);
      display: inline-block;
      vertical-align: top;
    }
  }
  .shipping {
    .order-detail-item {
      width: calc(50% - 2px);
      display: inline-block;
      vertical-align: top;
    }
  }
  .payment-radio-btns {
    .radio-btn {
      margin-left: 0;
      display: block;
      margin-bottom: 15px;
    }
    input[type="radio"] {
      + {
        label {
          color: #081148;
          font-weight: 500;
        }
      }
    }
  }
  @media {
    .form-control {
      font-size: 16px;
    }
    input[type="radio"] {
      + {
        label {
          font-size: 16px;
          &::before {
            top: 3px;
          }
        }
      }
    }
    input[type="checkbox"] {
      + {
        label {
          color: #004cff;
          font-weight: 500;
          font-size: 16px;
          &::before {
            top: 3px;
          }
        }
      }
    }
    .common-form {
      padding: 15px 30px;

      h4 {
        font-size: 24px;
      }
    }
    .container {
      max-width: 1400px;
    }
    .address-item {
      padding: 10px 20px 10px 20px;
      h4 {
        font-size: 15px;
      }
    }
    .address-inner {
      p {
        font-size: 13px;
      }
    }
    .billing-shipping-right {
      p {
        font-size: 15px;
        i {
          font-size: 11px;
        }
      }
      .checkout-item {
        &:nth-last-child(3) {
          p {
            font-size: 16px;
          }
        }
      }
    }
    @media (max-width: 1500px) {
      .checkout-div {
        padding: 20px 20px 10px 20px;
      }
    }
    .address-common {
      padding: 0 20px 20px 20px;
      h3 {
        font-size: 20px;
      }
    }
    .billing-shipping-left {
      width: calc(100% - 400px);
      margin: 0 0 50px;
      .row {
        margin-left: -10px;
        margin-right: -10px;
      }
      .col-lg-6 {
        padding-left: 10px;
        padding-right: 10px;
      }
      .col-lg-12 {
        padding-left: 10px;
        padding-right: 10px;
      }
      h2 {
        font-size: 24px;
      }
    }
    .edit-icon {
      img {
        width: 15px;
      }
    }
    .checkout-item {
      p {
        font-size: 15px;
        i {
          font-size: 11px;
        }
      }
    }
    .information {
      p {
        font-size: 15px;
      }
    }
    .payment-method-page {
      .checkout-item {
        &:last-child {
          p {
            font-size: 16px;
          }
        }
      }
    }
    .common-btn {
      height: 45px;
      line-height: 45px;
      font-size: 16px;
      font-weight: 600;
    }
    .shipping-order-info {
      h4 {
        font-size: 24px;
      }
      .container {
        max-width: 900px;
      }
    }
    .successful-payments {
      h4 {
        font-size: 24px;
      }
      &:before {
        width: 350px;
      }
    }
    .payment-method {
      h4 {
        font-size: 24px;
      }
      width: calc(100% - 520px);
      margin-left: 40px;
      padding: 30px;
      button {
        max-width: 260px;
      }
    }
    .btn-groups {
      .common-btn {
        &:first-child {
          width: 120px;
        }
        &:last-child {
          width: 200px;
        }
      }
    }
    .need-help-bottom {
      a {
        font-size: 18px;
        font-weight: 600;
      }
    }

    .invoice-number {
      font-size: 14px;
    }
    .payment-processed {
      h5 {
        font-size: 26px;
        margin-top: 15px;
      }
      p {
        font-size: 16px;
      }
    }
    .order-summary {
      h5 {
        font-size: 16px;
        margin-bottom: 10px;
        img {
          max-width: 20px;
        }
      }
      h6 {
        font-size: 13px;
      }
      margin-top: 25px;
    }
    .price {
      font-size: 13px;
    }
  }
`;
