import styled from "styled-components";

import HomeBan from "../assets/images/home/banner.png";
import ArrowLeft from "../assets/images/home/arrow-left.svg";
import ArrowRight from "../assets/images/home/arrow-right.svg";
import WhyRadix from "../assets/images/home/why-radix.png";

// mobile
import WhyRadixMob from "../assets/images/home/why-radix-mob.png";
import Pexels from "../assets/images/home/pexels-bck.png";

export const HomeWrap = styled.div`
  .banner {
    background: url(${HomeBan}) no-repeat;
    height: 100vh;
    background-size: cover;
    background-position: center;
    position: relative;
    overflow-x: hidden;
  }

  .banner-caption {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    width: 100%;
  }

  .banner-caption-top,
  .banner-caption-bottom {
    justify-content: space-between;
    position: relative;
  }

  .banner-caption-top {
    a {
      font-family: var(--sort-font);
      font-size: 50px;
      line-height: 50px;
      color: #ffffff;
      margin-left: 30px;
      margin-right: 30px;
    }

    &::before {
      position: absolute;
      width: 100%;
      height: 6px;
      content: "";
      background: rgba(203, 146, 116, 0.3);
      top: 50%;
      transform: translateY(-50%);
      margin-top: -5px;
    }

    .top-inner {
      -moz-animation: marquee 25s linear infinite;
      -webkit-animation: marquee 25s linear infinite;
      animation: marquee 25s linear infinite;
      display: flex;
      justify-content: space-between;
      width: 200%;
    }
  }

  .banner-caption-bottom {
    margin-top: 20px;

    a {
      font-size: 40px;
      line-height: 50px;
      color: #ffffff;
      font-weight: 500;
    }

    &::before {
      position: absolute;
      width: 100%;
      height: 6px;
      content: "";
      background: rgba(203, 146, 116, 0.3);
      top: 50%;
      transform: translateY(-50%);
    }

    .bottom-inner {
      -moz-animation: marqueebot 25s linear infinite;
      -webkit-animation: marqueebot 25s linear infinite;
      animation: marqueebot 25s linear infinite;
      display: flex;
      justify-content: space-between;
      width: 200%;
    }
  }

  .best-selling-inner {
    display: flex;
    justify-content: space-between;
    position: relative;

    &:before {
      position: absolute;
      content: "";
      left: 0;
      width: 486px;
      height: 1px;
      top: 80px;
      background: rgba(203, 146, 116, 0.22);
    }

    &:after {
      position: absolute;
      content: "";
      right: 0;
      width: 65%;
      height: 1px;
      top: 161px;
      background: rgba(203, 146, 116, 0.22);
      z-index: -1;
    }
  }

  .best-selling-pic {
    max-width: 445px;
    width: 100%;
    margin-top: 130px;
  }

  .best-selling-products {
    width: calc(100% - 445px);
    padding-left: 30px;
    position: relative;
  }

  .best-selling-products-container {
    display: flex;
    justify-content: space-between;
  }

  .products-heading {
    margin: 60px 0 30px 0;
  }

  .product-item {
    background: #fff;
    padding: 65px 25px 28px 25px;

    h4 {
      color: var(--primary);
      font-size: 19px;
      font-weight: 600;
      margin-bottom: 0;
      margin-top: 55px;
    }
  }

  .product-weight {
    font-size: 13px;
    font-weight: 600;
    color: #707070;
    display: block;
    margin-top: 8px;
    margin-bottom: 9px;
  }

  .price-container {
    font-size: 22px;
    color: #000000;
    font-weight: bold;

    strike {
      opacity: 0.1;
      margin-right: 5px;
    }
  }

  .product-img {
    img {
      max-height: 200px;
    }
  }

  .best-selling {
    padding: 40px 0 0 0;

    h3 {
      margin-bottom: -35px;
      background: #f6f4f2;
      display: inline-block;

      span {
        margin-right: 0px;
      }
    }
  }

  .arrow-custom {
    position: absolute;
    line-height: inherit;
    bottom: -8px;

    a {
      display: inline-block;
      width: 57px;
      height: 57px;
    }

    .prev {
      background: url(${ArrowLeft}) no-repeat var(--primary);
      background-position: center;
    }

    .prev:hover {
      background: url(${ArrowLeft}) no-repeat var(--heading-color);
      background-position: center;
    }

    .next {
      background: url(${ArrowRight}) no-repeat var(--primary);
      background-position: center;
      margin-left: 25px;
    }

    .next:hover {
      background: url(${ArrowRight}) no-repeat var(--heading-color);
      background-position: center;
    }
  }

  .loose-diamonds {
    padding: 190px 0 222px 0;
  }

  .loose-diamonds-inner {
    display: flex;
    justify-content: space-between;
    padding-left: 100px;

    h3 {
      margin-bottom: -35px;
    }

    .large-pic {
      position: relative;

      .active-img {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
      }
    }
  }

  .loose-diamonds-list {
    ul {
      list-style: none;
      display: flex;
      align-items: flex-end;

      li {
        margin-right: 50px;
        text-align: center;
      }
    }

    h4 {
      font-size: 20px;
      color: #000000;
      font-weight: 500;
      margin-top: 15px;
    }
  }

  .loose-diamond-category {
    position: relative;

    .arrow-custom {
      position: absolute;
      line-height: inherit;
      bottom: 50px;
    }
  }

  .limited-availability-inner {
    padding-left: 100px;
    display: grid;
    grid-gap: 45px;
    grid-template-columns: [col1-start] 18% [col2-start] 18% [col3-start] 18% [col4-start] 37.5% [col4-end];
    grid-template-rows: [row1-start] auto [row2-start] auto [row2-end];
    width: 100%;
    justify-content: space-between;
  }

  .col-1-txt {
    grid-column: col1-start / col3-start;
    grid-row: row1-start;
    padding-left: 0;

    p {
      font-size: 24px;
      line-height: 43px;
      font-style: italic;
      max-width: 90%;
    }

    h3 {
      margin-bottom: -15px;

      span {
        top: 35px;
        margin-right: -45px;
      }
    }
    p {
      max-width: 100% !important;
      font-size: 14px;
      color: #707070;
      line-height: 1.6;
      margin: 0 0 30px 0;
      text-align: center;
    }
  }

  .col-2-txt {
    grid-column: col3-start;
    grid-row: row1-start;
  }

  .col-3-img {
    grid-column: col4-start;
    grid-row: row1-start / row2-end;

    img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
  }

  .col-1-txt-r2 {
    grid-column: col1-start;
    grid-row: row2-start;
  }

  .col-2-txt-r2 {
    grid-column: col2-start;
    grid-row: row2-start;
  }

  .col-3-txt-r2 {
    grid-column: col3-start;
    grid-row: row2-start;
  }

  .limited-availability-outer {
    margin-left: -50px;
    margin-right: -165px;
  }

  .limited-availability {
    padding-bottom: 220px;
  }

  .why-radix {
    background: url(${WhyRadix}) no-repeat;
    background-position: center;
    background-size: cover;
    padding: 130px 0 95px 0;

    h4 {
      font-size: 51px;
      color: #fff;
      font-weight: 600;
      position: relative;
      display: inline-block;

      &:before {
        position: absolute;
        height: 23px;
        width: 98%;
        content: "";
        background: rgba(0, 0, 0, 0.2);
        bottom: 0;
        left: 0;
      }
    }

    p {
      font-size: 26px;
      color: #000;
      font-weight: bold;
      font-style: italic;
      margin-top: 25px;
      margin-bottom: 40px;
    }

    a.read-more {
      font-size: 36px;
      color: #fff;
      font-weight: bold;
      display: inline-block;
    }
  }

  .free-shipping {
    background: url(../images/free-shipping.png) no-repeat #fff;
    background-position-x: 0%;
    background-position-y: 0%;
    padding: 23px 0 1px 0;
    background-position: center;

    ul {
      list-style: none;
      display: flex;
      justify-content: space-between;

      li {
        span {
          font-size: 18px;
          font-weight: 600;
          color: #000000;
          margin-left: 10px;

          a {
            color: #000;
          }
        }
      }
    }
  }

  .lab-created {
    padding-top: 60px;
    padding-bottom: 190px;
    position: relative;

    h3 {
      span {
        top: 55px;
        margin-right: 5px;
      }
    }
  }

  .lab-created-inner {
    display: flex;
    align-items: end;
  }

  .lab-item {
    margin-bottom: 30px;

    &:last-child {
      margin-bottom: 0;
    }

    .lab-icon {
      display: inline-block;
      max-width: 72px;
      width: 100%;
      text-align: center;
      margin-top: 45px;
    }

    .lab-text-info {
      display: inline-block;
      width: calc(100% - 80px);
      vertical-align: top;
      padding-left: 47px;

      h5 {
        font-size: 35px;
        color: #000;
        font-weight: 600;
      }

      p {
        font-size: 25px;
        line-height: 50px;
        font-style: italic;
        padding-top: 7px;
      }
    }
  }

  .lab-created-list {
    margin-top: 65px;
  }

  .left-image {
    position: absolute;
    left: 0;
    bottom: 220px;
  }

  .lab-info {
    padding-left: 670px;
  }

  .recently-viewed-products {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding-left: 95px;
    padding-right: 95px;

    .common-heading {
      h3 {
        font-size: 60px;
        position: relative;

        span {
          top: 35px;
          margin-right: -38px;
        }

        b {
          font-weight: 400;
          position: absolute;
          right: -114px;
          bottom: 0;
        }
      }
    }
  }

  .recently-viewed {
    padding-bottom: 180px;
  }

  .recentView {
    padding: 0 0 80px 0;
    .react-multi-carousel-list {
      .react-multi-carousel-item {
        margin: 0;
        padding: 0 20px;

        .box {
          width: 100%;
        }
      }
    }
  }

  /***********css marquee*****/
  @keyframes marquee {
    0% {
      transform: translateX(0);
    }

    100% {
      transform: translateX(-100%);
    }
  }

  @keyframes marqueebot {
    0% {
      transform: translateX(0);
    }

    100% {
      transform: translateX(100%);
    }
  }

  /*****************media queries*********/
  @media (min-width: 1200px) {
    .container {
      max-width: 1200px;
    }
  }

  @media (min-width: 1500px) {
    .container {
      max-width: 1440px;
    }
  }

  @media (min-width: 1700px) {
    .container {
      max-width: 1600px;
    }
  }

  @media (min-width: 2000px) {
    .container {
      max-width: 1900px;
    }
  }

  @media (min-width: 2200px) {
    .best-selling-pic {
      max-width: 600px;

      img {
        width: 100%;
        max-height: 700px;
        object-fit: cover;
      }
    }

    .best-selling-products {
      width: calc(100% - 600px);
      padding-left: 60px;
    }

    .loose-diamonds-inner {
      justify-content: space-evenly;
    }

    .loose-diamonds-list ul li {
      margin-right: 80px;
    }

    .best-selling-inner::before {
      width: 680px;
    }
  }

  @media (max-width: 1700px) {
    .common-heading {
      h3 {
        font-size: 35px;

        span {
          font-size: 130px;
        }
      }
    }

    .best-selling h3 {
      margin-bottom: -10px;
    }

    .best-selling-inner {
      &:before {
        top: 49px;
      }

      &:after {
        width: 52%;
        top: 98px;
      }
    }

    .best-selling-pic {
      max-width: 330px;
      margin-top: 80px;

      img {
        width: 100%;
      }
    }

    .best-selling-products {
      width: calc(100% - 330px);
    }

    .product-item {
      padding: 25px 20px 20px 20px;
    }

    .product-item {
      h4 {
        font-size: 15px;
        margin-top: 25px;
      }

      .product-weight {
        font-size: 11px;
        margin-top: 5px;
        margin-bottom: 5px;
      }

      .price-container {
        font-size: 18px;
      }
    }

    .arrow-custom {
      a {
        width: 42px;
        height: 43px;
      }

      .prev,
      .prev:hover,
      .next,
      .next:hover {
        background-size: 15px;
      }

      .next {
        margin-left: 15px;
      }
    }

    .banner-caption-top {
      a {
        font-size: 35px;
        line-height: 35px;
        margin-left: 20px;
        margin-right: 20px;
      }
    }

    .banner-caption-bottom {
      a {
        font-size: 25px;
        line-height: 40px;
      }
    }

    .gallery-item-container {
      margin-left: -13px;
      margin-right: -13px;

      .gallery-item {
        margin-left: 13px;
        margin-right: 13px;
        width: calc(20% - 32px);

        h6 {
          font-size: 16px;
          line-height: 28px;
        }
      }
    }

    .loose-diamonds-inner {
      .large-pic img {
        max-width: 300px;
      }
    }

    .loose-diamonds-list {
      h4 {
        font-size: 15px;
        margin-top: 10px;
      }

      img {
        max-height: 50px;
      }

      ul li {
        margin-right: 40px;
      }
    }

    .loose-diamond-category {
      padding-left: 20px;

      .arrow-custom {
        bottom: 0;
      }
    }

    .product-img img {
      max-height: 160px;
    }

    .loose-diamonds {
      padding: 80px 0 80px 0;

      .loose-diamonds-inner {
        h3 {
          margin-bottom: -10px;
        }
      }
    }

    .limited-availability {
      padding-bottom: 80px;

      .limited-availability-outer {
        margin-left: 0;
        margin-right: -90px;
      }

      .limited-availability-inner {
        grid-gap: 30px;
        padding-left: 0;

        .col-1-txt {
          h3 span {
            top: 20px;
            margin-right: -25px;
          }

          p {
            font-size: 18px;
            line-height: 34px;
            font-style: italic;
            max-width: 90%;
          }
        }
      }
    }

    .why-radix {
      padding: 80px 0 70px 0;

      h4 {
        font-size: 40px;

        &:before {
          height: 15px;
        }
      }

      p {
        font-size: 18px;
        margin-top: 15px;
        margin-bottom: 20px;
      }

      a.read-more {
        font-size: 20px;
      }
    }

    .free-shipping {
      ul li {
        img {
          max-height: 50px;
        }

        span {
          font-size: 15px;
        }
      }
    }

    .lab-created {
      padding-top: 60px;
      padding-bottom: 80px;

      .left-image {
        bottom: 100px;
      }

      .lab-created-list {
        margin-top: 40px;
      }

      .left-image {
        img {
          max-width: 470px;
        }
      }

      .lab-info {
        padding-left: 470px;
      }

      h3 span {
        top: 32px;
        margin-right: 5px;
      }
    }

    .lab-item {
      .lab-icon {
        max-width: 60px;
        margin-top: 30px;

        svg {
          width: 50px;
          height: auto;
        }
      }

      .lab-text-info {
        padding-left: 20px;
        width: calc(100% - 67px);

        h5 {
          font-size: 20px;
        }

        p {
          font-size: 18px;
          line-height: 34px;
          padding-top: 4px;
        }
      }
    }

    .recently-viewed {
      padding-bottom: 80px;

      .recently-viewed-products {
        .common-heading {
          h3 {
            font-size: 35px;

            b {
              right: -65px;
            }

            span {
              top: 22px;
              margin-right: -20px;
            }
          }
        }
      }
    }
  }

  @media (max-width: 1024px) {
    .loose-diamonds-list {
      ul {
        li {
          margin-right: 0;
        }
      }
    }
    .container,
    .container-lg,
    .container-md,
    .container-sm {
      max-width: 100% !important;
    }
  }

  @media (max-width: 767px) {
    .lab-created {
      padding: 30px 0 60px 0;
      .lab-created-list {
        margin-top: 20px;
      }
      .lab-item {
        position: relative;
        padding: 0 0 0 70px;

        .lab-icon {
          display: inline-block;
          width: 70px;
          height: 70px;
          line-height: 70px;
          box-shadow: 0 0 14px 6px #ece0d8;
          border-radius: 50%;
          max-width: 100%;
          margin: 0;
          position: absolute;
          left: 0;
          top: 25px;

          svg {
            width: 40px;
          }
        }
        .lab-text-info {
          padding: 0 0 0 15px;
          width: 100%;
          h5 {
            font-size: 16px;
          }
          p {
            font-size: 14px;
            color: #707070;
            line-height: normal;
          }
        }
      }
      .left-image {
        display: none;
      }
      .lab-info {
        padding: 0;
        .common-heading {
          h3 {
            line-height: normal;
            font-size: 18px;

            span {
              font-size: 88px;
            }
          }
        }
      }
    }

    .usp {
      background: transparent;
      margin: 40px 0 0 0;
      & > .container {
        padding: 0 20px;
      }

      ul {
        box-shadow: 0 0 14px 6px #ece0d8;
        flex-wrap: wrap;
        padding: 15px;
        li {
          flex: 50%;
          padding: 10px;

          svg {
            max-width: 50px;
            path {
              fill: #000;
            }
          }
          h5 {
            color: var(--primary);
            font-size: 12px;
            span {
              color: var(--primary);
            }
          }
        }
      }
    }

    .recentView {
      padding: 0 0 20px 0;

      .d-flex.align-items-center {
        display: block !important;
        h2 {
          font-size: 24px;
          line-height: normal;
          justify-content: center;
          margin: 40px 0 0 0;
          br {
            display: none;
          }
          b {
            margin-top: 60px;
          }
          span {
            font-size: 80px;
            line-height: normal;
          }
        }
        ul {
          li {
            width: 200px !important;
            padding: 15px 10px;
            .box {
              padding: 20px 15px 0 15px;
              background: transparent;
              box-shadow: 0 0 14px 6px #ece0d8;

              h3 {
                font-size: 15px;
                margin: 20px 0 10px 0;
              }
              h4 {
                font-size: 12px;
              }
            }
          }
        }
      }
    }

    .why-radix {
      background: url(${WhyRadixMob}) no-repeat;
      background-position: center;
      background-size: cover;
      padding: 40px 0;

      h4 {
        font-size: 24px;
        color: #000;
        text-transform: uppercase;

        &:before {
          background: rgb(166 184 213 / 50%);
          height: 12px;
        }
      }
      p {
        font-size: 16px;
        font-weight: 600;
        margin: 12px 0;
        max-width: 300px;
      }
      a.read-more {
        color: var(--primary);
        font-size: 14px;
        padding: 15px;
        position: relative;
        z-index: 1;

        &:before {
          content: "Read";
          font-size: 44px;
          position: absolute;
          top: 0;
          left: 5px;
          font-family: var(--ed-font);
          color: #d4d4d4;
          line-height: normal;
          z-index: -1;
        }
      }
    }

    .limited-availability {
      .limited-availability-outer {
        margin: 0;

        .limited-availability-inner {
          display: block;

          h3 {
            margin: 0;
            justify-content: center;
            font-size: 24px;

            span {
              font-size: 120px;
              margin-top: -50px;
            }
          }

          .limited-slide {
            display: inline-block;
            width: 200px !important;
            padding: 15px 10px;

            .product-item {
              padding: 20px 15px 0 15px;
              background: transparent;
              box-shadow: 0 0 14px 6px #ece0d8;

              .product-img {
                img {
                  width: 100%;
                  height: auto;
                }
              }
            }
          }

          p {
            font-size: 14px;
            color: #707070;
            line-height: 1.6;
          }

          .col-3-img {
            display: none;
          }
        }
      }
    }

    .loose-diamonds {
      .loose-diamonds-inner {
        display: block;
        padding: 0;

        .loose-diamond-category {
          padding: 0 15px;

          h3 {
            font-size: 24px;
            line-height: normal;

            span {
              font-size: 120px;
            }
          }
        }
        .arrow-custom {
          a {
            background-color: transparent;
            box-shadow: 0 0 14px 6px #ece0d8;
            border-radius: 50%;
            &:hover {
            }
          }
        }
      }
      .large-pic {
        display: none;
      }
    }

    .need-help {
      .need-help-heading {
        padding: 0 15px;

        h4 {
          font-size: 22px;
        }
        p {
          font-size: 14px;
        }
      }

      .need-help-info {
        background: transparent;
        height: auto;
        line-height: normal;

        .need-help-inner {
          padding: 15px 5px;
          box-shadow: 0 10px 14px 6px #ece0d8;

          ul {
            display: block;
            text-align: center;
            li {
              display: inline-block;
              padding: 5px;

              svg {
                width: 22px;
              }
              a {
                font-size: 15px;
                margin-left: 10px;
              }
            }
          }
        }
      }
    }

    .create-your-ring {
      background: transparent;
      box-shadow: 0 0 14px 6px #ece0d8;
      position: relative;
      left: 15px;
      width: calc(100% - 30px);
      padding: 30px 0;

      .create-your-ring-inner {
        display: block;

        .create-your-ring-left {
          h3 {
            font-size: 22px;
            justify-content: center;
            span {
              font-size: 96px;
            }
          }
          p {
            font-size: 14px;
            color: #707070;
            line-height: 1.6;
          }
          .call-expert {
            width: 100%;
            text-align: center;
            font-size: 20px;
            a {
              font-size: 20px;
              margin-left: 8px;
            }
          }
        }
        .create-ring-right {
          margin: 30px 0 0 0;
          display: block;
          box-shadow: 0 0 14px 6px #ece0d8;
          position: relative;
          left: 10px;
          width: calc(100% - 20px);

          .ring-options {
            margin: 0;
            padding: 30px 15px;

            button {
              font-size: 16px;
            }
          }
        }
      }
    }

    .best-selling {
      .best-selling-inner {
        display: block;

        &:before,
        &:after {
          display: none;
        }
        .best-selling-pic {
          display: none;
        }
        .best-selling-products {
          width: 100%;
          padding: 0 15px;

          .products-heading {
            margin: 30px 0;
            h3 {
              margin: 0;
              font-size: 24px;
              width: 100%;
              text-align: center;
              span {
                font-size: 108px;
                position: relative;
                top: 20px;
              }
            }
          }
          .best-selling-products-container {
            display: block;
            width: 200px !important;
            padding: 15px 10px;
            .product-item {
              padding: 20px 15px 0 15px;
              background: transparent;
              box-shadow: 0 0 14px 6px #ece0d8;

              .product-img {
                img {
                  max-width: 100%;
                  height: auto;
                }
              }
            }
          }
        }
      }
    }
    .explore-more.home {
      margin: 30px 0;
      &:before {
        display: none;
      }
      .explore-more-inner {
        margin: 0;
        .explore-more-left {
          h3 {
            margin: 0;
            font-size: 24px;
            margin: -40px 0 40px 0;
            span {
              top: 60px;
              font-size: 98px;
              line-height: normal;
            }
          }
        }
        .explore-gallery {
          display: block;
          .explore-gallery-inner {
            grid-template-columns: repeat(2, 1fr);
            grid-gap: 15px;
            justify-content: start;

            .gallery-item {
              clear: both;
              .gallery-img {
                border: 0;
                padding: 5px;
                box-shadow: 0 0 14px 6px #ece0d8;
                img {
                  margin: 0;
                  max-width: 100%;
                }
              }
              h6 {
                font-size: 14px;
                margin: 15px 0;
                font-weight: 600;
                line-height: normal;
                position: relative;
                left: 50%;
                transform: translateX(-50%);
                -webkit-transform: translateX(-50%);
                -moz-transform: translateX(-50%);
                -ms-transform: translateX(-50%);
              }
            }
          }
        }
      }
    }
    .banner {
      display: none;
    }
    .banner-mobile {
      .ban_top {
        background: url(${Pexels}) no-repeat;
        background-position: center;
        background-size: cover;
        padding: 15px 0;
        margin: 15px 0;

        p {
          max-width: 240px;
        color: #666;
  font-size: 12px;
a {
  display: inline-block;
  color: #004CFF;
  font-size: 13px;
  font-style: italic;
  font-weight: 500;
}
}
      }
      .ban_text {
color: #B1B1B1;
font-size: 15px;
span {
  font-size: 21px;
  color: #CB9274;
  font-weight: bold;
position: relative;

&:before {
    content: "";
    height: 4px;
    width: 100%;
    position: absolute;
    left: 0;
    bottom: 0;
    background: #fff;
}
}
      }
.ban_btm {
    margin: 20px 0 0 0;
.ban_btm_left {
    display: inline-block;
    max-width: 220px;
    vertical-align: top;
    width: 100%;
h4 {
color: #051F34;
font-size: 18px;
font-style: italic;
margin: 0;
}
p {
color: #B1B1B1;
font-size: 15px;
}
}
a {
display: inline-block;
    font-size: 16px;
position: relative;
z-index: 9;
cursor: pointer;
    font-weight: 700;
    color: var(--primary);
    font-family: var(--my-font-family);
    line-height: normal;
&:before {
    content: "Shop Now";
    position: absolute;
    left: 0;
    right: 0;
    bottom: 0;
    font-size: 32px;
    min-width: 120px;
    top: -20px;
    font-family: var(--ed-font);
    color: rgba(227,219,212,0.34);
    z-index: -1;
}
}
}
    }
  }
`;
