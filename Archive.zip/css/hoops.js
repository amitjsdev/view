import styled from "styled-components";

export const Hoops = styled.div`
  .hoopSize {
    .container {
      & > div {
        &:not(:nth-of-type(1)) {
          margin-top: -80px;
        }
      }
    }
    .flex-row-reverse {
      .left {
        &:before {
          border-right: 9999px solid rgba(203, 146, 116, 0.22);
          border-left: 0;
          left: 6%;
          right: 0;
        }
      }
    }
    .left {
      padding: 40px 0;
      position: relative;
      flex: 0 0 50%;
      max-width: 50%;
      &:before {
        content: "";
        border-left: 9999px solid rgba(203, 146, 116, 0.22);
        right: 6%;
        position: absolute;
        top: 0;
        height: 100%;
        z-index: -1;
        @media (min-width: 2000px) {
          right: 20%;
        }
      }
      .image {
        span {
          position: relative;
          display: inline-block;
          width: 100%;
          h2 {
            position: absolute;
            bottom: 10%;
            left: 0;
            right: 0;
            width: 100%;
            text-align: center;
            background: rgba(255, 255, 255, 0.6);
            padding: 10px 0;
            text-transform: capitalize;
            font-size: 36px;
            font-weight: 500;
            letter-spacing: 1px;
            margin: 0;
          }
        }
        img {
          width: 100%;
        }
      }
    }
    .right {
      flex: 0 0 50%;
      text-align: center;
      max-width: 50%;
      .products {
        text-align: center;
      }
    }
    button {
      &:before {
        content: "Starting From";
      }
    }
  }

  .prongType {
    padding: 0 0 150px;
    .type {
      h2 {
        color: var(--heading-color);
        font-family: var(--sort-font);
        font-size: 40px;
        display: flex;
        align-items: center;
        margin: 0;
        span {
          font-family: var(--prist-font);
          font-size: 174px;
          line-height: 180px;
          color: var(--primary);
        }
      }
      .type-list {
        display: grid;
        grid-template-columns: 1fr 1fr 1fr;
        justify-content: center;
        align-items: center;
        text-align: center;
        grid-row-gap: 20px;
        li {
          span {
            display: inline-block;
            width: 100%;
            margin-bottom: -25px;
          }
          .setting {
            display: inline-block;
            background: #051f34;
            color: #fff;
            font-size: 19px;
            font-weight: 500;
            padding: 10px;
            margin-bottom: -10px;
            border: none;
            &:before {
              display: none;
            }
          }
        }
      }
      button {
        font-size: 26px;
        &:before {
          content: "Shop All";
        }
      }
    }
  }
`;

export const Listing = styled.div`
  .banner {
    background: rgba(203, 146, 116, 0.22);
    position: relative;
    padding: 40px 0;
    margin-bottom: 40px;
    height: 100%;
    h1 {
      color: rgba(0, 0, 0, 0.05);
      right: 0;
      font-size: 13rem;
      position: absolute;
      top: 0;
      line-height: 170px;
    }
    h4 {
      font-style: italic;
      font-size: 24px;
      line-height: 43px;
      color: #707070;
    }
    h2 {
      font-family: var(--sort-font);
      color: var(--heading-color);
      font-size: 50px;
    }
    .customButton {
      padding: 0;
      line-height: normal;
      &:before {
        display: none;
      }
    }
  }
  .productListing {
    grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
    grid-gap: 40px;
  }
  .show-more {
    position: relative;
    text-align: right;
    margin: 60px 0 0;
    &:after {
      content: "";
      border-top: 1px solid rgba(203, 146, 116, 0.23);
      width: 100%;
      height: 1px;
      position: absolute;
      top: 50%;
      left: 0%;
      bottom: 0;
    }
    &:before {
      content: "";
      border-top: 1px solid rgba(203, 146, 116, 0.23);
      width: 100%;
      height: 1px;
      position: absolute;
      top: 50%;
      right: 100%;
      bottom: 0;
    }
    button {
      background: #f6f4f2;
      z-index: 99;
      &:before {
        content: "Show More";
      }
    }
  }
  .products-listing {
    background: #fff;
    padding: 20px;
    img {
      cursor: pointer;
    }

    .icons {
      display: flex;
      li {
        border: 1px solid #c7c7c7;
        width: 25px;
        height: 25px;
        display: inline-block;
        font-size: 14px;
        margin: 0 5px 0 0;
        cursor: pointer;

        &.rose {
          background: rgb(200, 200, 200);
          background: linear-gradient(
            0deg,
            rgba(200, 200, 200, 0) 0%,
            rgba(255, 0, 119, 0.3) 100%
          );
        }
        &.white {
          background: rgb(254, 254, 254);
          background: linear-gradient(
            0deg,
            rgba(254, 254, 254, 1) 0%,
            rgba(236, 236, 236, 1) 100%
          );
        }
        &.yellow {
          background: rgb(239, 255, 10);
          background: linear-gradient(
            0deg,
            rgba(239, 255, 10, 0) 0%,
            rgba(249, 208, 0, 0.35) 100%
          );
        }
      }
    }
    h2 {
      color: #cb9274;
      font-size: 19px;
      font-weight: 500;
      cursor: pointer;
    }
    h4 {
      font-weight: 500;
      font-size: 13px;
      padding: 5px 0;
      color: #707070;
    }
    h5 {
      font-size: 22px;
      font-weight: 700;
      color: #000;
      padding: 10px 0 0;
    }
  }
  span.chip.false.false {
    display: none;
  }
`;
