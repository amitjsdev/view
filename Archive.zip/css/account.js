import styled from "styled-components";

export const UserAccountWrap = styled.div `
  .my-account {
    background: #f6f4f2;

    .form-control:focus::placeholder {
      opacity: 0;
    }

    /************floating labels*******/
    .form-group {
      position: relative;

      .floating-input + label,
      .floating-select + label {
        color: #8a8a8a;
        font-size: 22px;
        font-weight: normal;
        position: absolute;
        pointer-events: none;
        left: 52px;
        top: 5px;
        transition: 0.2s ease all;
        -moz-transition: 0.2s ease all;
        -webkit-transition: 0.2s ease all;

        @media (max-width: 1700px) {
          font-size: 14px;
          left: 20px;
        }
      }
    }

    .floating-input,
    .floating-select {
      display: block;
      width: 100%;
    }

    .floating-input:focus,
    .floating-select:focus {
      outline: none;
      border-bottom: 2px solid #5264ae;
    }

    .floating-input:focus ~ label,
    .floating-input:not(:placeholder-shown) ~ label {
      top: -18px;
      font-size: 14px;
      color: #000;
      font-weight: 500;

      @media (max-width: 1700px) {
        top: -11px;
      }
    }

    .floating-select:focus ~ label,
    .floating-select:not([value=""]):valid ~ label {
      top: -18px;
      font-size: 14px;
      color: #000;
      font-weight: 500;

      @media (max-width: 1700px) {
        top: -11px;
      }
    }

    /* active state */
    .floating-input:focus ~ .bar:before,
    .floating-input:focus ~ .bar:after,
    .floating-select:focus ~ .bar:before,
    .floating-select:focus ~ .bar:after {
      width: 50%;
    }

    /* active state */
    .floating-input:focus ~ .highlight,
    .floating-select:focus ~ .highlight {
      -webkit-animation: inputHighlighter 0.3s ease;
      -moz-animation: inputHighlighter 0.3s ease;
      animation: inputHighlighter 0.3s ease;
    }

    /* animation */
    @-webkit-keyframes inputHighlighter {
      from {
        background: #5264ae;
      }

      to {
        width: 0;
        background: transparent;
      }
    }

    @-moz-keyframes inputHighlighter {
      from {
        background: #5264ae;
      }

      to {
        width: 0;
        background: transparent;
      }
    }

    @keyframes inputHighlighter {
      from {
        background: #5264ae;
      }

      to {
        width: 0;
        background: transparent;
      }
    }

    /************floating labels*******/

    .custom-btn {
      font-size: 25px;
      font-weight: 600;
      color: #fff;
      height: 50px;
      line-height: 50px;
      background: #051f34;
      border: 0;

      @media (max-width: 1700px) {
        font-size: 14px;
        height: 40px;
        line-height: 40px;
      }

      &:focus {
        border-radius: 0;
        outline: 0;
      }

      &:hover {
        background: #cb9274;
      }
    }

    .container {
      width: 100% !important;
    }

    .my-account-wrapper {
      display: flex;
      position: relative;
      z-index: 2;
      padding: 75px 0;
      margin-left: -100px;
      margin-right: -100px;

      @media (max-width: 1700px) {
        margin-left: 0;
        margin-right: 0;
        padding: 35px 0;
      }

      &:before {
        content: "";
        border-left: 9999px solid rgba(203, 146, 116, 0.22);
        right: 90%;
        top: 0px;
        position: absolute;
        z-index: 1;
        height: 100%;
        bottom: 0px;
      }

      .my-account-left-box {
        flex: 0 0 23.6%;
        max-width: 23.6%;
      }

      .my-account-box {
        position: relative;
        z-index: 2;
      }

      .my-account-list {
        background: rgb(255, 255, 255) none repeat scroll 0% 0%;
        box-shadow: rgba(0, 0, 0, 0.16) 8px 8px 6px;
        padding: 22px 0 0 0;

        @media (max-width: 1700px) {
          padding: 10px 0 0 0;
        }

        h3 {
          font-size: 30px;
          color: #081148;
          font-family: "Sorts Mill Goudy", serif;
          padding-left: 35px;
          padding-right: 35px;
          margin-bottom: 30px;

          @media (max-width: 1700px) {
            font-size: 24px;
            padding-left: 20px;
            padding-right: 20px;
            margin-bottom: 15px;
          }
        }

        ul {
          border-bottom: 0;

          li {
            display: block;
            float: none;
            width: 100%;
            margin-bottom: 15px;

            @media (max-width: 1700px) {
              margin-bottom: 5px;
            }

            a {
              font-size: 20px;
              color: #051f34;
              font-weight: 500;
              padding: 14px 35px;
              margin-right: 0;
              border: 0;
              border-radius: 0;
              cursor: pointer;

              @media (max-width: 1700px) {
                font-size: 14px;
                padding: 10px 20px;
              }

              &:hover {
                background: #eddfd6;
                border: 0;
                border-radius: 0;
              }

              svg {
                display: inline-block;
                width: 25px;
                text-align: center;
                margin-right: 10px;
              }
            }

            a.logout {
              background: #051f34;
              color: #fff;
              font-size: 25px;
              font-weight: 600;
              text-align: center;
              cursor: pointer;

              @media (max-width: 1700px) {
                font-size: 14px;
              }
            }

            &:last-child {
              margin-bottom: 0;
              margin-top: 20px;
            }
          }

          li a.active {
            background: #eddfd6;
            border: 0;
            border-radius: 0;
          }
        }

        /***********ul************/
      }

      /*********my-account-list********/
      .tab-content {
        width: 76%;
        padding-left: 30px;
      }
    }

    /************my account wrapper*******/

    .need-help {
      padding: 50px 35px 0 35px;

      @media (max-width: 1700px) {
        padding: 30px 20px 0 20px;
      }

      p {
        font-size: 20px;
        font-weight: 600;
        color: #000000;
        letter-spacing: 1px;

        @media (max-width: 1700px) {
          font-size: 16px;
        }

        span {
          font-size: 17px;
          font-weight: 500;
          letter-spacing: 0.5px;

          @media (max-width: 1700px) {
            font-size: 14px;
          }
        }
      }

      a {
        font-size: 24px;
        color: #0080ff;
        font-weight: bold;
        margin-top: -8px;
        display: block;

        @media (max-width: 1700px) {
          font-size: 17px;
        }
      }
    }

    .account-detail-form {
      background: white none repeat scroll 0% 0%;
      box-shadow: rgba(0, 0, 0, 0.16) 8px 8px 6px;
      padding: 15px 55px 5px 55px;
      width: 57.5%;
      margin: 0 auto;

      @media (max-width: 1700px) {
        padding: 30px;
      }

      .edit-mode {
        .form-group {
          button {
            font-size: 14px;
            padding: 10px 40px;
          }
        }
      }

      h3 {
        font-size: 30px;
        font-weight: 600;
        position: relative;
        color: #010a43;
        margin-bottom: 45px;

        @media (max-width: 1700px) {
          font-size: 22px;
          margin-bottom: 20px;
        }

        .form-edit-icon {
          position: absolute;
          right: 0;
          cursor: pointer;

          img {
            @media (max-width: 1700px) {
              width: 25px;
            }
          }
        }
      }

      .form-group {
        border-bottom: 1px solid rgba(112, 112, 112, 0.27);
        position: relative;
        padding: 2px 10px 15px 10px;
        margin-bottom: 19px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        font-size: 14px;
        .radio-btns-group {
          .radio-btn {
            padding-left: 15px;
          }
          label {
            display: flex;
            flex-direction: row-reverse;
          }
        }
        .react-date-picker__wrapper {
          border: none;
          font-size: 14px;
          .react-date-picker__inputGroup {
            display: flex;
            align-items: center;
          }
        }
        label {
          font-size: 14px;
          color: #000;
          margin: 0;
          align-items: center;
          position: relative;
          span {
            color: #e80303;
          }
          input {
            width: 100%;
            height: 100%;
            opacity: 0;
            position: absolute;

            & + span {
              border: 1px solid #919191;
              width: 20px;
              height: 20px;
              border-radius: 50%;
              position: relative;
              margin-right: 5px;
              display: flex;
              align-items: center;
              justify-content: center;
              &:before {
                content: "";
                border: 1px solid #919191;
                border-radius: 50px;
                width: 10px;
                height: 10px;
                background: #fff;
              }
            }
            &:checked {
              & + span {
                &:before {
                  content: "";
                  border: 5px solid #051f34;
                  border-radius: 50px;
                }
              }
            }
          }
        }
        @media (max-width: 1700px) {
          padding: 0 5px 8px 5px;
          margin-bottom: 12px;
        }

        &:last-child {
          border-bottom: 0;
        }

        &:nth-last-child(2) {
          border-bottom: 0;
        }

        .custom-btn {
          width: 25.3%;
        }

        span {
          img {
            width: 22px;
            margin-top: -2px;
          }
        }

        .form-control {
          border: 0;
          box-shadow: none;
          text-align: right;
          font-size: 20px;
          font-weight: 400;
          background: none;
          color: #000;
          padding: 0;
          line-height: normal;
          height: auto;
          &[readonly] {
            cursor: auto;
          }

          &::placeholder {
            color: #000;
          }

          @media (max-width: 1700px) {
            font-size: 14px;
          }
        }

        input[type="date"] {
          padding-right: 5px;
          display: inline-block;
          width: auto;
          padding-left: 0;
        }

        input[type="date"]::-webkit-calendar-picker-indicator {
          background: url(../images/calender.svg) center no-repeat;
        }
      }

      label {
        font-size: 20px;
        font-weight: 400;
        color: #000;
        flex: 0 0 30%;

        @media (max-width: 1700px) {
          font-size: 14px;
        }
      }

      span.value {
        font-size: 20px;
        font-weight: 400;
        color: #000;

        @media (max-width: 1700px) {
          font-size: 14px;
        }
      }
    }

    /*******account-detail-form*******/

    .my-orders-container {
      background: white none repeat scroll 0% 0%;
      box-shadow: rgba(0, 0, 0, 0.16) -8px 8px 6px;
      padding: 30px 0 150px 0;

      .order-info-body {
        padding-bottom: 50px;
      }

      .order-row {
        input[type="checkbox"] {
          opacity: 0;
          position: absolute;
        }

        input[type="checkbox"] + label::before {
          content: " ";
          position: absolute;
          width: 20px;
          height: 20px;
          left: 0;
          top: 5px;
          border: 1px solid #000;
        }

        input[type="checkbox"] + label {
          position: relative;
          color: #000000;
          font-size: 14px;
          line-height: 30px;
          font-weight: 500;
          padding-left: 30px;
          vertical-align: middle;
          margin: 0;
        }

        input[type="checkbox"]:checked + label::after {
          background: url(../images/tick.svg) no-repeat;
          position: absolute;
          content: "";
          width: 18px;
          height: 20px;
          left: 7px;
          background-size: cover;
          top: 0px;
        }
      }

      .order-info-head {
        background: #eddfd6;
        display: flex;
        justify-content: space-between;
        padding: 15px 75px;
        margin-bottom: 10px;

        @media (max-width: 1700px) {
          padding: 12px 30px;
        }

        p {
          font-size: 20px;
          color: #051f34;
          font-weight: 400;
          margin-bottom: 0;

          @media (max-width: 1700px) {
            font-size: 15px;
          }
        }

        .deliverd b {
          color: #0011ff;
        }

        .cancelled b {
          color: #ff0000;
        }
      }

      .order-row {
        padding: 0 75px;
        display: flex;
        margin-bottom: 15px;

        @media (max-width: 1700px) {
          padding: 0 30px;
        }

        .checkbox {
          margin: 0 35px 0 0;

          @media (max-width: 1700px) {
            margin: 0 20px 0 0;
          }
        }

        .order-image {
          margin-right: 25px;
          margin-top: 3px;
        }

        .order-name {
          font-size: 20px;
          font-weight: 600;
          color: #000;

          @media (max-width: 1700px) {
            font-size: 15px;
          }

          span {
            font-size: 17px;
            font-weight: 500;

            @media (max-width: 1700px) {
              font-size: 13px;
            }
          }
        }

        .continue-btn {
          margin-left: 22%;
        }

        .continue {
          background: url(../images/arrow.svg) no-repeat center left 10px
            #cb9274;
          border: none;
          color: #fff;
          font-size: 17px;
          font-weight: 600;
          height: 36px;
          width: 155px;
          padding-left: 10px;

          @media (max-width: 1700px) {
            font-size: 13px;
            height: 30px;
            width: 135px;
          }
        }

        .return-btn {
          background: url(../images/return-btn-arrow.svg) no-repeat center left
            10px;
          border: none;
          color: #000000;
          font-size: 17px;
          font-weight: 600;
          padding-left: 43px;

          @media (max-width: 1700px) {
            font-size: 13px;
          }
        }
      }

      .cancelled-order .order-info-body {
        padding-top: 30px;
      }
    }

    /**********my-orders-container************/

    .address-view {
      width: 89.8%;
      margin: 0 auto;
      padding-top: 20px;

      @media (max-width: 1700px) {
        padding-top: 10px;
      }
    }

    .address-form {
      background: white none repeat scroll 0% 0%;
      box-shadow: rgba(0, 0, 0, 0.16) 8px 8px 6px;
      padding: 17px 50px 25px 50px;
      width: 89.8%;
      margin: 0 auto;

      @media (max-width: 1700px) {
        padding: 12px 20px 20px 20px;
      }

      h4 {
        font-size: 30px;
        font-weight: 600;
        color: #000;

        @media (max-width: 1700px) {
          font-size: 22px;
        }

        .disabled {
          opacity: 0.1;
        }
      }

      .form-container {
        margin-top: 40px;

        @media (max-width: 1700px) {
          margin-top: 20px;
        }

        .row {
          margin-left: -55px;
          margin-right: -55px;

          @media (max-width: 1700px) {
            margin-left: -20px;
            margin-right: -20px;
          }
        }

        .form-group {
          margin-bottom: 29px;
          padding-left: 55px;
          padding-right: 55px;

          @media (max-width: 1700px) {
            padding-left: 20px;
            padding-right: 20px;
            margin-bottom: 15px;
          }

          &:last-child {
            margin-top: 33px;
          }

          .input-group-prepend {
            position: absolute;
            font-size: 22px;
            color: #8a8a8a;
            top: 0;
            z-index: 23;
            top: 5px;

            @media (max-width: 1700px) {
              font-size: 15px;
            }

            select {
              -webkit-appearance: none;
              -moz-appearance: none;
              appearance: none;
              border: 0;

              &:focus {
                outline: 0;
                border: 0;
              }
            }
          }

          label {
            font-size: 22px;
            color: #8a8a8a;
            font-weight: 400;

            @media (max-width: 1700px) {
              font-size: 14px;
            }
          }
        }

        .form-control {
          border: 0;
          border-bottom: 1px solid rgba(0, 0, 0, 0.4);
          border-radius: 0;
          padding-left: 0;
          font-size: 22px;
          color: #051f34;
          box-shadow: none;
          height: 48px;
          position: relative;
          z-index: 3;
          background: 0;

          @media (max-width: 1700px) {
            font-size: 14px;
            height: 40px;
          }
        }

        input[type="tel"] {
          padding-left: 68px;
        }

        input[type="tel"] + label {
          left: 125px;

          @media (max-width: 1700px) {
            left: 87px;
          }
        }

        .radio-btn {
          display: inline-block;
          margin-left: 30px;
        }

        input[type="radio"],
        input[type="checkbox"] {
          opacity: 0;
          position: absolute;
        }

        input[type="radio"] + label {
          position: relative;
          color: #8a8a8a;
          font-size: 22px;
          line-height: 30px;
          font-weight: 300;
          padding-left: 30px;
          vertical-align: middle;
          margin: 0;
          cursor: pointer;

          @media (max-width: 1700px) {
            font-size: 14px;
          }
        }

        input[type="checkbox"] + label {
          position: relative;
          color: #004cff;
          font-size: 22px;
          line-height: 30px;
          font-weight: 500;
          padding-left: 45px;
          vertical-align: middle;
          margin: 0;
          cursor: pointer;

          @media (max-width: 1700px) {
            font-size: 14px;
            padding-left: 30px;
          }
        }

        input[type="radio"] + label::before {
          content: " ";
          position: absolute;
          width: 23px;
          height: 23px;
          left: 0;
          top: 5px;
        }

        input[type="checkbox"] + label::before {
          border: 2px solid #000;
          content: " ";
          position: absolute;
          width: 32px;
          height: 32px;
          left: 0;
          top: 0;

          @media (max-width: 1700px) {
            width: 24px;
            height: 24px;
            top: 3px;
          }
        }

        input[type="checkbox"]:checked + label::after {
          background: url(../images/tick.svg) no-repeat;
          position: absolute;
          content: "";
          width: 26px;
          height: 30px;
          left: 12px;
          background-size: cover;
          top: -8px;
        }

        input[type="radio"] + label::after {
          content: " ";
          position: absolute;
          width: 15px;
          height: 15px;
          left: 4px;
          top: 9px;
        }

        input[type="radio"] + label::before,
        input[type="radio"] + label::after {
          border-radius: 50%;
          border: 1px solid #919191;
        }

        input[type="radio"]:checked + label::after {
          background: #000;
          border-color: #000;
        }

        .custom-btn {
          width: 14.9%;
          display: inline-block;
          vertical-align: middle;
        }

        .checkbox {
          display: inline-block;
          vertical-align: middle;
          margin: 0 0 0 25px;
        }
      }

      /***********form container**********/
    }

    /*************address form******/

    .change-password-inner {
      width: 46.1%;
      position: relative;
      margin-top: 45px;
      margin-left: 8%;

      h5 {
        font-size: 25px;
        font-weight: 600;
        color: #010a43;

        @media (max-width: 1700px) {
          font-size: 20px;
        }
      }

      .old-password {
        font-size: 20px;
        position: absolute;
        top: 0;
        right: 0;
        color: rgba(5, 31, 52, 0.3);
        font-weight: 500;

        @media (max-width: 1700px) {
          font-size: 15px;
        }

        span {
          color: #ff0000;
        }
      }

      .form-control {
        height: 50px;
        border-radius: 0;
        box-shadow: none;
        border: 1px solid rgba(112, 112, 112, 0.17);
        font-size: 20px;
        font-weight: 400;
        color: rgba(5, 31, 52, 0.3);
        position: relative;
        z-index: 3;
        background: #fff;
      }

      .form-group {
        margin-bottom: 30px;
        position: relative;
      }

      .change-password-form {
        margin-top: 70px;

        @media (max-width: 1700px) {
          margin-top: 30px;
        }

        .custom-btn {
          width: 26%;
        }

        label {
          z-index: 4;
          left: 15px;
          top: 10px;

          @media (max-width: 1700px) {
            top: 15px;
          }

          span {
            color: #ff0000;
          }
        }

        .floating-input:focus ~ label,
        .floating-input:not(:placeholder-shown) ~ label {
          top: -9px;
        }
      }
    }

    #account-detail-view .account-detail-form {
      padding-bottom: 80px;

      @media (max-width: 1700px) {
        padding-bottom: 30px;
      }
    }

    .address-view {
      .add-new-address {
        margin-top: 25px;

        .custom-btn {
          height: 40px;
          font-size: 20px;
          line-height: 40px;
          width: 12.5%;

          @media (max-width: 1700px) {
            font-size: 16px;
          }
        }
      }

      .row {
        margin-left: -10px;
        margin-right: -10px;
      }

      .col-lg-6 {
        padding-left: 10px;
        padding-right: 10px;
      }

      .col-lg-12 {
        padding-left: 10px;
        padding-right: 10px;
      }

      .address-common {
        background: #edeceb;
        padding: 0 25px 25px 25px;
        position: relative;

        @media (max-width: 1700px) {
          padding: 0 15px 15px 15px;
        }

        &::before {
          position: absolute;
          content: "";
          width: 100%;
          height: 12px;
          background: #f6f4f2;
          left: 0;

          @media (max-width: 1700px) {
            height: 8px;
          }
        }

        h3 {
          text-align: center;
          font-size: 23px;
          color: #081148;
          font-weight: 500;
          margin-bottom: 20px;
          z-index: 1;
          position: relative;

          @media (max-width: 1700px) {
            font-size: 18px;
          }
        }

        .address-list {
          max-height: 529px;
          overflow-y: auto;

          @media (max-width: 1700px) {
            max-height: 453px;
          }
        }

        .address-item {
          background: #fff;
          box-shadow: 7px 7px 6px rgba(0, 0, 0, 0.16);
          padding: 10px 20px 25px 30px;
          position: relative;
          margin-bottom: 15px;

          @media (max-width: 1700px) {
            padding: 10px 15px 20px 15px;
          }

          h4 {
            color: #cb9274;
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 15px;

            @media (max-width: 1700px) {
              font-size: 14px;
              margin-bottom: 10px;
            }
          }

          .edit-icon {
            position: absolute;
            top: 10px;
            right: 20px;

            img {
              width: 20px;

              @media (max-width: 1700px) {
                width: 15px;
              }
            }
          }

          .address-inner {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;

            p {
              color: #9b9b9b;
              font-size: 15px;
              font-weight: 400;
              margin-bottom: 0;

              @media (max-width: 1700px) {
                font-size: 12px;
              }

              a {
                color: #9b9b9b;
              }

              &:nth-child(even) {
                width: 37%;
              }
            }
          }
        }
      }
    }

    /**********address-view*******/
  }

  /***********main section****/

  .my-account-footer {
    background: #eddfd6;
    padding: 18px 0 8px 0;

    .container {
      width: 100% !important;
    }

    .get-update-outer {
      display: flex;
      justify-content: space-between;
      margin-left: -100px;
      margin-right: -100px;

      @media (max-width: 1700px) {
        margin-left: 0;
        margin-right: 0;
      }

      .get-update-form {
        background: #fff;
        display: flex;
        padding: 0 25px 0 70px;
        align-items: center;
        height: 63px;
        position: relative;

        @media (max-width: 1700px) {
          padding: 0 20px 0 40px;
          height: 50px;
        }

        &:before {
          position: absolute;
          content: "";
          height: 100%;
          background: #fff;
          left: -100px;
          width: 100px;
        }

        .form-group {
          display: inline-block;
          margin-bottom: 0;

          .form-control {
            min-width: 600px;
            border: none;
            border-bottom: 1px solid rgba(112, 112, 112, 0.4);
            border-radius: 0;
            padding-left: 0;
            font-size: 17px;
            box-shadow: none;
            margin-top: 8px;

            @media (max-width: 1700px) {
              font-size: 14px;
              min-width: 450px;
              margin-top: 4px;
            }

            &:focus {
              box-shadow: none;
            }
          }
        }

        h4 {
          font-size: 23px;
          color: #cb9274;
          font-family: "Sorts Mill Goudy", serif;
          margin-right: 35px;
          margin-bottom: 0;
          position: relative;
          z-index: 2;

          @media (max-width: 1700px) {
            font-size: 18px;
            margin-right: 20px;
          }

          &:after {
            content: "";
            content: "";
            border-top: 1px solid rgba(203, 146, 116, 0.22);
            left: -118%;
            top: 50%;
            position: absolute;
            width: 110%;
            transform: translateY(-50%);
            margin-top: -3px;
            z-index: -1;
          }
        }
      }

      .social-media {
        ul {
          list-style: none;

          li {
            display: inline-block;
            margin-right: 60px;

            @media (max-width: 1700px) {
              margin-right: 30px;
            }

            &:last-child {
              margin-right: 0;
            }

            a {
              background: #e1d5cd;
              width: 63px;
              height: 63px;
              line-height: 63px;
              display: inline-block;
              border-radius: 50%;
              text-align: center;

              @media (max-width: 1700px) {
                width: 50px;
                height: 50px;
                line-height: 50px;
              }

              &:hover {
                background: #b8aea7;
              }
            }
          }
        }
      }

      .radio-btn {
        display: inline-block;
        vertical-align: middle;

        input[type="radio"] {
          opacity: 0;
          position: absolute;
        }

        input[type="radio"] + label {
          color: #cb9274;
          font-size: 20px;
          font-weight: 600;
          cursor: pointer;

          @media (max-width: 1700px) {
            font-size: 15px;
          }
        }

        input[type="radio"]:checked + label {
          color: #010a43;
        }

        span.or {
          color: #051f34;
          font-size: 18px;
          font-family: "Sorts Mill Goudy", serif;
          display: inline-block;
          margin: 0 17px 0 17px;
          position: relative;
          top: -1px;
          font-style: italic;
        }
      }
    }

    /**********get-update-outer*********/
  }

  /**************my-account-footer***********/

  .users-table-wrap {
    thead {
      background: #f9ede7;
      th {
        border: 0;
        span {
          display: inline-block;
          background: #0543ff;
          color: #fff;
          line-height: normal;
          padding: 2px 8px;
          cursor: pointer;
        }
      }
    }
    tbody {
      background: #fff;
      td {
        border: 0;
        vertical-align: middle;
        .productImgDiv {
          float: left;
          max-width: 80px;
          img {
            max-width: 100%;
          }
        }
        .productName {
          margin: 0;
          padding: 0 0 0 15px;
          color: #000;
          font-family: "Josefin Sans";
          font-weight: normal;
          letter-spacing: 0.06em;
          p {
            position: relative;
            top: 50%;
            transform: translateY(-50%);
            -webkit-transform: translateY(-50%);
            -moz-transform: translateY(-50%);
            -ms-transform: translateY(-50%);
            span {
              display: block;
              font-family: "Montserrat";
              letter-spacing: normal;
              font-size: 15px;
            }
          }
        }
        .productDelivery {
          font-weight: bold;
          font-size: 15px;
          span {
            display: block;
            font-weight: normal;
            font-style: italic;
            font-size: 15px;
          }
        }
      }
    }
    tfoot {
      background: #fff;
      border: 1px solid #dee2e6;
      th {
        border: 0;
        padding: 10px;
        line-height: normal;
        span {
          font-weight: normal;
        }
      }
    }
  }
`;