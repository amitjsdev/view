import styled from "styled-components";
import { CustomButton } from "./global";

export const Cart = styled.div`
  margin: 0 0 110px;
  .mainWrapCart {
    display: flex;
    padding: 40px 0;
    position: relative;
    &:before {
      content: "";
      border-right: 9999px solid rgba(203, 146, 116, 0.22);
      left: 90%;
      top: 0;
      position: absolute;
      z-index: -1;
      height: 100%;
      bottom: 0;
    }
  }
  h2.head {
    top: -40px;
    font-size: 97px;
    color: rgba(0, 0, 0, 0.04);
    z-index: -1;
    position: absolute;
    right: -2%;
  }

  .leftBox {
    display: flex;
    flex-direction: column;
    flex: 1;
    margin-right: 100px;
    max-height: 469px;
    overflow-y: auto;
    h4 {
      color: #081148;
      font-weight: 600;
      margin: 0 0 20px;
    }
    .box {
      display: flex;
      margin: 0 0 30px;
      padding: 0 0 30px;
      &:nth-last-of-type(1) {
        border: none;
        margin: 0;
        padding: 0;
      }
      .left {
        margin-right: 35px;
        span {
          background: #fff;
          padding: 20px;
          display: inline-block;
          box-shadow: 0 0 5px rgb(0 0 0 / 10%);
          img {
            display: none;
            &:first-child {
              display: block;
            }
          }
        }
      }
      .right {
        flex: 1;
        h4 {
          font-size: 20px;
          color: #000;
          margin: 0 0 10px;
          font-weight: 600;
        }
        .desc {
          display: grid;
          grid-template-columns: 1fr 1fr;
          li {
            margin: 0 0 5px;
            font-size: 14px;
            label {
              margin: 0 5px 0 0;
            }
          }
        }
        .buttonList {
          button {
            background: none;
            border: none;
            box-shadow: none;
            font-size: 14px;
            display: flex;
            align-items: center;
            padding: 0;
            font-weight: 500;
            svg {
              margin-right: 5px;
            }
          }
          h5 {
            font-weight: 600;
            font-size: 30px;
          }
        }
        .quantity {
          display: flex;
          height: 100%;
          button {
            background: none;
            border: none;
            box-shadow: none;
            font-size: 14px;
            padding: 0;
            width: 26px;
            background: #fff;
            margin: 0 3px;
            font-size: 20px;
            line-height: 26px;
          }
          span {
            background: #fff;
            width: 52px;
            font-size: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
          }
        }
      }
    }
  }

  .totalPrice {
    background: #fff;
    padding: 30px 60px;

    box-shadow: -8px 8px 6px rgb(0 0 0 / 16%);
    h4 {
      color: #081148;
      font-weight: 600;
      margin: 0 0 20px;
    }
    .listName {
      border-bottom: 4px solid #f2f2f2;
      margin: 0 0 30px;
      padding: 0 0 20px;

      li {
        display: flex;
        justify-content: space-between;
        font-weight: 400;
        color: rgba(8, 17, 72, 0.6);
        h6 {
          font-weight: 600;
          span {
            color: #0080ff;
          }
        }
      }
    }
    .total {
      h3 {
        background: none;
        font-size: 23px;
        color: #081148;
        font-weight: 600;
        font-family: inherit;
      }
      h2 {
        font-size: 26px;
        color: #081148;
        font-weight: 600;
        margin-left: 40px;
      }
    }
    button {
      color: #fff;
      width: 100%;
      border: none;
      padding: 10px;
      margin-top: 10px;
      text-transform: capitalize;
    }
  }

  h3 {
    font-family: var(--sort-font);
    color: #081148;
    font-size: 30px;
  }
  .purchaseDetails {
    margin: 40px 0 0;
    .listName {
      margin: 0;
      padding: 0;
      border: none;
    }
  }
  .coupon {
    padding: 20px 0;
    input {
      border: 1px solid rgba(112, 112, 112, 0.2);
      margin-right: 5px;
      font-size: 16px;
      text-align: center;
    }
    button {
      margin: 0;
      font-size: 16px;
    }
  }
  .help {
    font-size: 18px;
    font-weight: 400;
    width: 100%;
    text-align: center;
    padding: 15px 0 0;
    a {
      font-weight: 700;
      color: #0080ff;
    }
  }
  .allInfo {
    display: grid;
    grid-template-columns: 1fr 1fr 1fr;
    grid-gap: 40px;
    margin: 160px 0 70px;
    .main-points {
      background: #fff;
      box-shadow: 5px 5px 6px rgba(0, 0, 0, 0.16);
      display: flex;
      justify-content: center;
      align-items: center;
      .list {
        display: grid;
        grid-template-columns: 1fr 1fr;
        li {
          text-align: center;
          h5 {
            font-weight: 400;
            margin: 10px 0 0;
            font-size: 20px;
          }
          svg {
            min-height: 90px;
          }
        }
      }
    }
    .shippingInfo {
      border: 1px solid rgba(33, 139, 130, 0.2);
      text-align: center;
      h3 {
        background: var(--primary);
        color: #fff;
        text-align: center;
        font-size: 24px;
        padding: 10px 0;
      }
      button {
        text-transform: capitalize;
      }
      .list {
        margin: 40px 0 20px;
        li {
          color: #000;
          font-size: 16px;
          font-weight: 400;
          text-transform: uppercase;
          justify-content: space-between;
          padding: 0 30px 10px;
          h4 {
            font-size: 16px;
            font-weight: 400;
          }
        }
      }
    }
  }
`;

export const Wishlist = styled.div`
  margin: 0 0 150px;
  position: relative;
  .empty {
    grid-template-columns: auto !important;
    .empty-wish {
      span {
        margin-right: 20px;
      }
      p {
        color: rgba(0, 0, 0, 0.2);
        font-size: 18px;
      }
    }
  }
  h2.head {
    top: 10px;
    font-size: 97px;
    color: rgba(0, 0, 0, 0.04);
    z-index: -1;
    position: absolute;
    right: 2%;
  }
  h3 {
    color: rgba(0, 0, 0, 0.26);
    font-size: 16px;
    margin: 15px 0 5px;
  }
  .d-grid {
    grid-gap: 30px;
  }
  .list {
    box-shadow: 0 0 10px rgb(0 0 0 / 12%);
    background: rgba(255, 255, 255, 0.5);
    text-align: center;
    padding: 50px 40px 20px;
    ${CustomButton} {
      font-size: 17px;
      margin-left: 20px;
    }
    h6 {
      position: absolute;
      left: 10px;
      top: 10px;
      color: rgba(0, 0, 0, 0.2);
      margin: 0;
      font-weight: 600;
    }
    span {
      cursor: pointer;
    }
    &.outof_stock {
      background: rgba(255, 97, 97, 0.22);
      h4 {
        color: rgba(0, 0, 0, 0.2) !important;
      }
    }
    .wishInfo {
      width: 100%;
      span {
        margin: 0;
        cursor: default;
        img {
          display: none;
          &:first-child {
            display: inline-block;
          }
        }
      }
      h4 {
        font-size: 16px;
        color: #000;
        font-weight: 700;
      }
      h5 {
        font-size: 24px;
        font-weight: 600;
        color: #000;
        padding: 10px 0;
        margin: 0;
      }
    }
  }
`;
