import styled, { css } from "styled-components";
import { CustomButton } from "./global";

//images
import Arrow from "../assets/images/slider-arrow.png";
import Luxury from "../assets/images/detail/luxurybg.png";
import LuxuryGift from "../assets/images/detail/luxurygift.png";
import Shape from "../assets/images/detail/shape.png";
import Quote from "../assets/images/detail/quote.svg";

export const ProductDetail = styled.div`
  ${(props) =>
    props.looseDiamond &&
    css`
      .product-details {
        width: 55% !important;
        h2 {
          text-align: left !important;
        }
      }
      .shippingInfo {
        svg {
          position: static;
          margin-right: 20px;
        }
      }
      .diamond-details-wrap {
        background: #fff;
        /* padding: 10px 0; */
        margin: 0 0 100px;
        &.ring {
          display: flex;
          flex-wrap: wrap;
          h2 {
            flex: 1;
          }
          .ring-content {
            flex: 1;
            padding: 30px;
            h4 {
              font-size: 20px;
              font-weight: 600;
              color: #000;
            }
            p {
              font-size: 14px;
              line-height: 30px;
            }
          }
        }
        h2 {
          background-color: var(--primary);
          color: #fff;
          padding: 10px 60px;
          font-size: 20px;
        }
        .diamond-skeleton {
          padding: 0 30px;
        }
        .list {
          flex: 1;
          li {
            display: flex;
            justify-content: space-between;
            padding: 10px 50px;
            align-items: center;
            &:nth-child(even) {
              background: rgba(203, 146, 116, 0.05);
            }
            h4 {
              font-size: 14px;
              font-weight: 600;
              color: rgba(0, 0, 0, 0.69);
              margin: 0;
            }
            label {
              font-size: 14px;
              font-weight: 500;
              margin: 0;
              color: rgba(0, 0, 0, 0.4);
            }
          }
        }
      }
      .diamond-education-wrap {
        .nav {
          background: #eff1f2;
          justify-content: space-evenly;
          border: none;
          li {
            flex: 1;
            text-align: center;
            a {
              font-weight: 600;
              font-size: 18px;
              color: #767778;
              border: none;
              border-radius: 0;
              &.active {
                background: #051f34;
                color: #fff;
              }
            }
          }
        }
        .tab-content {
          background: #fff;
          padding: 50px;
        }
      }
    `}
  ${(props) =>
    props.make &&
    css`
      .product-price {
        margin: 20px 0 0 !important;
      }
      .selected-filter {
        background: #fff;
        margin: 20px 0 0px;
        .productDivs {
          display: flex;
          align-items: center;
          width: 100%;
          padding: 20px !important;
          h6 {
            margin: 0;
          }
          h5 {
            color: rgba(0, 0, 0, 0.5);
            font-size: 14px;
            font-style: italic;
            padding: 5px 0 0;
            margin: 0;
          }
          svg {
            margin-right: 15px;
          }
          .productPrice {
            margin-left: auto;
            color: var(--primary);
            font-size: 16px;
            font-weight: 500;
          }
        }
      }
    `}
  .product-card {
    margin: 0 auto;
    margin-top: 50px;
    margin-bottom: 130px;
    font-weight: normal;
    text-align: left;
    display: flex;
    justify-content: space-between;
    padding: 0;
  }

  .product-details {
    width: 30%;
    height: 100%;
    &:first-child {
      padding-right: 50px;
    }
    &:last-child {
      padding-left: 50px;
    }
    .btn-grp {
      grid-gap: 10px;
    }

    &.ring {
      .type-list {
        padding: 20px 0 0;
        li {
          .position-relative {
            svg {
              width: 35px;
              height: auto;
            }
            p {
              font-size: 12px;
            }
          }
        }
      }
    }
    .selected-filter {
      & > div {
        padding-right: 15px;
        border-right: 1px solid rgba(112, 112, 112, 0.4);
        margin-right: 15px;
        &:last-child {
          border: none;
          margin-right: 0;
          padding-right: 0;
        }
        label {
          font-size: 12px;
          margin: 0;
        }
        b {
          display: flex;
        }
        em {
          font-size: 12px;
        }
      }
    }
    h2 {
      color: #000;
      margin: 0;
      font-size: 30px;
      text-align: right;
      span {
        color: rgba(0, 0, 0, 0.5);
        padding-left: 5px;
        font-style: italic;
      }
      @media (max-width: 1500px) {
        line-height: 30px;
        font-size: 22px;
      }
    }
    h3 {
      font-size: 25px;
      text-align: right;
      font-weight: 400;
      @media (max-width: 1500px) {
        font-size: 15px;
      }
    }
  }

  .product-image {
    padding: 0;
    width: 40%;
    height: 40%;

    .carousel-inner {
      border-radius: 50%;
      box-shadow: 0 0 10px rgb(0 0 0 / 10%);
      background: #fff;

      #canvas1 {
        width: 100%;
        display: inline-block;
        pointer-events: none;
        max-width: 100%;
        object-fit: cover;
        height: 100%;
      }
    }
    .carousel,
    .carousel-item,
    .carousel-inner {
      height: 100%;
    }
    .carousel-control-next,
    .carousel-control-prev {
      opacity: 1;
      background: #fff;
      padding: 10px;
      border-radius: 50%;
      top: 48%;
      bottom: auto;
      width: auto;
    }
    .carousel-control-prev {
      left: -20px;
    }
    .carousel-control-next {
      right: -20px;
    }
    .carousel-control-prev-icon {
      background-image: url(${Arrow});
    }
    .carousel-control-next-icon {
      background-image: url(${Arrow});
      transform: rotate(180deg);
    }

    .carousel-indicators {
      position: static;
      padding: 20px 0 0;
      li {
        border: 1px solid rgba(112, 112, 112, 0.36);
        height: 40px;
        width: 40px;
        text-indent: 0;
        background-position: center center;
        background-size: 70px;
        background-color: transparent;
        opacity: 1;
        &.active {
          border: 1px solid rgba(112, 112, 112, 1);
        }
      }
    }

    img {
      max-width: 100%;
      object-fit: cover;
      height: 100%;
    }
  }

  .product-color-choices {
    grid-template-columns: repeat(4, 30px);
    grid-column-gap: 20px;
    grid-row-gap: 10px;
    margin: 0.5em 0;
    display: grid;
    position: relative;
    button {
      &.four {
        grid-area: 2;
        &:before {
          content: "14K";
          font-size: 12px;
          color: rgba(0, 0, 0, 0.8);
        }
      }
      &.eight {
        grid-area: 3;
        &:before {
          content: "18K";
          font-size: 12px;
          color: rgba(0, 0, 0, 0.8);
        }
      }
    }
    &.not {
      button {
        opacity: 0.5;
        border: 1px solid #c7c7c7 !important;
      }
      &:after {
        content: "Out of Stock";
        position: absolute;
        left: 0;
        opacity: 0;
        bottom: 0;
        right: 0;
        height: 65%;
        text-align: center;
        width: 60%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 700;
        color: #ff5000;
      }
      &:hover:after {
        opacity: 1;
      }
    }
  }

  .product-color-choices button {
    width: 40px;
    height: 40px;
    margin-right: 10px;
    border: 1px solid #c7c7c7;
    position: relative;
    padding: 0;
    background: rgb(254, 254, 254);
    background: linear-gradient(0deg, #fff 0%, rgba(241, 241, 241, 0.78) 100%);
    &#platinum {
      grid-row: 3/3;
      &:before {
        content: "Pt";
        font-size: 12px;
        color: rgba(0, 0, 0, 0.8);
      }
    }
    &.active {
      border: 2px solid #4a4a4a;
    }
    @media (max-width: 1500px) {
      width: 35px;
      height: 35px;
      font-size: 14px;
    }
  }

  .product-price {
    display: flex;
    margin: 40px 0 0;
    flex-wrap: wrap;
    h3 {
      margin-right: 10px;
      font-size: 22px;
      font-weight: 700;
    }
    h5 {
      width: 100%;
      font-size: 13px;
      font-weight: 400;
      font-style: italic;
      span {
        color: #0065ff;
      }
    }
  }

  #roseGold {
    background: #fff;
    background: linear-gradient(0deg, #fff 0%, rgba(255, 0, 119, 0.45) 100%);
  }

  #yellowGold {
    background: #fff;
    background: linear-gradient(0deg, #fff 0%, rgba(249, 208, 0, 0.45) 100%);
  }

  #whiteGold {
    background: #fff;
    background: linear-gradient(0deg, #fff 0%, rgba(242, 242, 242, 1) 100%);
  }

  .carousel-indicators li {
    background-color: blue;
  }
  .productDetail {
    display: grid;
    grid-template-columns: 330px 1fr 1fr;
    grid-gap: 30px;
    margin: 0 0 100px;
    span {
      img {
        width: 100%;
      }
    }
    .detailInfo {
      border: 1px solid rgba(33, 139, 130, 0.2);
      h3 {
        background: var(--primary);
        color: #fff;
        text-align: center;
        font-size: 16px;
        padding: 10px 0;
        margin: 0 0 30px;
      }
      .list {
        li {
          margin: 0 15px 10px;
          padding: 0 0 10px;
          justify-content: space-between;
          border-bottom: 1px solid rgba(203, 146, 116, 0.22);
          &:last-child {
            border-bottom: 0;
          }
        }
        h4,
        p {
          font-size: 13px;
          color: #000;
          font-weight: 400;
          text-transform: uppercase;
          margin: 0;
        }
        p {
          font-weight: 500;
        }
      }
    }
  }

  .caratWeight {
    .list {
      display: grid;
      grid-template-columns: repeat(5, minmax(40px, 1fr));
      grid-gap: 10px;
      li {
        background: #fff;
        padding: 12px 0;
        color: #000000;
        font-size: 13px;
        font-weight: 600;
        text-align: center;
        cursor: pointer;
        &.active {
          background: var(--primary);
          color: #fff;
        }
      }
    }
  }

  .earringInfo {
    padding: 20px 10px 15px;
    background: rgba(255, 255, 255, 1);
    margin: 20px 0;
    word-break: break-all;
    font-size: 13px;
    text-transform: capitalize;
    .row {
      margin-bottom: 5px;
    }
    &.desc {
      p {
        padding: 0 20px;
      }
    }
  }
  .shippingInfo {
    padding-top: 20px;
    p {
      padding-right: 70px;
      font-size: 15px;
      color: #000;
      font-weight: 700;
      line-height: 20px;
    }
    svg {
      margin-right: 10px;
    }
  }
  .helpUs {
    margin: 40px 0 0;
    ul {
      li {
        text-align: center;
        margin-right: 40px;
        cursor: pointer;
        display: flex;
        a {
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: space-between;
          min-height: 40px;
        }
        h4 {
          font-size: 18px;
          margin: 0;
          display: flex;
          font-weight: 700;
          justify-content: space-between;
          color: #000;
        }
        p {
          font-size: 16px;
          line-height: normal;
          margin: 0;
          a {
            color: #000;
          }
        }
      }
    }
  }

  .product-choices {
    p {
      font-size: 18px;
      font-weight: 400;
      margin: 0 0 10px;
      color: #000000;
    }
    .caratWeight {
      margin: 30px 0;
    }

    ${CustomButton} {
      padding: 10px 20px;
      font-size: 16px;
      &.cart {
        margin-left: 10px;
        flex: 1;
        text-transform: capitalize;
      }
    }
    .button {
      margin-top: 50px;
      button {
        margin-right: 30px;
        text-transform: uppercase;
        font-size: 18px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        svg {
          margin-right: 5px;
        }
      }
    }
    a {
      button {
        font-size: 20px;
      }
    }
  }

  .similar {
    padding: 100px 0;
    position: relative;
    &:before {
      content: "";
      background: rgba(237, 223, 214, 0.6);
      width: 100%;
      height: 30%;
      position: absolute;
      top: 25%;
      z-index: -1;
      bottom: 0;
      left: 0;
      right: 0;
      margin: auto;
    }
    h2 {
      font-size: 60px;
      margin: 0 200px 40px;
      font-family: var(--sort-font);
      display: flex;
      align-items: center;
      justify-content: flex-end;
      span {
        font-family: var(--prist-font);
        font-size: 214px;
        color: var(--primary);
        line-height: 120px;
      }
      b {
        margin-top: 90px;
        margin-left: -50px;
        font-weight: 400;
      }
    }
    .react-multi-carousel-item {
      padding: 0 20px;
      div {
        padding: 20px;
        background: #fff;
        span {
          width: auto;
        }
        h4 {
          color: var(--primary);
          font-size: 19px;
          font-weight: 600;
          width: 100%;
          text-align: left;
        }
        h5 {
          font-weight: 600;
          font-size: 24px;
          color: #000;
          padding: 10px 0;
          text-align: left;
        }
      }
    }
  }

  .luxury {
    background: url(${Luxury}) no-repeat scroll 0 0 / cover;
    padding: 90px 0;
    h2 {
      font-family: var(--sort-font);
      font-size: 72px;
      color: var(--heading-color);
      span {
        font-family: var(--prist-font);
        font-size: 214px;
        color: var(--primary);
      }
    }
    p {
      font-size: 20px;
      color: #000;
      width: 75%;
    }
    .right {
      span {
        /* background: url(${LuxuryGift}) no-repeat scroll 0 0 / cover; */
      }
    }
  }

  .react-multi-carousel-item {
    div {
      text-align: center;

      span {
        width: 230px;
        display: inline-block;
        img {
          display: none;
          &:first-child {
            display: block;
            cursor: pointer;
          }
        }
      }

      h4 {
        font-size: 13px;
        width: 60%;
        display: inline-block;
        margin-top: 10px;
        cursor: pointer;
      }
      h5 {
        font-size: 16px;
      }
    }
  }
  .feel-luxury {
    background: #f1e9e4;
    position: relative;
    margin-top: 100px;

    /* &:after {
      position: absolute;
      right: 0;
      background: url(${Shape});
      width: 360px;
      height: 100%;
      content: "";
      top: 0;
      background-size: cover;
    } */
  }

  .testimonials {
    h3 {
      justify-content: center;
    }
  }

  .feel-luxury-img {
    width: 40%;
    margin: 0 0 -24px 0;
    text-align: right;
  }

  .feel-luxury-caption {
    p {
      font-size: 20px;
      line-height: 46px;
      color: #000;
      @media (max-width: 1500px) {
        margin-left: 30px;
        width: 70%;
        font-size: 16px;
        line-height: 36px;
      }
    }

    width: calc(100% - 345px);
  }

  .feel-luxury-inner {
    position: relative;
    z-index: 333;
    display: flex;
    align-items: center;

    p {
      line-height: 2;
      color: #000;
      margin: 20px 0 0 0;
    }
  }

  .testimonial-heading {
    text-align: right;
  }

  @media (max-width: 1439px) {
    .feel-luxury-caption {
      p {
        font-size: 16px;
        line-height: 36px;
      }
    }

    .feel-luxury-img {
      right: 7px;
      top: -7px;
      max-width: 340px;
    }

    .testimonial-caption {
      .client-name {
        font-size: 18px;
      }

      padding-left: 90px;
    }

    .rating {
      img {
        width: 15px;
      }
    }
  }
  .usp {
    ul {
      padding: 10px 0;
      svg {
        max-width: 45px;
        height: auto;
      }
      h5,
      span {
        color: #fff;
        margin: 5px 0 0;
        font-size: 14px;
      }
    }
  }
`;
