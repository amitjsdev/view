import styled from "styled-components";
        export const FooterWrap = styled.div`

        `;