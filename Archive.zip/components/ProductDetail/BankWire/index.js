import React from "react";

function BankWire(props) {
  // BankWire price Calculation
  const bankWire = () => {
    const diamondPrice = props.diamondProduct?.price?.$numberDecimal;
    const engagementPrice = props.ringProduct?.price?.$numberDecimal;
    const totalPrice = +diamondPrice + +engagementPrice;
    const bankwireDiscount = 1.5 / 100;
    const finalBankWirePrice = totalPrice - totalPrice * bankwireDiscount;
    return finalBankWirePrice.toFixed(2);
  };

  return <>{bankWire()}</>;
}

export default BankWire;
