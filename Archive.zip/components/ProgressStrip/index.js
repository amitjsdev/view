
import React, { useEffect, useState } from "react";
import APIUtil from "../../api";
import { Container } from "reactstrap";
import { UserDetails } from "../../constant";
import { useLocation, useHistory } from "react-router-dom";

// dummy image
import dummyImg from "../../assets/images/er-Img.jpeg";

const api = new APIUtil();

const ProgressStrip = (props) => {
  const history = useHistory();
  const [firstStepData, setFirstStepData] = useState();
  const [secondStepData, setSecondStepData] = useState();
  const userId = UserDetails();
  const firstStep = localStorage.getItem("firstStep");
  const secondStep = localStorage.getItem("secondStep");
  const search = useLocation().search;
  const stoneShapeId = new URLSearchParams(search).get("stoneShapeId");
  const diamondId = new URLSearchParams(search).get("diamondId");
  const engagementRingId = new URLSearchParams(search).get("engagementRingId");
  const [recordCount, setRecordCount] = useState(0);

  const pathname = window.location.pathname;

  useEffect(() => {
    if (!!userId && !!userId?._id && Object.keys(userId).length > 0) {
      api.get(`products/ringReview?id=${userId?._id.toString()}`).then((res) => {
        let ringReviewData = Object.values(res.data.data);
        setRecordCount(ringReviewData.length)
        let firstDataIndex = ringReviewData.findIndex((item) => item?.engagementRingId)
        if (firstDataIndex == 0) {
          setFirstStepData(ringReviewData[0])
        }
        let firstlooseDiamondIdIndex = ringReviewData.findIndex((item) => item?.looseDiamondId)
        if (firstlooseDiamondIdIndex == 0) {
          setFirstStepData(ringReviewData[0])
        }
        let secondDataIndex = ringReviewData.findIndex((item) => item?.engagementRingId)
        if (secondDataIndex > 0) {
          setSecondStepData(ringReviewData[secondDataIndex])
        }
        let secondlooseDiamondIdIndex = ringReviewData.findIndex((item) => item?.looseDiamondId)
        if (secondlooseDiamondIdIndex > 0) {
          setSecondStepData(ringReviewData[secondlooseDiamondIdIndex])
        }
      });
    }
  }, []);
  // useEffect(() => {

  // }, [firstStepData,secondStepData]);

  const viewPage = (e) => {
    if (!!e?.looseDiamondId) {
      history.push({
        pathname: `/diamond-details/${e?.looseDiamondId?._id}`,
      });
    }
    if (!!e?.engagementRingId) {
      let urlLastPara = e?.engagementRingId?.metal.split(' ');
      history.push({
        pathname: `/engagement-rings-details/${e?.engagementRingId?._id}/${e?.engagementRingId?.metalCarat}/${urlLastPara[0]}`,
      });
    }
  };

  const removeRing = async (e,type) => {
    const token = localStorage.getItem("token");
    const headers = {
      Authorization: `Bearer ${token}`,
    };
    let new_data = {};
    if (!!e?.looseDiamondId) {
      new_data = {
        userId: userId._id.toString(),
        looseDiamondId: e?.looseDiamondId?._id,
      };
    }
    if (!!e?.engagementRingId) {
      new_data = {
        userId: userId._id.toString(),
        engagementRingId: e?.engagementRingId?._id,
      };
    }
    await api
      .post(`products/delRingReview`, new_data, { headers })
      .then((response) => {
      });
    if (e?.engagementRingId?._id) {
      if(type == 'first'){
        history.push({
          pathname: "/build-your-own-ring/settings",
          search: `?diamondId=${!!secondStepData ? secondStepData?.looseDiamondId?._id : ''}`,
        });
      }
      if(type == 'second'){
        history.push({
          pathname: "/build-your-own-ring/settings",
          search: `?diamondId=${!!firstStepData ? firstStepData?.looseDiamondId?._id : ''}`,
        });
      }
      setFirstStepData();
      //window.location.reload();
    }
    if (e?.looseDiamondId?._id) {
      if(type == 'first'){
        history.push({
          pathname: "/diamond-search",
          search: `?engagementRingId=${!!secondStepData ? secondStepData?.engagementRingId?._id : ''}`,
        });
      }
      if(type == 'second'){
        history.push({
          pathname: "/diamond-search",
          search: `?engagementRingId=${!!firstStepData ? firstStepData?.engagementRingId?._id : ''}`,
        });
      }
      
      setFirstStepData();
      // window.location.reload();
    }
  };

  return (
    <div className="strip">
      <Container>
        <ul className="steps">
          <li
            className={
              !!firstStepData ? `d-flex justify-content-between activeStep` : ""
            }
          >
            <div className="left">
              <span>1</span>
              {firstStepData?.engagementRingId?._id &&
                <p>
                  Choose Setting
              </p>
              }
              {firstStepData?.looseDiamondId?._id &&
                <p>
                  Choose Diamond
              </p>
              }

              {(recordCount == 0 && pathname.includes("engagement-rings-details")) &&
                <p>
                  Choose Setting
                </p>
              }
              {(recordCount == 0 && pathname.includes("diamond-details")) &&
                <p>
                  Choose Diamond
                </p>
              }

            </div>
            {firstStepData && (
              <div className="righSection">
                <span
                  className="viewleft"
                  onClick={() => {
                    viewPage(firstStepData);
                  }}
                >
                  view
                </span>

                <span
                  onClick={() => {
                    removeRing(firstStepData,'first');
                  }}
                  className="viewRight"
                >
                  Remove
                </span>
                {firstStepData && firstStepData?.engagementRingId?._id && (
                  <>
                    <img className="stepImg" src={dummyImg} alt="" />
                    <p className="stepsPrice">
                      ${firstStepData.engagementRingId?.price.$numberDecimal}
                    </p>
                  </>
                )}
                {firstStepData && firstStepData?.looseDiamondId?._id && (
                  <>
                    <img
                      className="stepImg"
                      src={
                        firstStepData.looseDiamondId?.images?.diamondImages[0]
                      }
                      alt=""
                    />
                    <p className="stepsPrice">
                      ${firstStepData.looseDiamondId?.price.$numberDecimal}
                    </p>
                  </>
                )}
              </div>
            )}
          </li>
          <li
            className={
              !!secondStepData ? `d-flex justify-content-between activeStep` : ""
            }
          >
            <div className="left">
              <span>2</span>
              {(!!firstStepData?.looseDiamondId?._id || !!secondStepData?.engagementRingId?._id) &&
                <p>
                  Choose Setting
              </p>
              }

              {/* {(!!firstStepData?.looseDiamondId?._id) &&
                <p>
                  Choose Setting
                </p>
              } */}
              {(!!firstStepData?.engagementRingId?._id) &&
                <p>
                  Choose Diamond
                </p>
              }
              {(recordCount == 0 && pathname.includes("diamond-details")) &&
                <p>
                  Choose Setting
                </p>
              }
             {(recordCount == 0 && pathname.includes("engagement-rings-details")) &&
                <p>
                  Choose Diamond
                </p>
              }
            </div>
            {secondStepData && (
              <div className="righSection">
                <span
                  className="viewleft"
                  onClick={() => {
                    viewPage(secondStepData);
                  }}
                >
                  view
                </span>

                <span
                  onClick={() => {
                    removeRing(secondStepData,'second');
                  }}
                  className="viewRight"
                >
                  Remove
                </span>
                {secondStepData && secondStepData?.engagementRingId?._id && (
                  <>
                    <img className="stepImg" src={dummyImg} alt="" />
                    <p className="stepsPrice">
                      ${secondStepData.engagementRingId?.price.$numberDecimal}
                    </p>
                  </>
                )}
                {secondStepData && secondStepData?.looseDiamondId?._id && (
                  <>
                    <img
                      className="stepImg"
                      src={
                        secondStepData.looseDiamondId?.images?.diamondImages[0]
                      }
                      alt=""
                    />
                    <p className="stepsPrice">
                      ${secondStepData.looseDiamondId?.price.$numberDecimal}
                    </p>
                  </>
                )}
              </div>
            )}
          </li>
          <li
            className={
              !!stoneShapeId ? `d-flex justify-content-between activeStep` : ""
            }
          >
            <div className="left">
              <span>3</span>
              <p>Complete Ring</p>
              <p className="stepsPrice">
                {firstStepData &&
                  secondStepData &&
                  secondStepData?.looseDiamondId?._id &&
                  firstStepData.engagementRingId?.price &&
                  secondStepData?.looseDiamondId?.price
                  ? '$' + (+firstStepData.engagementRingId?.price?.$numberDecimal +
                    +secondStepData?.looseDiamondId?.price?.$numberDecimal)
                  : ""}

                {secondStepData &&
                  firstStepData &&
                  firstStepData?.looseDiamondId?._id &&
                  secondStepData.engagementRingId?.price &&
                  firstStepData?.looseDiamondId?.price
                  ? '$' + (+secondStepData.engagementRingId?.price?.$numberDecimal +
                    +firstStepData?.looseDiamondId?.price?.$numberDecimal)
                  : ""}
              </p>
            </div>
          </li>
        </ul>
      </Container>
    </div>
  );
};

export default ProgressStrip;
