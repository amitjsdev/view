import React from "react";
import { Button, Form, FormGroup, Label } from "reactstrap";
import { CustomButton } from "../../css/global";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as Yup from "yup";

const validationSchema = Yup.object().shape({
  email: Yup.string().required("Email is required").email("Email is invalid"),
});

const ForgotPassword = ({ forgotHandle, forgotToggle }) => {
  const { errors, register, handleSubmit } = useForm({
    resolver: yupResolver(validationSchema),
  });

  return (
    <>
      <h2>Forgot Password</h2>
      <h6 className="mb-5">
        Verification link will be send to Registered email id
      </h6>

      <Form onSubmit={handleSubmit(forgotHandle)} noValidate autoComplete="off">
        <FormGroup className="email">
          <Label>Email</Label>
          <div className="icon"></div>

          <input type="email" name="email" ref={register} />
          {errors.email && (
            <span className="errorMessage">{errors.email.message}</span>
          )}
        </FormGroup>
        <div className="submit d-flex justify-content-between">
          <CustomButton type="submit" dark>
            Submit
          </CustomButton>
          <Button
            color="link"
            className="login-again"
            type="button"
            onClick={forgotToggle}
          >
            Login
          </Button>
        </div>
      </Form>
    </>
  );
};

export default ForgotPassword;
