import React from "react";
import { Container } from "reactstrap";

// images
import { ReactComponent as Day } from "../../assets/images/usb/day.svg";
import { ReactComponent as Delivery } from "../../assets/images/usb/fast-delivery.svg";
import { ReactComponent as Cert } from "../../assets/images/usb/inde-cert.svg";
import { ReactComponent as Life } from "../../assets/images/usb/lifetime.svg";
import { ReactComponent as Warranty } from "../../assets/images/usb/lifetimewarranty.svg";
import { ReactComponent as Ring } from "../../assets/images/usb/wedding-rings-couple.svg";

const USP = () => {
  return (
    <div className="usp">
      <Container>
        <ul className="list d-flex align-items-center">
          <li>
            <Delivery width="98px" height="58px" fill="#fff" />
            <h5>Free Shipping</h5>
          </li>
          <li>
            <Cert width="66px" height="64px" fill="#fff" />
            <h5>Independentley Certified</h5>
          </li>
          <li>
            <Ring width="66px" height="58px" fill="#fff" />
            <h5>Free Resizing</h5>
          </li>
          <li>
            <Day width="57px" height="57px" fill="#fff" />
            <h5>
              100 Day Returns <br /> <span>(No Questions Asked)</span>
            </h5>
          </li>
          <li>
            <Life width="55px" height="55px" fill="#fff" />
            <h5>Life Time Upgrade</h5>
          </li>
          <li>
            <Warranty width="52px" height="52px" fill="#fff" />
            <h5>Life Time Guarantee </h5>
          </li>
        </ul>
      </Container>
    </div>
  );
};

export default USP;
