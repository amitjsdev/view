import React from "react";
import { Container, Row, Col } from "reactstrap";
import Paypal from "../../assets/images/logo/paypal.png";
import Maestro from "../../assets/images/logo/maestro.jpg";
import AmericanExpress from "../../assets/images/logo/americanexpress.png";
export default function Footer() {
  return (
    <div>
      <footer>
        <Container>
          <Row>
            <Col md={3}>
              <h2>About Diamonds</h2>
              <ul className="list">
                <li>Contact us</li>
                <li>FAQ</li>
                <li>Testimonials</li>
                <li>Press</li>
                <li>Become an Affiliate</li>
                <li>Order Status</li>
                <li>Return</li>
                <li>Give us your Feedback</li>
              </ul>
            </Col>
            <Col md={3}>
              <h2>Why Radix</h2>
              <ul className="list">
                <li>Contact us</li>
                <li>FAQ</li>
                <li>Testimonials</li>
                <li>Press</li>
                <li>Become an Affiliate</li>
                <li>Order Status</li>
                <li>Return</li>
                <li>Give us your Feedback</li>
              </ul>
            </Col>

            <Col md={3}>
              <h2>About Radix</h2>
              <ul className="list">
                <li>Contact us</li>
                <li>FAQ</li>
                <li>Testimonials</li>
                <li>Press</li>
                <li>Become an Affiliate</li>
                <li>Order Status</li>
                <li>Return</li>
                <li>Give us your Feedback</li>
              </ul>
            </Col>
            <Col md={3}>
              <h2>Guides & Education</h2>
              <ul className="list">
                <li>Contact us</li>
                <li>FAQ</li>
                <li>Testimonials</li>
                <li>Press</li>
                <li>Become an Affiliate</li>
                <li>Order Status</li>
                <li>Return</li>
                <li>Give us your Feedback</li>
              </ul>
            </Col>
          </Row>
        </Container>
      </footer>
      <div className="logoBanner">
        <ul className="list align-items-center">
          <li className="cursor-">
            <img className="logoImg" src={Paypal} />
          </li>
          <li className="cursor-">
            <img className="logoImg" src={AmericanExpress} />
          </li>
          <li className="cursor-">
            <img className="logoImg" src={Maestro} />
          </li>
         
        </ul>
      </div>
      <div className="copyRight">
        <p>Copy Right@Radix</p>
      </div>
    </div>
  );
}
