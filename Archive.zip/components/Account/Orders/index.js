import React, { useEffect, useState } from "react";
import APIUtil from "../../../api";
import { UserDetails } from "../../../constant";
import { Table } from 'reactstrap';
import dummyImg from "../../../assets/images/er-Img.jpeg"
const api = new APIUtil();

const UsersOrder = () => {
  const user = UserDetails();
  const [orders, setOrders] = useState([]);
  useEffect(() => {
    const token = localStorage.getItem("token");
    const headers = {
      Authorization: `Bearer ${token}`,
    };
    //.get(`orders/orderDetails?pageNumber=1&user_id=${user._id}`, { headers })

    api
    .get(`orders/orderDetails?pageNumber=1&user_id=${user._id}`, { headers })
      .then((res) => {
        let orderData = Object.values(res.data)
        console.log('orderData',orderData)
        setOrders(orderData[2].products)
      });
  }, []);

  return <div class="users-table-wrap">
    <Table>
      {orders && orders.length > 0 && orders.map((item) => {
        return (
          <>
            <thead>
              <tr>
                <th>Order Number - {item?._id}</th>
                <th><span>Tack</span></th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>
                  <div className="productDiv">
                    <div className="productImgDiv"><img className="productImg" src={dummyImg} /></div>
                    <div className="productName"><p>Channel-Set Huggie Hoop Earrings 18K Rose Gold <span>(0.35 ct.tw)</span></p></div>
                  </div>
                </td>
                <td>
                <div className="productDelivery"><p>Delivered on 06 march 2021 <span>Delivered Through FedEx Priority Shipping</span></p></div>
                </td>
              </tr>
            </tbody>
            <tfoot>
              <tr>
                <th></th>
                <th><span>Order Total -</span> ${item.total_amount?.$numberDecimal}</th>
              </tr>
            </tfoot>
          </>
        )
      })
      }
    </Table>

  </div>;
};

export default UsersOrder;
