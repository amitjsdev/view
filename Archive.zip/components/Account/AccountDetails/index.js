import React, { useEffect, useState } from "react";
import { Form } from "reactstrap";
import { useForm, Controller } from "react-hook-form";
import APIUtil from "../../../api";
import DatePicker from "react-date-picker";
import moment from "moment";
import { toast } from "react-toastify";
import { useDispatch } from "react-redux";
import * as actions from "../../../store/actions/index";
import { CustomButton } from "../../../css/global";

const api = new APIUtil();

const AccountDetail = ({ editMode, setEditMode }) => {
  const dispatch = useDispatch();
  const [userDetail, setUserDetail] = useState(null);
  const [dateOfBirth, setDateOfBirth] = useState(null);
  const [dateOfAnni, setDateOfAnni] = useState();
  const [checked, setChecked] = useState({
    Other: false,
    Male: false,
    Female: false,
  });

  console.log(dateOfBirth);

  useEffect(() => {
    const token = localStorage.getItem("token");
    const headers = {
      Authorization: `Bearer ${token}`,
    };
    api.get("users/myProfile", { headers }).then((res) => {
      setUserDetail(res.data.data);
      setDateOfBirth(
        res.data.data?.dateOfBrth ? res.data.data.dateOfBrth : null
      );
      // setDateOfAnni(
      //   res.data.data?.dateOfAnni ? res.data.data?.dateOfAnni : null
      // );
      setChecked(() => {
        return {
          Female: res.data.data?.gender === "Female" ? true : false,
          Other: res.data.data?.gender === "Other" ? true : false,
          Male: res.data.data?.gender === "Male" ? true : false,
        };
      });
    });
  }, []);

  const { register, handleSubmit, control } = useForm({});

  const onSubmit = (data) => {
    const dateOfBrth = moment(data.dateOfBrth).format("DD/MM/YYYY");
    const dateOfAnni = moment(data.dateOfAnni).format("DD/MM/YYYY");
    const token = localStorage.getItem("token");
    const headers = {
      Authorization: `Bearer ${token}`,
    };

    api
      .post(
        "users/updateProfile",
        { ...data, dateOfBrth, dateOfAnni },
        { headers: headers }
      )
      .then((res) => {
        toast.success("Details Updated!");

        api.get("users/myProfile", { headers }).then((res) => {
          setUserDetail(res.data.data);
          dispatch(actions.setCurrentUser(res.data.data));
        });
        setEditMode(!editMode);
      });
  };

  const onChange = (e) => {
    const init = e.target.value;
    setUserDetail({
      ...userDetail,
      [e.target.name]: init,
    });
  };

  const handleChange = (e) => {
    if (e.target.value === "Other") {
      setChecked(() => {
        return { Male: false, Female: false, Other: true };
      });
    }
    if (e.target.value === "Male") {
      setChecked(() => {
        return { Female: false, Other: false, Male: true };
      });
    }
    if (e.target.value === "Female") {
      setChecked(() => {
        return { Male: false, Other: false, Female: true };
      });
    }
  };

  return (
    <Form
      onSubmit={handleSubmit(onSubmit)}
      noValidate
      autoComplete="off"
      className={`${editMode ? "edit-mode" : "no"}`}
    >
      <div className="form-group">
        <label>First Name</label>
        <input
          type="text"
          name="first_name"
          readOnly={editMode ? false : true}
          className="form-control"
          ref={register}
          value={userDetail?.first_name ? userDetail.first_name : ""}
          onChange={(e) => onChange(e)}
        />
        <span></span>
      </div>

      <div className="form-group">
        <label>Last Name</label>
        <input
          type="text"
          name="last_name"
          readOnly={editMode ? false : true}
          className="form-control"
          ref={register}
          value={userDetail?.last_name ? userDetail.last_name : ""}
          onChange={(e) => onChange(e)}
        />
      </div>

      <div className="form-group">
        <label>Email</label>
        <input
          type="mail"
          name="email"
          readOnly={editMode ? false : true}
          className="form-control"
          ref={register}
          value={userDetail?.email ? userDetail.email : ""}
          onChange={(e) => onChange(e)}
        />
      </div>

      <div className={`form-group ${editMode ? "enable" : "disable"}`}>
        <label>Gender</label>
        {editMode ? (
          <div className="radio-btns-group d-flex">
            <div className="radio-btn">
              <label>
                Other
                <input
                  type="radio"
                  name="gender"
                  value="Other"
                  ref={register}
                  id="other"
                  onChange={(e) => handleChange(e)}
                  checked={checked.Other}
                />
                <span />
              </label>
            </div>
            <div className="radio-btn">
              <label>
                Female
                <input
                  type="radio"
                  name="gender"
                  value="Female"
                  ref={register}
                  id="female"
                  onChange={(e) => handleChange(e)}
                  checked={checked.Female}
                />
                <span />
              </label>
            </div>

            <div className="radio-btn">
              <label>
                Male
                <input
                  type="radio"
                  name="gender"
                  value="Male"
                  ref={register}
                  id="Male"
                  onChange={(e) => handleChange(e)}
                  checked={checked.Male}
                />
                <span />
              </label>
            </div>
          </div>
        ) : userDetail?.gender ? (
          userDetail?.gender
        ) : (
          "Not Selected"
        )}
      </div>

      {/* <div className={`form-group ${editMode ? "enable" : "disable"}`}>
        <label>DOB</label>
        {editMode ? (
          <Controller
            name="dateOfBrth"
            control={control}
            render={() => {
              return (
                <DatePicker
                  format="dd/MM/yyyy"
                  dayPlaceholder="dd"
                  monthPlaceholder="MM"
                  yearPlaceholder="yyyy"
                  clearIcon={null}
                  calendarIcon={null}
                  onChange={(value) => {
                    setDateOfBirth(value);
                  }}
                  value={new Date(dateOfBirth)}
                />
              );
            }}
          />
        ) : userDetail?.dateOfBrth ? (
          userDetail?.dateOfBrth
        ) : (
          "Not Selected"
        )}
      </div> */}

      {/* <div className={`form-group ${editMode ? "enable" : "disable"}`}>
        <label>Anniversary Date</label>
        {editMode ? (
          <Controller
            name="dateOfAnni"
            control={control}
            render={(props) => {
              return (
                <DatePicker
                  format="dd/MM/yyyy"
                  dayPlaceholder="dd"
                  monthPlaceholder="MM"
                  yearPlaceholder="yyyy"
                  clearIcon={null}
                  calendarIcon={null}
                  onChange={(value) => {
                    setDateOfAnni(value);
                  }}
                  value={dateOfAnni ? new Date(dateOfAnni) : null}
                />
              );
            }}
          />
        ) : userDetail?.dateOfAnni ? (
          userDetail?.dateOfAnni
        ) : (
          "Not Selected"
        )}
      </div> */}

      <div className="form-group">
        <label>News & offers</label>
        {editMode ? (
          <div className="radio-btns-group">
            <div className="radio-btn d-flex">
              <div className="form-group">
                <label>
                  Subscribe
                  <input
                    type="radio"
                    name="subscription"
                    ref={register}
                    id="subscribed"
                  />
                  <span />
                </label>
              </div>
              <div className="form-group">
                <label>
                  Unsubscribe
                  <input
                    type="radio"
                    name="subscription"
                    ref={register}
                    id="unsubscribed"
                  />
                  <span />
                </label>
              </div>
            </div>
          </div>
        ) : (
          "Subscribed"
        )}
      </div>
      {editMode && (
        <div className="form-group d-flex align-items-center">
          <CustomButton light onClick={() => setEditMode(!editMode)}>
            Cancel
          </CustomButton>
          <CustomButton dark type="submit">
            Save
          </CustomButton>
        </div>
      )}
    </Form>
  );
};

export default AccountDetail;
