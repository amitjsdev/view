import React from "react";
import { ReactComponent as Mail } from "../../assets/images/home/mail.svg";
import { ReactComponent as Phone } from "../../assets/images/home/phone.svg";
import { ReactComponent as Live } from "../../assets/images/home/live-chat.svg";

export default function Help() {
  return (
    <section className="need-help">
      <div className="need-help-heading text-center">
        <h4>Need help ? Call us Anytime </h4>
        <p>
          Our Diamond expert team will Available 24/7 to answer your question be
          free to ask you{" "}
        </p>
      </div>
      <div className="need-help-info">
        <div className="container">
          <div className="need-help-inner">
            <ul>
              <li>
                <Mail width="48px" height="38px" />
                <a href="mailto:help@radix.com">help@radix.com</a>
              </li>
              <li>
                <Phone width="38px" height="38px" />
                <a href="tel:1800-858-6936">1800-858-6936</a>
              </li>
              <li>
                <Live width="39px" height="39px" />
                <a href="#">Live chat Room</a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}
