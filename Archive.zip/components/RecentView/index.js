import React from "react";
import Carousel from "react-multi-carousel";

import Slider from "../../assets/images/hoops/landing/sliderimg.png";

const Recent = () => {
  const responsive = {
    desktop: {
      breakpoint: { max: 3000, min: 1024 },
      items: 3,
      slidesToSlide: 3, // optional, default to 1.
    },
    tablet: {
      breakpoint: { max: 1024, min: 464 },
      items: 2,
      slidesToSlide: 2, // optional, default to 1.
    },
    mobile: {
      breakpoint: { max: 464, min: 0 },
      items: 1,
      slidesToSlide: 1, // optional, default to 1.
    },
  };
  return (
    <div className="d-flex align-items-center">
      <Carousel
        showDots={false}
        responsive={responsive}
        ssr={true} // means to render carousel on server-side.
        infinite={true}
        keyBoardControl={true}
        containerClass="carousel-container"
        arrows={false}
        dotListClass="custom-dot-list-style"
        itemClass="carousel-item-padding-40-px"
      >
        <div className="box">
          <span>
            <img src={`${Slider}`} alt="" />
          </span>
          <h3>Diamond Hoop earring</h3>
          <h4>14k White Gold (4 ct.tw)</h4>
        </div>
        <div className="box">
          <span>
            <img src={`${Slider}`} alt="" />
          </span>
          <h3>Diamond Hoop earring</h3>
          <h4>14k White Gold (4 ct.tw)</h4>
        </div>
        <div className="box">
          <span>
            <img src={`${Slider}`} alt="" />
          </span>
          <h3>Diamond Hoop earring</h3>
          <h4>14k White Gold (4 ct.tw)</h4>
        </div>
      </Carousel>
      <h2>
        <span>R</span>ecently <br /> <b>Viewed</b>
      </h2>
    </div>
  );
};

export default Recent;
