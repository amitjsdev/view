import React from "react";
import { Container } from "reactstrap";
import { Link } from "react-router-dom";

//css
import { CustomButton } from "../../css/global";

// images
import Setting from "../../assets/images/home/settings.png";
import SettingDiamond from "../../assets/images/home/diamond1.png";

const CreateYourOwn = () => {
  return (
    <section className="create-your-ring">
      <Container>
        <div className="create-your-ring-inner">
          <div className="create-your-ring-left">
            <div className="common-heading">
              <h3>
                <span>C</span>reate your Own Ring
              </h3>
            </div>
            <p>
              Fall in love with this hand-selected collection of luxurious lab
              created diamond jewelry
            </p>
            <div className="call-expert">
              Call an Expert <a href="tel:1800-585-6964">1800-585-6964</a>
            </div>
          </div>

          <div className="create-ring-right">
            <div className="ring-options">
              <div className="img-container">
                <img src={`${Setting}`} alt="" />
              </div>
              <Link to="/build-your-own-ring/settings">
                <CustomButton cursive className="setting">
                  Start with a Settings
                </CustomButton>
              </Link>
            </div>

            <div className="ring-options">
              <div className="img-container">
                <img src={`${SettingDiamond}`} alt="" />
              </div>
              <Link to="/diamond-search">
                <CustomButton cursive>Start with a Diamonds</CustomButton>
              </Link>
            </div>
          </div>
        </div>
      </Container>
    </section>
  );
};

export default CreateYourOwn;
