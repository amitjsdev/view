import React from "react";

//images
import Client from "../../assets/images/detail/client.png";
import Rating from "../../assets/images/detail/rating.svg";

const Testimonial = () => {
  return (
    <section className="testimonials">
      <div className="container">
        <div className="common-heading">
          <h3>
            <span>T</span>estimonial's
          </h3>
        </div>

        <div className="testimonial-container">
          <div className="testimonial-img">
            <img src={`${Client}`} alt="" />
          </div>

          <div className="testimonial-caption">
            <span className="client-name">Linda Syoeo</span>
            <div className="rating">
              <a href="">
                <img src={`${Rating}`} alt="" />
              </a>
              <a href="">
                <img src={`${Rating}`} alt="" />
              </a>
              <a href="">
                <img src={`${Rating}`} alt="" />
              </a>
              <a href="">
                <img src={`${Rating}`} alt="" />
              </a>
              <a href="">
                <img src={`${Rating}`} alt="" />
              </a>
            </div>

            <blockquote>
              One best site to buy Diamonds jewellry online
            </blockquote>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonial;
