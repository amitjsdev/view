import React, { useState } from "react";
import Carousel from "react-multi-carousel";
import "react-multi-carousel/lib/styles.css";
import { useHistory } from "react-router-dom";

const responsive = {
  desktop: {
    breakpoint: { max: 3000, min: 1024 },
    items: 4,
    slidesToSlide: 1, // optional, default to 1.
  },
  tablet: {
    breakpoint: { max: 1024, min: 464 },
    items: 2,
    slidesToSlide: 1, // optional, default to 1.
  },
  mobile: {
    breakpoint: { max: 464, min: 0 },
    items: 1,
    slidesToSlide: 1, // optional, default to 1.
  },
};
const Slider = (props) => {
  const history = useHistory();

  const [redirect, setRedirect] = useState({});

  const sliderData = props.data.map((val, index) => {
    return (
      <div key={index} onClick={(e) => redirectPath(e, val)}>
        <span>
          {val.images.studsImages.map((img, index) => {
            return <img key={index} className="img-fluid" src={img} alt="" />;
          })}
        </span>
        <h4>
          Diamond Stud Earring {val.metalCarat}K {val.metal} Gold (
          {val.diamondWeight?.$numberDecimal} ct. wt.)
        </h4>
        <h5>${val.price}</h5>
      </div>
    );
  });

  const redirectPath = (e) => {
    props.data.map((val, index) => {
      const id = val._id;
    });
    const newValue = sliderData.id;

    setRedirect(newValue);
    props.onClick(newValue);
    // history.push({
    //   pathname: `/productDetail/${id._id}`,
    // });
    setRedirect();
  };

  return (
    <div>
      <Carousel
        showDots={false}
        responsive={responsive}
        ssr={true}
        infinite={true}
        autoPlaySpeed={1000}
        keyBoardControl={true}
        arrows={false}
        containerClass="carousel-container"
        removeArrowOnDeviceType={false}
        dotListClass="custom-dot-list-style"
        itemClass="carousel-item-padding-40-px"
      >
        {sliderData}
      </Carousel>
    </div>
  );
};

export default Slider;
