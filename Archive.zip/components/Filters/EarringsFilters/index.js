import React, { useState, useEffect } from "react";
import {
  BackType,
  HoopProngs,
  HoopSizes,
  StoneShape,
} from "../../../constant/filters";
import CustomDropdown from "../../Dropdown";
import PriceSlide from "../Price";
import Metal from "../Metal";

// CSS
import { Filters } from "../../../css/filters";

const CustomFilters = (props) => {
  const {
    filterPage,
    tags,
    minMax,
    setMinMax,
    setSelectedMetal,
    selectedMetal,
    setFiltersvalues,
    filtersvalues,
    stoneShape,
    setStoneShape,
    hoopProngs,
    setHoopProngs,
    backType,
    setBackType,
    hoopSizes,
    setHoopSizes,
    setTags,
    finalMetal,
    setFinalMetal,
    setFinalValueRange,
    finalValueRange,
  } = props;

  //check current path for hoops filter
  useEffect(() => {
    var pathname = window.location.pathname;
    var currentPage = pathname.includes("hoops");
    setCurrentPath(currentPage);
  }, [props, tags]);

  const [currentPath, setCurrentPath] = useState(false);
  //On change filter values adding values in tag and filter bits
  const handleChange = (e) => {
    const singleValue = e?.value;
    const options = e && e.key ? e.key : [];
    if (filtersvalues.includes(singleValue)) {
      const filter = filtersvalues.filter(function (data) {
        return data !== singleValue;
      });
      setFiltersvalues(filter);

      switch (options) {
        case "stoneshape":
          const filter1 = stoneShape.filter(function (data) {
            return data !== singleValue;
          });
          setStoneShape(filter1);

          break;
        case "hoopsizes":
          const filter2 = hoopSizes.filter(function (data) {
            return data !== singleValue;
          });
          setHoopSizes(filter2);

          break;
        case "hoopprongs":
          const filter3 = hoopProngs.filter(function (data) {
            return data !== singleValue;
          });
          setHoopProngs(filter3);

          break;
        case "backtype":
          const filter4 = backType.filter(function (data) {
            return data !== singleValue;
          });
          setBackType(filter4);
          break;
        default:
      }
    } else {
      setFiltersvalues((prevState) => {
        const x = [...prevState, singleValue];
        return x;
      });
      switch (options) {
        case "stoneshape":
          setStoneShape((prevState) => {
            const x = [...prevState, singleValue];
            return x;
          });

          setTags((prevState) => {
            const y = [...prevState, singleValue];
            return y;
          });

          break;
        case "hoopsizes":
          if (currentPath) {
            setHoopSizes((prevState) => {
              const x = [...prevState, singleValue];
              return x;
            });

            setTags((prevState) => {
              const y = [...prevState, singleValue];
              return y;
            });
          }

          break;
        case "hoopprongs":
          if (currentPath) {
            setHoopProngs((prevState) => {
              const x = [...prevState, singleValue];
              return x;
            });

            setTags((prevState) => {
              const y = [...prevState, singleValue];
              return y;
            });
          }
          break;
        case "backtype":
          setBackType((prevState) => {
            const x = [...prevState, singleValue];
            return x;
          });
          setTags((prevState) => {
            const y = [...prevState, singleValue];
            return y;
          });
          break;
        default:
      }
    }
  };

  return (
    <Filters>
      <div className="filterSection">
        <h4>
          <span>H</span>ello,
        </h4>
        <div className="d-flex filter-paragraph flex-wrap align-items-center">
          Please help me to sort result of
          <PriceSlide
            filterPage={filterPage}
            setMinMax={setMinMax}
            minMax={minMax}
            setFinalValueRange={setFinalValueRange}
            finalValueRange={finalValueRange}
          />
          with interesting
          <Metal
            path="metal"
            filterPage={filterPage}
            setSelectedMetal={setSelectedMetal}
            selectedMetal={selectedMetal}
            setTags={setTags}
            tags={tags}
            finalMetal={finalMetal}
            setFinalMetal={setFinalMetal}
          />
          with Superb
          <CustomDropdown
            path="stone"
            filterPage={filterPage}
            handleChange={handleChange}
            setTags={setTags}
            tags={tags}
            options={StoneShape}
            placeholder="Stone Shape"
          />
          {currentPath ? (
            <>
              delightfull
              <CustomDropdown
                path="hoops"
                filterPage={filterPage}
                handleChange={handleChange}
                setTags={setTags}
                tags={tags}
                options={HoopSizes}
                placeholder="Hoops size"
              />
              And
              <CustomDropdown
                path="hoops"
                filterPage={filterPage}
                handleChange={handleChange}
                setTags={setTags}
                tags={tags}
                options={HoopProngs}
                placeholder="Hoops Prongs"
              />
            </>
          ) : (
            ""
          )}
          with design
          <CustomDropdown
            filterPage={filterPage}
            path="earrings"
            handleChange={handleChange}
            setTags={setTags}
            tags={tags}
            options={BackType}
            placeholder="Earrings Back"
          />
          {/* of
          <CustomDropdown
            handleChange={handleChange}
            options={BackType}
            placeholder="Designs"
          /> */}
        </div>
      </div>
    </Filters>
  );
};

export default CustomFilters;
