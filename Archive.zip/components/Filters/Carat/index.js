import React, { useEffect, useState } from "react";
import { Suspense } from "react";
import InputRange from "react-input-range";
import { FormGroup } from "reactstrap";

const CaratSlide = (props) => {
  const { setFinalValueRange, caratValue } = props;

  const [values, setValues] = useState({
    min: Number(0),
    max: Number(100),
  });

  const [defaultValues, setDefaultValues] = useState({
    min: Number(0),
    max: Number(100),
  });

  const [minValue, setMinValue] = useState({ min: defaultValues.min });
  const [maxValue, setMaxValue] = useState({ max: defaultValues.max });
  const [focus, setFocus] = useState(false);
  const [empty, setEmpty] = useState(true);
  const [load, setLoad] = useState(false);

  const focused = () => {
    setFocus(!focus);
  };

  useEffect(() => {
    if (caratValue !== undefined) {
      setDefaultValues({
        min: Number(caratValue.min),
        max: Number(caratValue.max),
      });

      setValues({
        min: Number(caratValue.min),
        max: Number(caratValue.max),
      });
      setMinValue({ min: Number(caratValue.min) });
      setMaxValue({ max: Number(caratValue.max) });
    }
  }, [caratValue]);

  // Function to Change values on enter key
  const keypressHandler = (e) => {
    focused();
    if (e.key === "Enter") {
      // to set minimum Values in range slider and minimum input field
      if (
        (minValue.min > defaultValues.min &&
          minValue.min < defaultValues.max &&
          minValue.min !== defaultValues.max) ||
        minValue.min === defaultValues.min
      ) {
        setValues((prevState) => {
          return {
            ...prevState,
            min: minValue.min,
          };
        });
        setFinalValueRange((prevState) => {
          return {
            ...prevState,
            min: minValue.min,
          };
        });
      } else if (
        minValue.min < defaultValues.min ||
        minValue.min > defaultValues.max ||
        minValue.min === defaultValues.max ||
        empty
      ) {
        setValues((prevState) => {
          return {
            ...prevState,
          };
        });
        setMinValue(defaultValues);
        setFinalValueRange((prevState) => {
          return {
            ...prevState,
            min: defaultValues.min,
          };
        });
      }

      // to set maximum Values in range slider and maximum input field
      if (
        (maxValue.max < defaultValues.max &&
          maxValue.max > defaultValues.min &&
          maxValue.max !== defaultValues.min) ||
        maxValue.max === defaultValues.max
      ) {
        setValues((prevState) => {
          return {
            ...prevState,
            max: maxValue.max,
          };
        });
        setFinalValueRange((prevState) => {
          return {
            ...prevState,
            max: maxValue.max,
          };
        });
      } else if (
        maxValue.max < defaultValues.min ||
        maxValue.max > defaultValues.max ||
        maxValue.max === defaultValues.min ||
        empty
      ) {
        setValues((prevState) => {
          return {
            ...prevState,
          };
        });
        setMaxValue(defaultValues);
        setFinalValueRange((prevState) => {
          return {
            ...prevState,
            max: defaultValues.max,
          };
        });
      }
    }
  };

  // On blur function to loose focus and update state after loosing focus of respected input
  const blur = () => {
    focused();
    // to set minimum Values in range slider and minimum input field
    if (
      (minValue.min > defaultValues.min &&
        minValue.min < defaultValues.max &&
        minValue.min !== defaultValues.max) ||
      minValue.min === defaultValues.min
    ) {
      setValues((prevState) => {
        return {
          ...prevState,
          min: minValue.min,
        };
      });
      setFinalValueRange((prevState) => {
        return {
          ...prevState,
          min: minValue.min,
        };
      });
    } else if (
      minValue.min < defaultValues.min ||
      minValue.min > defaultValues.max ||
      minValue.min === defaultValues.max ||
      empty
    ) {
      setValues((prevState) => {
        return {
          ...prevState,
        };
      });
      setMinValue(defaultValues);
      setFinalValueRange((prevState) => {
        return {
          ...prevState,
          min: defaultValues.min,
        };
      });
    }

    // to set maximum Values in range slider and maximum input field
    if (
      (maxValue.max < defaultValues.max &&
        maxValue.max > defaultValues.min &&
        maxValue.max !== defaultValues.min) ||
      maxValue.max === defaultValues.max
    ) {
      setValues((prevState) => {
        return {
          ...prevState,
          max: maxValue.max,
        };
      });
      setFinalValueRange((prevState) => {
        return {
          ...prevState,
          max: maxValue.max,
        };
      });
    } else if (
      maxValue.max < defaultValues.min ||
      maxValue.max > defaultValues.max ||
      maxValue.max === defaultValues.min ||
      empty
    ) {
      setValues((prevState) => {
        return {
          ...prevState,
        };
      });
      setMaxValue(defaultValues);
      setFinalValueRange((prevState) => {
        return {
          ...prevState,
          max: defaultValues.max,
        };
      });
    }
  };

  // It will detech change in minimum amount field
  const inputMinChange = (e) => {
    const minValues = {
      [e.target.name]: Math.round(e.target.value * 100) / 100,
      max: values.max,
    };

    if (e.target.value !== "") {
      setMinValue(minValues);
    } else {
      setEmpty(!empty);
      setMinValue(minValues);
    }
  };

  // It will detect change in maximum amount field
  const inputMaxChange = (e) => {
    const maxValues = {
      [e.target.name]: Math.round(e.target.value * 100) / 100,
      min: values.min,
    };

    if (e.target.value !== "") {
      setMaxValue(maxValues);
    } else {
      setEmpty(!empty);
      setMaxValue(maxValues);
    }
  };

  // Input range Change - it will detect every change in range slider
  const handleOnChange = (value) => {
    const min = Math.round(value.min * 100) / 100;
    const max = Math.round(value.max * 100) / 100;

    setValues({ min: min, max: max });
    setMinValue({ min: min });
    setMaxValue({ max: max });
  };

  const handleComplete = (value) => {
    setFinalValueRange(value);
    setLoad(!load);
  };

  return (
    <Suspense>
      <div className={`dropdown ${props.diamond && "diamonds"}`}>
        <h4>Carat</h4>
        <div className={`dropdown-menu open`}>
          <InputRange
            maxValue={defaultValues.max === 0 ? 0.3 : defaultValues.max}
            step={0.1}
            minValue={defaultValues.min}
            value={values}
            onChange={(value) => handleOnChange(value)}
            onChangeComplete={(value) => handleComplete(value)}
          />
          <ul className="list">
            <li>
              <div className="d-flex">
                <FormGroup>
                  <label>Min</label>
                  <input
                    type="number"
                    min={values.min}
                    max={values.max}
                    className="form-control"
                    value={minValue.min}
                    name="min"
                    onFocus={focused}
                    onBlur={blur}
                    onChange={(e) => inputMinChange(e)}
                    onKeyPress={(e) => keypressHandler(e)}
                  />
                </FormGroup>
                <FormGroup>
                  <label>Max</label>
                  <input
                    type="number"
                    min={values.min}
                    max={values.max}
                    className="form-control"
                    value={maxValue.max}
                    name="max"
                    onFocus={focused}
                    onBlur={blur}
                    onChange={(e) => inputMaxChange(e)}
                    onKeyPress={(e) => keypressHandler(e)}
                  />
                </FormGroup>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </Suspense>
  );
};

export default CaratSlide;
