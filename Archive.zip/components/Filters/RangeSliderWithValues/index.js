import React, { useState } from "react";
import InputRange from "react-input-range";

const RangeSliderWithValues = (props) => {
  const [values, setValues] = useState({
    min: parseInt(0),
    max: parseInt(4),
  });

  const [colorValue, setColorValue] = useState({
    min: parseInt(0),
    max: parseInt(8),
  });
  const [clarityValue, setClarityValue] = useState({
    min: parseInt(0),
    max: parseInt(10),
  });

  const [load, setLoad] = useState(false);

  // Input range Change - it will detect every change in range slider
  const handleOnChange = (value) => {
    setValues(value);
  };
  const handleOnColorChange = (value) => {
    setColorValue(value);
  };
  const handleOnClarityChange = (value) => {
    setClarityValue(value);
  };

  const handleComplete = (value) => {
    props.setCutRange({ min: value.min + 1, max: value.max });
    setLoad(!load);
    let arr = [];
    for (let i = value.min + 1; i <= value.max; i++) {
      arr.push(i);
    }
    console.log(arr);
    let element = document.getElementsByClassName("quality");
    for (let z = 1; z <= element.length; z++) {
      let classMethod = document.getElementById("selected-" + z);
      if (!arr.includes(z)) {
        classMethod.classList.add("unselected");
      } else {
        classMethod.classList.remove("unselected");
      }
    }
  };

  const handleColorComplete = (value) => {
    props.setColorRange({ min: value.min + 1, max: value.max });

    let arr = [];
    for (let i = value.min + 1; i <= value.max; i++) {
      arr.push(i);
    }
    let element = document.getElementsByClassName("color");
    for (let z = 1; z <= element.length; z++) {
      let classMethod = document.getElementById("color-" + z);
      if (!arr.includes(z)) {
        classMethod.classList.add("unselected");
      } else {
        classMethod.classList.remove("unselected");
      }
    }
  };

  const handleClarityComplete = (value) => {
    props.setClarityRange({ min: value.min + 1, max: value.max });

    let arr = [];
    for (let i = value.min + 1; i <= value.max; i++) {
      arr.push(i);
    }
    let element = document.getElementsByClassName("clarity");
    for (let z = 1; z <= element.length; z++) {
      let classMethod = document.getElementById("clarity-" + z);
      if (!arr.includes(z)) {
        classMethod.classList.add("unselected");
      } else {
        classMethod.classList.remove("unselected");
      }
    }
  };

  const Title = () => {
    if (props.cut) {
      return "Cut";
    }
    if (props.color) {
      return "Color";
    }
    if (props.clarity) {
      return "Clarity";
    }
  };

  return (
    <div className={`dropdown ${props.diamond && "diamonds"}`}>
      <h4>{Title()}</h4>
      <div className="dropdown-menu open">
        {props.cut && (
          <InputRange
            maxValue={4}
            minValue={0}
            value={values}
            onChange={(value) => handleOnChange(value)}
            onChangeComplete={(value) => handleComplete(value)}
          />
        )}

        {props.color && (
          <InputRange
            maxValue={8}
            minValue={0}
            value={colorValue}
            onChange={(value) => handleOnColorChange(value)}
            onChangeComplete={(value) => handleColorComplete(value)}
          />
        )}

        {props.clarity && (
          <InputRange
            maxValue={10}
            minValue={0}
            value={clarityValue}
            onChange={(value) => handleOnClarityChange(value)}
            onChangeComplete={(value) => handleClarityComplete(value)}
          />
        )}

        {props.cut && (
          <div className="slider-values d-flex">
            <div className="quality" id="selected-1">
              Ideal
            </div>
            <div className="quality" id="selected-2">
              Astor Ideal
            </div>
            <div className="quality" id="selected-3">
              Very Good
            </div>
            <div className="quality" id="selected-4">
              Good
            </div>
          </div>
        )}
        {props.color && (
          <div className="slider-values d-flex">
            <div className="color" id="color-1">
              D
            </div>
            <div className="color" id="color-2">
              E
            </div>
            <div className="color" id="color-3">
              F
            </div>
            <div className="color" id="color-4">
              G
            </div>
            <div className="color" id="color-5">
              H
            </div>
            <div className="color" id="color-6">
              I
            </div>
            <div className="color" id="color-7">
              J
            </div>
            <div className="color" id="color-8">
              K
            </div>
          </div>
        )}
        {props.clarity && (
          <div className="slider-values d-flex">
            <div className="clarity" id="clarity-1">
              FL
            </div>
            <div className="clarity" id="clarity-2">
              IF
            </div>
            <div className="clarity" id="clarity-3">
              VVS1
            </div>
            <div className="clarity" id="clarity-4">
              VVS2
            </div>
            <div className="clarity" id="clarity-5">
              VS1
            </div>
            <div className="clarity" id="clarity-6">
              VS2
            </div>
            <div className="clarity" id="clarity-7">
              SI1
            </div>
            <div className="clarity" id="clarity-8">
              SI2
            </div>
            <div className="clarity" id="clarity-9">
              SI3
            </div>
            <div className="clarity" id="clarity-10">
              I
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default RangeSliderWithValues;
