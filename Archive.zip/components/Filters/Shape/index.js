import React, { useState, useEffect } from "react";
import { diamondShape } from "../../../constant/filters";

import { ReactComponent as Round } from "../../../assets/images/looseDiamonds/roundShape.svg";
import { ReactComponent as Princess } from "../../../assets/images/looseDiamonds/princessshape.svg";
import { ReactComponent as Emerald } from "../../../assets/images/looseDiamonds/emeraldShape.svg";
import { ReactComponent as Asscher } from "../../../assets/images/looseDiamonds/asscherShape.svg";
import { ReactComponent as Cushion } from "../../../assets/images/looseDiamonds/cushionshape.svg";
import { ReactComponent as Marquise } from "../../../assets/images/looseDiamonds/marquiseShape.svg";
import { ReactComponent as Radiant } from "../../../assets/images/looseDiamonds/radiantShape.svg";
import { ReactComponent as Oval } from "../../../assets/images/looseDiamonds/ovalShape.svg";
import { ReactComponent as Pear } from "../../../assets/images/looseDiamonds/pearShape.svg";
import { ReactComponent as Heart } from "../../../assets/images/looseDiamonds/HeartShape.svg";

const ShapeDiamondFilter = (props) => {
  const { stoneShape } = props;
  const [shape, setShape] = useState(diamondShape);

  const handleSelect = (e) => {
    const shapeActive = shape.map((val) => {
      if (e === val.label) {
        val["clicked"] = !val["clicked"];
        return val;
      } else {
        return { ...val };
      }
    });
    setShape(shapeActive);
  };

  useEffect(() => {
    const filterActiveShapes = shape.filter((val) => val.clicked === true);
    const valueLoop = filterActiveShapes.map((val) => {
      return val.value;
    });
    const activeShapeValues = valueLoop.join();

    props.setSelectShape(activeShapeValues);
  }, [shape]);

  const shapeList = () => {
    return shape.map((val, i) => {
      return (
        <li
          key={i}
          onClick={() => handleSelect(val.label)}
          className={
            stoneShape == val.label ? "active" : val.clicked ? "active" : ""
          }
        >
          <button>
            {val.label === "round" && <Round width="46px" height="46px" />}
            {val.label === "princess" && (
              <Princess width="46px" height="46px" />
            )}
            {val.label === "emerald" && <Emerald width="46px" height="46px" />}
            {val.label === "asscher" && <Asscher width="46px" height="46px" />}
            {val.label === "cushion" && <Cushion width="46px" height="46px" />}
            {val.label === "marquise" && (
              <Marquise width="46px" height="46px" />
            )}
            {val.label === "radiant" && <Radiant width="46px" height="46px" />}
            {val.label === "oval" && <Oval width="46px" height="46px" />}
            {val.label === "pear" && <Pear width="46px" height="46px" />}
            {val.label === "heart" && <Heart width="46px" height="46px" />}
            <p>{val.label}</p>
          </button>
        </li>
      );
    });
  };

  return (
    <div className="filter">
      <h4>Shape</h4>
      <ul className="shape-list">
        {shapeList()}

        {/* <li>
          <button>
            <Round width="46px" height="46px" />
            <p>Round</p>
          </button>
        </li> */}
        {/* <li>
          <button>
            <Princess width="46px" height="46px" />
            <p>Princess</p>
          </button>
        </li>
        <li>
          <button>
            <Emerald width="46px" height="46px" />
            <p>Emerald</p>
          </button>
        </li>
        <li>
          <button>
            <Asscher width="46px" height="46px" />
            <p>Asscher</p>
          </button>
        </li>
        <li>
          <button>
            <Cushion width="46px" height="46px" />
            <p>Cushion</p>
          </button>
        </li>
        <li>
          <button>
            <Marquise width="46px" height="46px" />
            <p>Marquise</p>
          </button>
        </li>
        <li>
          <button>
            <Radiant width="46px" height="46px" />
            <p>Radiant</p>
          </button>
        </li>
        <li>
          <button>
            <Oval width="46px" height="46px" />
            <p>Oval</p>
          </button>
        </li>
        <li>
          <button>
            <Pear width="46px" height="46px" />
            <p>Pear</p>
          </button>
        </li>
        <li>
          <button>
            <Heart width="46px" height="46px" />
            <p>Heart</p>
          </button>
        </li> */}
      </ul>
    </div>
  );
};

export default ShapeDiamondFilter;
