import React, { useEffect, useState } from "react";
import { Suspense } from "react";
import InputRange from "react-input-range";
import { FormGroup } from "reactstrap";

const PriceSlide = (props) => {
  const { minMax, setFinalValueRange } = props;

  // These all states are related with price filter for every page
  const [values, setValues] = useState({
    min: parseInt(1),
    max: parseInt(100),
  });

  const [defaultValues, setDefaultValues] = useState({
    min: parseInt(1),
    max: parseInt(100),
  });

  const [minValue, setMinValue] = useState({ min: defaultValues.min });
  const [maxValue, setMaxValue] = useState({ max: defaultValues.max });

  const [focus, setFocus] = useState(false);
  const [empty, setEmpty] = useState(true);

  const [dropdownOpen, setDropdownOpen] = useState(
    props.diamond || props.cut || props.carat || props.clarity || props.color
      ? true
      : false
  );

  const [load, setLoad] = useState(false);
  const toggle = () => setDropdownOpen((prevState) => !prevState);

  const focused = () => {
    setFocus(true);
  };

  useEffect(() => {
    if (minMax !== undefined) {
      setDefaultValues({
        min: parseInt(minMax.min),
        max: parseInt(minMax.max),
      });

      setValues({ min: parseInt(minMax.min), max: parseInt(minMax.max) });
      setMinValue({ min: parseInt(minMax.min) });
      setMaxValue({ max: parseInt(minMax.max) });
    }
  }, [minMax]);

  // Function to Change values on enter key
  const keypressHandler = (e) => {
    if (e.key === "Enter") {
      setFocus(false);
      // to set minimum Values in range slider and minimum input field
      if (
        (minValue.min > defaultValues.min &&
          minValue.min < defaultValues.max &&
          minValue.min !== defaultValues.max) ||
        minValue.min === defaultValues.min
      ) {
        setValues((prevState) => {
          return {
            ...prevState,
            min: minValue.min,
          };
        });
        setFinalValueRange((prevState) => {
          return {
            ...prevState,
            min: minValue.min,
          };
        });
      } else if (
        minValue.min < defaultValues.min ||
        minValue.min > defaultValues.max ||
        minValue.min === defaultValues.max ||
        empty
      ) {
        setValues((prevState) => {
          return {
            ...prevState,
          };
        });
        setMinValue(defaultValues);
      }

      // to set maximum Values in range slider and maximum input field
      if (
        (maxValue.max < defaultValues.max &&
          maxValue.max > defaultValues.min &&
          maxValue.max !== defaultValues.min) ||
        maxValue.max === defaultValues.max
      ) {
        setValues((prevState) => {
          return {
            ...prevState,
            max: maxValue.max,
          };
        });
        setFinalValueRange((prevState) => {
          return {
            ...prevState,
            max: minValue.max,
          };
        });
      } else if (
        maxValue.max < defaultValues.min ||
        maxValue.max > defaultValues.max ||
        maxValue.max === defaultValues.min ||
        empty
      ) {
        setValues((prevState) => {
          return {
            ...prevState,
          };
        });
        setMaxValue(defaultValues);
      }
    }
  };

  // On blur function to loose focus and update state after loosing focus of respected input
  const blur = () => {
    setFocus(false);
    // to set minimum Values in range slider and minimum input field
    if (
      (minValue.min > defaultValues.min &&
        minValue.min < defaultValues.max &&
        minValue.min !== defaultValues.max) ||
      minValue.min === defaultValues.min
    ) {
      setValues((prevState) => {
        return {
          ...prevState,
          min: minValue.min,
        };
      });
      setFinalValueRange((prevState) => {
        return {
          ...prevState,
          min: minValue.min,
        };
      });
    } else if (
      minValue.min < defaultValues.min ||
      minValue.min > defaultValues.max ||
      minValue.min === defaultValues.max ||
      empty
    ) {
      setValues((prevState) => {
        return {
          ...prevState,
        };
      });
      setMinValue(defaultValues);
      setFinalValueRange((prevState) => {
        return {
          ...prevState,
          min: defaultValues.min,
        };
      });
    }

    // to set maximum Values in range slider and maximum input field
    if (
      (maxValue.max < defaultValues.max &&
        maxValue.max > defaultValues.min &&
        maxValue.max !== defaultValues.min) ||
      maxValue.max === defaultValues.max
    ) {
      setValues((prevState) => {
        return {
          ...prevState,
          max: maxValue.max,
        };
      });
      setFinalValueRange((prevState) => {
        return {
          ...prevState,
          max: minValue.max,
        };
      });
    } else if (
      maxValue.max < defaultValues.min ||
      maxValue.max > defaultValues.max ||
      maxValue.max === defaultValues.min ||
      empty
    ) {
      setValues((prevState) => {
        return {
          ...prevState,
        };
      });
      setMaxValue(defaultValues);
      setFinalValueRange((prevState) => {
        return {
          ...prevState,
          max: defaultValues.max,
        };
      });
    }
  };

  // It will detech change in minimum amount field
  const inputMinChange = (e) => {
    const minValues = {
      [e.target.name]: parseInt(e.target.value),
      max: values.max,
    };
    if (e.target.value !== "") {
      setMinValue(minValues);
    } else {
      setEmpty(!empty);
      setMinValue(minValues);
    }
  };

  // It will detect change in maximum amount field
  const inputMaxChange = (e) => {
    const maxValues = {
      [e.target.name]: parseInt(e.target.value),
      min: values.min,
    };
    if (e.target.value !== "") {
      setMaxValue(maxValues);
    } else {
      setEmpty(!empty);
      setMaxValue(maxValues);
    }
  };

  // Input range Change - it will detect every change in range slider
  const handleOnChange = (value) => {
    setValues(value);
    setMinValue({ min: value.min });
    setMaxValue({ max: value.max });
  };

  // it will hit when slider is completed
  const handleComplete = (value) => {
    // setMinMax(value)
    setFinalValueRange(value);
    setLoad(!load);
  };

  return (
    <Suspense>
      <div className={`dropdown price_dwn ${props.diamond ? "diamonds" : ""}`}>
        <h4 onClick={toggle}>Price</h4>
        <div className={`dropdown-menu ${dropdownOpen && "open"}`}>
          <InputRange
            maxValue={defaultValues.max === 0 ? 10 : defaultValues.max}
            step={10}
            minValue={defaultValues.min}
            value={values}
            onChange={(value) => handleOnChange(value)}
            onChangeComplete={(value) => handleComplete(value)}
          />
          <ul className="list">
            <li>
              <div className="d-flex">
                <FormGroup>
                  <label>Min</label>
                  <input
                    type="number"
                    min={values.min}
                    max={values.max}
                    className="form-control"
                    value={minValue.min}
                    name="min"
                    onFocus={focused}
                    onBlur={blur}
                    onChange={(e) => inputMinChange(e)}
                    // onChangeComplete={(e) => changeComplete(e)}
                    onKeyPress={(e) => keypressHandler(e)}
                  />
                </FormGroup>
                <FormGroup>
                  <label>Max</label>
                  <input
                    type="number"
                    min={values.min}
                    max={values.max}
                    className="form-control"
                    value={maxValue.max}
                    name="max"
                    onFocus={focused}
                    onBlur={blur}
                    onChange={(e) => inputMaxChange(e)}
                    // onChangeComplete={(e) => changeComplete(e)}
                    onKeyPress={(e) => keypressHandler(e)}
                  />
                </FormGroup>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </Suspense>
  );
};

export default PriceSlide;
