import React, { useState, useEffect } from "react";

const Metal = (props) => {
  const {
    selectedMetal,
    setSelectedMetal,
    setTags,
    tags,
    finalMetal,
    setFinalMetal,
    filterPage
  } = props;
  const [localData, setLocalData] = useState([]);

  //using useEffect for handling localStorage for metal & color filter
  useEffect(() => {
    let metalData = localStorage.getItem(filterPage+`metalData`);

    if (metalData != null) {
      if (metalData.length > 0) {
        let dataVal = metalData.split(",");
        let selectedMetals = [];

        dataVal?.length > 0 &&
          dataVal?.map((val) => {
            if (val) {
              selectedMetals.push(val);
              setTags((prevState) => {
                const y = [...prevState, val];
                return y;
              });
            }
          });

        setSelectedMetal(selectedMetals);
      }
    }
  }, []);
  const metalValues = [
    {
      value: "Rose",
      allSelected: [{ four: "Rose 14", eight: "Rose 18", className: "hide" }],
      caratValue: [{ fourteen: "14", eighteen: "18" }],
      checked: false,
      four: "select",
      eight: "select",
    },
    {
      value: "White",
      allSelected: [{ four: "White 14", eight: "White 18" }],
      caratValue: [{ fourteen: "14", eighteen: "18" }],
      checked: false,
      four: "select",
      eight: "select",
    },
    {
      value: "Yellow",
      allSelected: [{ four: "Yellow 14", eight: "Yellow 18" }],
      caratValue: [{ fourteen: "14", eighteen: "18" }],
      checked: false,
      four: "select",
      eight: "select",
    },
    {
      value: "Platinum",
      allSelected: [{ zero: "Platinum 0" }],
      caratValue: [{ zero: "0" }],
      checked: false,
      four: "select",
      eight: "select",
    },
  ];
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [checkbox, setCheckbox] = useState(metalValues);

  const toggle = () => setDropdownOpen((prevState) => !prevState);

  //This function used for save filter values in tag and filter bits
  const combineValue = (e) => {
    const checked = e.target.checked;
    const combineMetalValue = e.target.value;
    const singleMetalValue = combineMetalValue.split(" ");
    const finalSingleMetalValue = singleMetalValue[0];
    setLocalData([...localData, finalSingleMetalValue]);

    if (
      (tags && tags.includes(combineMetalValue)) ||
      selectedMetal.includes(combineMetalValue)
    ) {
      const filter = tags.filter(function (data) {
        return data !== combineMetalValue;
      });
      let filterVal = filter.filter((c, index) => {
        return filter.indexOf(c) === index;
      });
      setTags(filterVal);
      const filterAPIValues = selectedMetal.filter(function (data) {
        return data !== combineMetalValue;
      });

      localStorage.setItem(filterPage+`metalData`, filterAPIValues);
      setSelectedMetal(filterAPIValues);
    } else {
      if (
        (tags && tags.includes(finalSingleMetalValue)) ||
        selectedMetal.includes(finalSingleMetalValue)
      ) {
        setTags((prevState) => {
          localStorage.setItem(filterPage+`metalData`, [
            ...selectedMetal,
            combineMetalValue,
          ]);
          const x = [...prevState, combineMetalValue];

          let uniqueChars = x.filter((c, index) => {
            return x.indexOf(c) === index;
          });
          return uniqueChars;
        });
        setSelectedMetal((prevState) => {
          const x = [...prevState, combineMetalValue];
          let uniqueChars = x.filter((c, index) => {
            return x.indexOf(c) === index;
          });
          return uniqueChars;
        });
      } else {
        setTags((prevState) => {
          localStorage.setItem(filterPage+`metalData`, [
            ...selectedMetal,
            combineMetalValue,
          ]);
          const x = [...prevState, combineMetalValue];
          let uniqueChars = x.filter((c, index) => {
            return x.indexOf(c) === index;
          });
          return uniqueChars;
        });

        setSelectedMetal((prevState) => {
          const x = [...prevState, combineMetalValue];
          let uniqueChars = x.filter((c, index) => {
            return x.indexOf(c) === index;
          });
          return uniqueChars;
        });

        checkbox.map((x) => {
          if (x.value === finalSingleMetalValue) {
            if (!finalMetal.includes(finalSingleMetalValue)) {
              setFinalMetal((prevState) => {
                const x = [...prevState, finalSingleMetalValue];
                return x;
              });
            }
          }
        });
      }
    }

    if (checked === true) {
      const updatedValues = checkbox.map((x, y) => {
        if (x.value === finalSingleMetalValue) {
          x["checked"] = checked === true ? true : false;
          const val = { ...x, metalval: combineMetalValue };
          return val;
        } else {
          const val = { ...x, metalval: "na" };
          return val;
        }
      });
      setCheckbox(updatedValues);

      const activeClass = checkbox.map((y, z) => {
        switch (true) {
          case combineMetalValue === "Rose 14" && y.checked === true:
            y["four"] = "selected";
            return y;
            break;
          case combineMetalValue === "Yellow 14" && y.checked === true:
            y["four"] = "selected";
            return y;
            break;
          case combineMetalValue === "White 14" && y.checked === true:
            y["four"] = "selected";
            return y;
            break;
          case combineMetalValue === "Rose 18" && y.checked === true:
            y["eight"] = "selected";
            return y;
            break;
          case combineMetalValue === "White 18" && y.checked === true:
            y["eight"] = "selected";
            return y;

          case combineMetalValue === "Yellow 18" && y.checked === true:
            y["eight"] = "selected";
            return y;
            break;
          default:
            return {
              ...y,
            };
        }
      });

      setCheckbox(activeClass);
    } else {
      const activeClass = checkbox.map((y, z) => {
        switch (true) {
          case combineMetalValue === "Rose 14" && y.checked === true:
            y["four"] = "select";
            return y;
            break;
          case combineMetalValue === "Yellow 14" && y.checked === true:
            y["four"] = "select";
            return y;
            break;
          case combineMetalValue === "White 14" && y.checked === true:
            y["four"] = "select";
            return y;
            break;
          case combineMetalValue === "Rose 18" && y.checked === true:
            y["eight"] = "select";
            return y;
            break;
          case combineMetalValue === "White 18" && y.checked === true:
            y["eight"] = "select";
            return y;

          case combineMetalValue === "Yellow 18" && y.checked === true:
            y["eight"] = "select";
            return y;
            break;
          default:
            return {
              ...y,
            };
        }
      });
      setCheckbox(activeClass);
    }
  };
  //Display list of checkboxes filter
  const metalFilterValue = () => {
    return checkbox.map((val, i) => {
      return val.allSelected.map((k) => {
        return (
          <li key={i}>
            <label>
              <input
                className="chk"
                type="checkbox"
                value={`${val.value}`}
                onChange={(e) => combineValue(e)}
                checked={tags && tags.includes(val.value) ? true : false}
              />
              <span />
              {val.value}
            </label>

            {val.caratValue.map((i, j) => {
              return (
                <ul className="boxes" value={val.value} key={j}>
                  {i.zero ? (
                    <li className={val.value} value={i.zero}>
                      {i.zero}
                    </li>
                  ) : (
                    ""
                  )}
                  {i.fourteen ? (
                    <li className={val.value}>
                      <label>
                        <input
                          type="checkbox"
                          value={`${val.value} ${i.fourteen}`}
                          onChange={(e) => {
                            combineValue(e);
                          }}
                          className={val.four}
                          checked={
                            tags && tags.includes(`${val.value} ${i.fourteen}`)
                              ? true
                              : false
                          }
                        />
                        14K {val.value}
                        <span></span>
                      </label>
                    </li>
                  ) : (
                    ""
                  )}
                  {i.eighteen ? (
                    <li className={val.value} value={i.eighteen}>
                      <label>
                        <input
                          type="checkbox"
                          value={`${val.value} ${i.eighteen}`}
                          onChange={(e) => combineValue(e)}
                          className={val.eight}
                          checked={
                            tags && tags.includes(`${val.value} ${i.eighteen}`)
                              ? true
                              : false
                          }
                        />
                        18K {val.value}
                        <span></span>
                      </label>
                    </li>
                  ) : (
                    ""
                  )}
                </ul>
              );
            })}
          </li>
        );
      });
    });
  };

  return (
    <div className="dropdown metalFilter">
      <h2 onClick={toggle}>
        {selectedMetal.length > 0
          ? `Metal & Color(${selectedMetal.length})`
          : ` Metal & Color`}
      </h2>
      <div className={`dropdown-menu ${dropdownOpen && "open"}`}>
        <ul className="list">{metalFilterValue()}</ul>
      </div>
    </div>
  );
};

export default Metal;
