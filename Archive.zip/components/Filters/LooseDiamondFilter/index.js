import React from "react";
import { Container } from "react-bootstrap";

import CaratSlide from "../Carat";
import RangeSliderWithValues from "../RangeSliderWithValues";

import PriceSlide from "../Price";
import ShapeDiamondFilter from "../Shape";

const LooseDiamondFilter = (props) => {
  return (
    <div className={`diamond-filters ${props.engagementRingId && "pt-0"}`}>
      <Container>
        <div className="d-grid">
          <ShapeDiamondFilter
            stoneShape={props.stoneShape}
            setSelectShape={props.setSelectShape}
          />

          <PriceSlide
            price
            diamond
            finalValueRange={props.finalValueRange}
            setFinalValueRange={props.setFinalValueRange}
            setMinMax={props.setMinMax}
            minMax={props.minMax}
          />

          <CaratSlide
            carat
            diamond
            caratValue={props.caratValue}
            setCaratValue={props.setCaratValue}
            finalValueRange={props.caratRange}
            setFinalValueRange={props.setCaratRange}
          />

          <RangeSliderWithValues
            cut
            diamond
            cutRange={props.cutRange}
            setCutRange={props.setCutRange}
          />

          <RangeSliderWithValues
            color
            diamond
            colorRange={props.colorRange}
            setColorRange={props.setColorRange}
          />

          <RangeSliderWithValues
            clarity
            diamond
            clarityRange={props.clarityRange}
            setClarityRange={props.setClarityRange}
          />
        </div>
      </Container>
    </div>
  );
};

export default LooseDiamondFilter;
