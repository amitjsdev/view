import React from "react";
import { Container } from "reactstrap";

//css
import { CustomButton } from "../../css/global";

// images
import GiftHead from "../../assets/images/hoops/landing/giftcard.png";

const GiftCard = () => {
  return (
    <div className="giftCard">
      <Container className="pr-0 mr-0 h-100">
        <div className="d-flex align-items-center h-100">
          <div className="left">
            <span className="head">
              <img src={`${GiftHead}`} alt="" />
            </span>
            <CustomButton cursive className="customButton">
              Shop now
            </CustomButton>
          </div>
          <div className="right"></div>
        </div>
      </Container>
    </div>
  );
};

export default GiftCard;
