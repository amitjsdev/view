import React from "react";
import News from "../../assets/images/newsletter.png";

const Newsletter = () => {
  return (
    <div className="newsletter d-inline-block py-5">
      <div className="news-wrap">
            {/* <img src={`${News}`} alt="" /> */}
              <div className="right">
        <h2><span>Get Update</span></h2>
          <div className="form-group">
            <input
              type="email"
              placeholder="Please enter your email to subscribe to our newsletter"
            />
            <div className="btn-group">
              <button>Male</button> or 
              <button>Female</button>
            </div>
          </div>
          <h6>
            By subscribing to our newsletter you accept all our terms and
            conditions
          </h6>
        </div>
      <div class="news-social">
      <i class="fa fa-id-card" aria-hidden="true"></i>
      </div>
      </div>
    </div>
  );
};

export default Newsletter;
