import React, { useState, useEffect } from "react";
import { Multiselect } from "multiselect-react-dropdown";

const CustomDropdown = (props) => {
  const { options, placeholder, handleChange, setTags, tags, diamondShape, filterPage } = props;
  const [seletedVal, setSelectedVal] = useState([]);
  const [count, setCount] = useState(0);
  //on checked and select dropdown item
  const onSelect = (selectedList, selectedItem) => {
    handleChange(selectedItem, true);
    setSelectedVal([...seletedVal, selectedItem]);

    setTags([...tags, selectedItem.value]);
    localStorage.setItem(
      filterPage + '-' + selectedItem.key,
      JSON.stringify([...seletedVal, selectedItem])
    );
  };

  //remove selected item from drop down
  const onRemove = (selectedList, removedItem) => {
    handleChange(removedItem, false);
    const seletedValIndex = seletedVal.findIndex(
      (item) => item.value == removedItem.value
    );
    if (seletedValIndex !== -1) {
      seletedVal.splice(seletedValIndex, 1);
    }
    localStorage.setItem(filterPage + '-' + removedItem.key, JSON.stringify(seletedVal));
    const tagsIndex = tags.findIndex((item) => item == removedItem.value);
    if (tagsIndex !== -1) {
      tags.splice(tagsIndex, 1);
    }
    setTags(tags);
    setSelectedVal(seletedVal);
  };

  //using useEffect for add or remove tags value or filter values on both end
  useEffect(() => {
    let optionData = [];
    tags &&
      tags.length > 0 &&
      tags.map((item) => {
        const tagData = options.filter((val) => val.value == item);
        if (tagData.length > 0) {
          optionData.push(tagData[0]);
        }
      });
    if (optionData.length > 0) {
      localStorage.setItem(filterPage + '-' + optionData[0].key, JSON.stringify(optionData));
      setSelectedVal(optionData);
      setCount(optionData.length);
    } else {
      setCount(0);
    }
    if (tags && tags.length == 0) {
      setSelectedVal([]);
      setCount(0);
    }

    //using localStorage for on page refresh set previous as default value of filters
    let localData = localStorage.getItem(filterPage + '-' + options[0].key);
    if (localData == null || localData == "") {
      setSelectedVal([]);
    } else {
      let currentData = JSON.parse(localStorage.getItem(filterPage + '-' + options[0].key));
      if (currentData.length > 0) {
        // setTags(currentData)
        for (var i = 0; i < currentData.length; i++) {
          if (!tags.includes(currentData[i].value)) {
            handleChange(currentData[i], true);
          }
        }
        setSelectedVal(currentData);
      }
    }

    // Start Select Diamond ring for complete ring 
    if (options && options.length > 0 && options[0].key == "stoneshape" && !!diamondShape) {
      let diamondShapeData = options.filter(
        (item) => item.value == diamondShape
      );
      if (diamondShapeData.length > 0) {
        // setTags(currentData)
        for (var i = 0; i < diamondShapeData.length; i++) {
          if (!tags.includes(diamondShapeData[i].value)) {
            handleChange(diamondShapeData[i], true);
          }
        }
        setSelectedVal(diamondShapeData);
      }
      localStorage.setItem(filterPage + '-' + options[0].key, JSON.stringify(diamondShapeData));
    }

    //End Select Diamond ring for complete ring 

    //Enagegment rings selected filter
    if (options && options.length > 0 && options[0].key == "ringShape") {
      let ringFilter = localStorage.getItem("ringFilter");
      if (ringFilter == null || ringFilter == "") {
      } else {
        let localData = localStorage.getItem(filterPage + '-' + options[0].key);
        if (localData == null || localData == "") {
        let newData = [];
            let ringFilterData = options.filter(
              (item) => item.value == ringFilter
            );
            localStorage.setItem(filterPage + '-' + options[0].key, JSON.stringify(ringFilterData));
            if (!tags.includes(ringFilter)) {
              handleChange(ringFilterData, true);
              localStorage.setItem("ringFilter", "");
            }
            newData.push(JSON.stringify(ringFilterData))
            setSelectedVal(newData);
          
      
        } else {
          let ringFilterData = options.filter(
            (item) => item.value == ringFilter
          );
          let checkData = JSON.parse(localData).findIndex((item) => item.value == ringFilter);
          if (checkData == -1) {
            if (ringFilterData && ringFilterData.length > 0) {

              localStorage.setItem(
                filterPage + '-' + options[0].key,
                JSON.stringify(ringFilterData)
              );
              if (!tags.includes(ringFilter)) {
                if (ringFilterData.length > 0) {
                  handleChange(ringFilterData, "ringFilter");
                  localStorage.setItem("ringFilter", "");
                }
              }
              setSelectedVal(ringFilterData);
            }
          }
        }
      }
    }
  }, [tags]);

  return (
    <div className="d-md-flex">
      <div className="examples">
        <Multiselect
          className={`check${options.key}`}
          options={options}
          displayValue="value"
          showCheckbox={true}
          onSelect={onSelect}
          onRemove={onRemove}
          disable={!!diamondShape && true}
          selectedValues={seletedVal}
          controlShouldRenderValue={true}
          placeholder={
            seletedVal.length > 0
              ? `${placeholder}(${seletedVal.length})`
              : placeholder
          }
          closeOnSelect={false}
        />
      </div>
    </div>
  );
};

export default CustomDropdown;
