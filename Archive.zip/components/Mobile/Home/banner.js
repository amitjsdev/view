import react from "react";

const HomeMobileBanner = () => {
  return (
    <div class="container">
      <div class="ban_top">
        <p>
          There's always something to celebrate. Mark the moment and save up to
          on Radix fine jewelry. <a href="javascript:void(0)">Shop now</a></p>
      </div>

      <div class="ban_text">
        <p>
          There's always something to celebrate. Mark the moment and save up
          to <span>30%</span> on Radix fine jewelry.
        </p>
      </div>

<div class="ban_btm">
  <div class="ban_btm_left">
  <h4>Diamond Stud</h4>
    <p>Exclusive Collection</p>
    </div>
    <a href="javascript:void(0)">Shop Now</a>
      </div>
    </div>
  );
};

export default HomeMobileBanner;
