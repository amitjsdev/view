import React, { useEffect, useState } from 'react';

import React360Viewer from './React360Viewer'

function App() {
  const [currentImages, setCurrentImages] = useState([]);
  useEffect(() => {
    function importAll(r) {
      return r.keys().map(r);
    }

    const images = importAll(require.context('../../assets/images/pro-img/', false, /\.(bmp|png|jpe?g|svg)$/));
    setCurrentImages(images)
  }, []);

  return (

    <div>
      <React360Viewer
        amount={currentImages.length}
        fileName="iris-{index}.jpeg"
        spinReverse
        autoplay
        buttonClass="dark"
      />
    </div>
  )
}

export default App;
