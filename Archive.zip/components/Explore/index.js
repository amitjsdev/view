import React from "react";
import { Link } from "react-router-dom";

//images
import More1 from "../../assets/images/detail/img1.png";
import More2 from "../../assets/images/detail/img2.png";
import More3 from "../../assets/images/detail/img3.png";
import More4 from "../../assets/images/detail/img4.png";
import More5 from "../../assets/images/detail/img5.png";

const Explore = ({ home }) => {
  return (
    <section className={`explore-more w-100 ${home && "home"}`}>
      <div className="container">
        <div className="explore-more-inner">
          <div className="explore-more-left">
            <h3>
              <span>E</span>xplore More
            </h3>
          </div>

          <div className="explore-gallery">
            <div className="explore-gallery-inner">
              <div className="gallery-item">
                <div className="gallery-img">
                  <img src={`${More1}`} alt="" />
                </div>
                <h6>Engagement Ring</h6>
              </div>

              <div className="gallery-item">
                <div className="gallery-img">
                  <img src={`${More2}`} alt="" />
                </div>
                <h6>Wedding Ring</h6>
              </div>

              <div className="gallery-item">
                <div className="gallery-img">
                  <img src={`${More3}`} alt="" />
                </div>
                <h6>Diamond</h6>
              </div>

              <div className="gallery-item">
                <div className="gallery-img">
                  <img src={`${More4}`} alt="" />
                </div>
                <h6>Diamond Jewellry</h6>
              </div>
              <Link to="earring">
                <div className="gallery-item">
                  <div className="gallery-img">
                    <img src={`${More5}`} alt="" />
                  </div>
                  <h6>Earring</h6>
                </div>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Explore;
