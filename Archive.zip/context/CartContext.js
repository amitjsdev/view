import React, { createContext, useReducer } from "react";
import APIUtil from "../api";
import { CartReducer } from "./CartReducer";
import { AddressReducer } from "./addressReducer";
import { PriceRangeReducer } from "./PriceRangeReducer";
export const CartContext = createContext();
const api = new APIUtil();

const initialState = {
  cartItems: [],
  wishLists: [],
  quantity: 0,
};
const wish = { wishListId: [] };
const cart = { cartListId: [] };

const CartContextProvider = ({ children }) => {
  const [state, dispatch] = useReducer(CartReducer, initialState);
  const [address, addressDispatch] = useReducer(AddressReducer);
  const [priceRange, priceRangeDispatch] = useReducer(PriceRangeReducer);
  const [wishId, wishListIdDispatch] = useReducer(CartReducer, wish);
  const [cartID, cartListIdDispatch] = useReducer(CartReducer, cart);

  const addProduct = async (userid) => {
    const result = await api.get(
      `products/cartList?id=${userid}&pageNumber=1`,
      {
        parse: false,
      }
    );
    const mydata = result.data.data;
    let myCart = mydata.Cart.map((item) => {
      let y = {
        _id: item._id,
        productCategory: item.productCategory,
        quantity: item.quantity,
        price: item.price,
        productId: item.productId,
      };
      let x = {};
      switch (item.productCategory) {
        case 1:
          x = {
            studId: item.studId,
            price: item.studId.price,
          };
          if (!cartID.cartListId?.includes(item.studId._id)) {
            cartID.cartListId.push(item.studId._id);
          }
          break;
        case 2:
          x = {
            hoopsId: item.hoopsId,
            price: item.hoopsId.totalPrice?.$numberDecimal,
          };
          if (!cartID.cartListId?.includes(item.hoopsId._id)) {
            cartID.cartListId.push(item.hoopsId._id);
          }
          break;
        case 3:
          x = {
            dropsId: item.dropsId,
            price: item.dropsId.totalPrice?.$numberDecimal,
          };
          if (!cartID.cartListId?.includes(item.dropsId._id)) {
            cartID.cartListId.push(item.dropsId._id);
          }
          break;
        case 4:
          x = {
            fashionId: item.fashionId,
            price: item.fashionId.totalPrice?.$numberDecimal,
          };
          if (!cartID.cartListId?.includes(item.fashionId._id)) {
            cartID.cartListId.push(item.fashionId._id);
          }
          break;
        case 5:
          x = {
            looseDiamondId: item.looseDiamondId,
            price: item.looseDiamondId?.totalPrice?.$numberDecimal,
          };
          if (!cartID.cartListId?.includes(item.looseDiamondId?._id)) {
            cartID.cartListId.push(item.looseDiamondId?._id);
          }
          break;
        case 6:
          x = {
            engagementRingId: item.engagementRingId,
            price: item.engagementRingId.price?.$numberDecimal,
          };
          if (!cartID.cartListId?.includes(item.engagementRingId._id)) {
            cartID.cartListId.push(item.engagementRingId._id);
          }
          break;
        case 7:
          x = {
            data: item,
          };
          if (!cartID.cartListId?.includes(item)) {
            cartID.cartListId.push(item);
          }
          break;
        default:
      }
      return {
        ...x,
        ...y,
      };
    });
    dispatch({ type: "ADD_ITEM", payload: myCart });
  };

  const wishProduct = async (userid) => {
    const result = await api.get(`products/wishList?id=${userid}&pageNumber=1`);
    const mydata = result.data.data;

    let myWish = mydata.Wishlist.map((item) => {
      let y = {
        _id: item._id,
        productCategory: item.productCategory,
      };

      let x = {};
      switch (item.productCategory) {
        case 1:
          x = {
            studId: item.studId,
            price: item.studId.price,
          };
          if (!wishId.wishListId?.includes(item.studId?._id)) {
            wishId.wishListId.push(item.studId?._id);
          }
          break;
        case 2:
          x = {
            hoopsId: item.hoopsId,
            price: item.hoopsId?.totalPrice.$numberDecimal,
          };
          if (!wishId.wishListId?.includes(item.hoopsId?._id)) {
            wishId.wishListId.push(item.hoopsId?._id);
          }
          break;
        case 3:
          x = {
            dropsId: item.dropsId,
            price: item.dropsId.price,
          };
          if (!wishId.wishListId?.includes(item.dropsId?._id)) {
            wishId.wishListId.push(item.dropsId?._id);
          }
          break;
        case 4:
          x = {
            fashionId: item.fashionId,
            price: item.fashionId.price,
          };
          if (!wishId.wishListId?.includes(item.fashionId?._id)) {
            wishId.wishListId.push(item.fashionId?._id);
          }
          break;
        case 5:
          x = {
            looseDiamondId: item.looseDiamondId,
            price: item.looseDiamondId?.price?.$numberDecimal,
          };
          if (!wishId.wishListId?.includes(item.looseDiamondId?._id)) {
            wishId.wishListId.push(item.looseDiamondId?._id);
          }
          break;
        case 6:
          x = {
            engagementRingId: item.engagementRingId,
            price: item.engagementRingId?.price?.$numberDecimal,
          };
          if (!wishId.wishListId?.includes(item.engagementRingId?._id)) {
            wishId.wishListId.push(item.engagementRingId?._id);
          }
          break;
        default:
      }
      return { ...x, ...y };
    });

    dispatch({ type: "GET_WISH_CART", payload: myWish });
  };

  const withoutLoging = (payload) => {
    dispatch({ type: "ADD_ITEM_WLOGIN", payload });
  };

  const increase = (payload, val) => {
    const cartQuantity = {
      ...payload,
      button: val,
    };
    dispatch({ type: "INCREASE", cartQuantity });
  };

  const formValues = (payload) => {
    addressDispatch({ type: "FORM_VALUES", payload });
  };

  const priceRangeValues = (payload) => {
    priceRangeDispatch({ type: "PRICE_RANGE", payload });
  };

  const wishListIdDel = (payload) => {
    wishListIdDispatch({ type: "WISHID_DEL", payload });
  };

  const cartListIdDel = (payload) => {
    cartListIdDispatch({ type: "CARTID_DEL", payload });
  };

  const contextValues = {
    addProduct,
    withoutLoging,
    increase,
    wishProduct,
    formValues,
    priceRangeValues,
    wishListIdDel,
    cartListIdDel,
    ...state,
    ...address,
    ...priceRange,
    ...wishId,
    ...cartID,
  };

  return (
    <CartContext.Provider value={contextValues}>
      {children}
    </CartContext.Provider>
  );
};

export default CartContextProvider;
