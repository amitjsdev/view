import APIUtil from "../api";

const api = new APIUtil();

// cart quantity can be increased and decreased by this function
export const cartQuanitites = (state, action) => {
  let action_data = {};
  let new_data = {};
  const category = action.cartQuantity.productCategory;
  switch (category) {
    case 1:
      action_data = action.cartQuantity.studId._id;
      break;
    case 2:
      action_data = action.cartQuantity.hoopsId._id;
      break;
    case 3:
      action_data = action.cartQuantity.dropsId._id;
      break;
    case 4:
      action_data = action.cartQuantity.fashionId._id;
      break;

    default:
  }

  const findIndex = state.cartItems.findIndex((item) => {
    switch (item.productCategory) {
      case 1:
        new_data = item.studId._id;
        break;
      case 2:
        new_data = item.hoopsId._id;
        break;
      case 3:
        new_data = item.dropsId._id;
        break;
      case 4:
        new_data = item.fashionId._id;
        break;

      default:
    }

    return new_data === action_data;
  });
  const buttonCondition = action.cartQuantity.button;

  if (findIndex >= 0) {
    const newState = [
      ...state.cartItems.slice(0, findIndex),
      {
        ...state.cartItems[findIndex],

        quantity: parseInt(
          `${
            buttonCondition == "inc"
              ? state.cartItems[findIndex].quantity + 1
              : state.cartItems[findIndex].quantity - 1
          }`
        ),
        ...state.cartItems,
      },
      ...state.cartItems.slice(findIndex + 1),
    ];

    const incData = async () => {
      const data = {
        cartId: action.cartQuantity._id,
        quantity: parseInt(
          `${
            buttonCondition == "inc"
              ? action.cartQuantity.quantity++
              : action.cartQuantity.quantity--
          }`
        ),
        price: action.cartQuantity.price,
      };
      await api.post(`products/updateCart`, data);
    };
    incData();
    return newState;
  }

  return [...state.cartItems, action.cartQuantity];
};

export const CartReducer = (state, action) => {
  switch (action.type) {
    case "ADD_ITEM":
      return {
        ...state,
        cartItems: action.payload,
      };

    case "GET_WISH_CART":
      return {
        ...state,
        wishLists: action.payload,
      };

    case "INCREASE":
      return {
        ...state,
        cartItems: cartQuanitites(state, action),
      };

    case "DECREASE":
      return {
        ...state,
        cartItems: cartQuanitites(state, action),
      };
    case "WISHID_DEL":
      return {
        ...state,
        wishListId: action.payload,
      };
    case "CARTID_DEL":
      return {
        ...state,
        cartListId: action.payload,
      };

    default:
      return state;
  }
};
