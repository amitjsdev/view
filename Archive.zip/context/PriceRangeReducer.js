export const PriceRangeReducer = (state = null, action) => {
  switch (action.type) {
    case "PRICE_RANGE":
      return {
        ...state,
        ranges: action.payload,
      };
    default:
      return state;
  }
};
