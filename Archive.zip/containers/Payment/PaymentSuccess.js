import React from "react";
import { Link } from "react-router-dom";
import { PaySuccess } from "../../css/paySuccess";

export default function PaymentSuccess() {
  return (
    <PaySuccess className="my-5 py-5">
      <span>
        <img
          className="payimage"
          src={require("../../assets/images/payment/payment_success.png")}
          alt=""
        />
      </span>
      <p className="paytext1">Payment SuccessFul</p>
      <p className="paytext2">Your payment was successfully processed </p>
      <div className="paybuttonrel">
        <div className="paybuttoncen">
          <Link to="/earring">
            <button className="button">Purchase More</button>
          </Link>
        </div>
      </div>
    </PaySuccess>
  );
}
