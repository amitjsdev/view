import React, { useState, useEffect, useContext } from "react";
import { Col, Container, Row } from "reactstrap";
import APIUtil from "../../api";
import { CartContext } from "../../context/CartContext";
import { UserDetails } from "../../constant";
// css
import { CustomButton } from "../../css/global";
import { PaymentWrap } from "../../css/payment";

import dummyImg from "../../assets/images/er-Img.jpeg";

const api = new APIUtil();

const Payment = (props) => {
  const { addProduct } = useContext(CartContext);
  const [orderInfo, setOrderInfo] = useState([]);
  const [ship, setShip] = useState({});
  const [bill, setBill] = useState({});
  const [order, setOrder] = useState();
  var userId = UserDetails();

  const data = async () => {
    const token = localStorage.getItem("token");
    const headers = {
      Authorization: `Bearer ${token}`,
    };
    const fetchOrderNumber = await api.get("orders/generateOrderNo", {
      headers,
    });
    setOrder(fetchOrderNumber.data.data);
    await api
      .get(`orders/order_review?order_number=${fetchOrderNumber.data.data}`, {
        headers,
      })
      .then((res) => {
        const productInfo = res.data.data.products;
        const shipp = res.data.data.address;
        const bill = res.data.data.address?.billing_id;

        setOrderInfo(res.data.data.products);
        setShip(shipp);
        setBill(bill);
      });
  };

  const finalOrder = () => {
    return orderInfo?.map((val, index) => {
      let productId = {};
      let productImg = {};
      switch (val.productCategory) {
        case 1:
          productId = val.studId;
          break;
        case 2:
          productId = val.hoopsId;
          break;
        case 3:
          productId = val.dropsId;
          break;
        case 4:
          productId = val.fashionId;
          break;
        case 5:
          productId = val.looseDiamondId;
          break;
        case 6:
          productId = val.engagementRingId;
          break;
        case 7:
          productId = val?._id;
          break;
        default:
      }
      switch (val.productCategory) {
        case 1:
          productImg = productId.images.studsImages;
          break;
        case 2:
          productImg = productId.images.hoopsImages;
          break;
        case 3:
          productImg = productId.images.dropsImages;
          break;
        case 4:
          productImg = productId.images.fashionImages;
          break;
        case 5:
          productImg = productId.images.diamondImages;
          break;
        case 6:
          productImg = productId.images.productsPreviewImages;
          break;
        case 7:
          productImg = productId?.images?.productsPreviewImages;
          break;
        default:
      }

      return (
        <>
          {val && val?.productCategory == 7 ?
            <div key={index}>
              <div className="products">
                <div className="box d-flex">
                  <span>
                    {!!productImg ?
                      productImg?.map((image, index) => {
                        return (
                          <img
                            key={index}
                            src={`${image}`}
                            className="img-fluid"
                            alt=""
                          />
                        );
                      })
                      :
                      <img
                        key={index}
                        src={`${dummyImg}`}
                        className="img-fluid"
                        alt=""
                      />
                    }

                  </span>
                  <div className="right">
                    <h4>
                      Engagement Ring (Completed)
                 </h4>
                    <div className="d-flex align-items-start justify-content-between">
                      <h4>Quantity {val?.quantity}</h4>
                      <h4>
                        Total{" "}
                        <span>
                          $
                       {val?.total_amount?.$numberDecimal}
                        </span>
                      </h4>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            :

            <div key={index}>
              <div className="products">
                <div className="box d-flex">

                  <span>
                    {productImg?.map((image, index) => {
                      return (
                        <img
                          key={index}
                          src={`${image}`}
                          className="img-fluid"
                          alt=""
                        />
                      );
                    })}
                  </span>
                  <div className="right">
                    <h4>
                      {productId?.diamondInformation?.settingType
                        ? productId?.diamondInformation?.settingType
                        : ""}
                      {productId?.diamondWeight?.$numberDecimal
                        ? productId?.diamondWeight?.$numberDecimal
                        : productId?.caratWeight?.$numberDecimal
                          ? productId?.caratWeight?.$numberDecimal
                          : productId?.diamondWeight}
                  Ct. Wt. Diamond Stud Earrings
                </h4>
                    <div className="d-flex align-items-start justify-content-between">
                      <h4>Quantity {val.quantity}</h4>
                      <h4>
                        Total{" "}
                        <span>
                          $
                      {productId?.price
                            ? productId?.price.$numberDecimal
                              ? productId?.price.$numberDecimal
                              : productId?.price
                            : productId?.totalPrice.$numberDecimal}
                        </span>
                      </h4>
                    </div>
                  </div>
                </div>
              </div>
            </div>

          }
        </>

      );
    });
  };

  useEffect(() => {
    data();
  }, []);

  if (!orderInfo) {
    return <div />;
  } else if (!ship) {
    return <div />;
  }

  const confirmPayment = async () => {
    const totalAmount = orderInfo[0]?.total_amount.$numberDecimal;

    const token = localStorage.getItem("token");
    const headers = {
      Authorization: `Bearer ${token}`,
    };
    let arrInfo = orderInfo?.map((item) => {
      const qty = item.quantity;
      let x = {};
      switch (item.productCategory) {
        case 1:
          x = {
            quantity: qty,
            studId: item.studId._id,
            payment_method: "Bank wire",
            productCategory: item.productCategory,
          };
          break;
        case 2:
          x = {
            quantity: qty,
            hoopsId: item.hoopsId._id,
            payment_method: "Bank wire",
            productCategory: item.productCategory,
          };
          break;
        case 3:
          x = {
            quantity: qty,
            dropsId: item.dropsId._id,
            payment_method: "Bank wire",
            productCategory: item.productCategory,
          };
          break;
        case 4:
          x = {
            quantity: qty,
            fashionId: item.fashionId._id,
            payment_method: "Bank wire",
            productCategory: item.productCategory,
          };
          break;
        case 5:
          x = {
            quantity: qty,
            looseDiamondId: item.looseDiamondId._id,
            payment_method: "Bank wire",
            productCategory: item.productCategory,
          };
          break;
        case 7:
          x = {
            quantity: qty,
            productId: item?._id,
            payment_method: "Bank wire",
            productCategory: item.productCategory,
          };
          break;
        default:
      }
      return x;
    });
    const dataval = {
      order_number: order,
      total_amount: totalAmount,
      shipping_amount: orderInfo[0].shipping_amount?.$numberDecimal,
      amount_wihout_taxes: orderInfo[0].amount_wihout_taxes?.$numberDecimal,
      tax: orderInfo[0].tax.$numberDecimal,
      productDetails: arrInfo,
      totalQuantity: orderInfo[0].totalQuantity,
      shipping_id: ship.shipping_id._id,
      billing_id: ship.billing_id._id,
    };
    const body = {
      order_number: order,
      payment_status: "1",
      payment_method: "Bank wire",
      price: totalAmount,
    };

    await api.post(`orders/order_payment`, body, { headers }).then((res) => {
      api.post(`orders/confirm_order`, dataval, { headers }).then((res) => {
        addProduct(userId.toString());
        //delete engagement rings products start
        if (!!orderInfo.some((item) => item.productCategory == 7)) {
          api
            .get(`products/ringReview?id=${userId._id.toString()}`)
            .then((res) => {
              const token = localStorage.getItem("token");
              const headers = {
                Authorization: `Bearer ${token}`,
              };
              let new_data = {};
              let ringReviewData = Object.values(res.data.data);
              ringReviewData &&
                ringReviewData.length > 0 &&
                ringReviewData.map((item) => {
                  if (item?.engagementRingId?._id) {
                    new_data = {
                      userId: userId._id.toString(),
                      looseDiamondId: item?.looseDiamondId?._id,
                    };
                     api
                      .post(`products/delRingReview`, new_data, { headers })
                      .then((response) => {
                      });
                  }
                  if (item?.looseDiamondId?._id) {
                    new_data = {
                      userId: userId._id.toString(),
                      engagementRingId: item?.engagementRingId?._id,
                    };
                     api
                      .post(`products/delRingReview`, new_data, { headers })
                      .then((response) => {
                      });
                  }
                });
            });
        }
        //delete engagement ring products end 
      });

      props.history.push("/paysuccess");
    });
  };

  return (
    <PaymentWrap>
      <Container className="py-5">
        <Row>
          <Col md={5}>
            <div className="order-info">
              <h4 className="orderno">Order Number: {ship.order_number} </h4>

              {finalOrder()}
              <div className="shippingInfo">
                <h4>Estimate Delivery By 27th November 2020 </h4>
              </div>
              <div className="addressInfo">
                <div className="shipping">
                  <h4>Shipping Address-</h4>
                  <p>
                    {ship.shipping_id?.first_name} {ship.shipping_id?.last_name}
                  </p>
                  <p>
                    {ship.shipping_id?.street_address}, {ship.shipping_id?.city}
                    , {ship.shipping_id?.state}, {ship.shipping_id?.country},{" "}
                    {ship.shipping_id?.zip_code}
                  </p>
                </div>
                <div className="billing">
                  <h4>Billing Address-</h4>
                  <p>
                    {bill.first_name} {bill.last_name}
                  </p>
                  <p>
                    {bill.street_address}, {bill.city}, {bill.state},{" "}
                    {bill.country}, {bill.zip_code}
                  </p>
                </div>
              </div>
            </div>
          </Col>
          <Col md={7} className="payment-method">
            <h4>Payment method </h4>

            <CustomButton dark onClick={confirmPayment}>
              Proceed to Pay
            </CustomButton>
          </Col>
        </Row>
      </Container>
    </PaymentWrap>
  );
};

export default Payment;
