import React, { useState } from "react";
import {
  TabContent,
  TabPane,
  Nav,
  NavItem,
  NavLink,
  Container,
} from "reactstrap";
import UsersOrder from "../../components/Account/Orders";
import AccountDetail from "../../components/Account/AccountDetails";

//css
import { UserAccountWrap } from "../../css/account";
//images
import { ReactComponent as UserIcon } from "../../assets/images/account/user.svg";
import { ReactComponent as Orders } from "../../assets/images/account/orders.svg";
import { ReactComponent as Map } from "../../assets/images/account/map.svg";
import { ReactComponent as Member } from "../../assets/images/account/member.svg";
import { ReactComponent as ChangePassword } from "../../assets/images/account/change-password.svg";
import { ReactComponent as Edit } from "../../assets/images/account/edit-1.svg";
import BillingAndShipping from "../BillingAndShipping";

const UserAccount = () => {
  const [activeTab, setActiveTab] = useState("1");
  const [editMode, setEditMode] = useState(false);
  const toggle = (tab) => {
    if (activeTab !== tab) setActiveTab(tab);
  };

  return (
    <UserAccountWrap>
      <section className="my-account">
        <Container>
          <div className="my-account-wrapper">
            <div className="my-account-left-box">
              <div className="my-account-box">
                <div className="my-account-list">
                  <h3>My Account</h3>
                  <Nav tabs>
                    <NavItem>
                      <NavLink
                        className={activeTab === "1" ? "active" : ""}
                        onClick={() => {
                          toggle("1");
                        }}
                      >
                        <UserIcon width="17px" height="17px" />
                        Account Detail
                      </NavLink>
                    </NavItem>
                    <NavItem>
                      <NavLink
                        className={activeTab === "2" ? "active" : ""}
                        onClick={() => {
                          toggle("2");
                        }}
                      >
                        <Orders width="19px" height="17px" />
                        My Orders
                      </NavLink>
                    </NavItem>
                    <NavItem>
                      <NavLink
                        className={activeTab === "3" ? "active" : ""}
                        onClick={() => {
                          toggle("3");
                        }}
                      >
                        <Map width="13px" height="19px" />
                        Address
                      </NavLink>
                    </NavItem>
                    <NavItem>
                      <NavLink
                        className={activeTab === "4" ? "active" : ""}
                        onClick={() => {
                          toggle("4");
                        }}
                      >
                        <Member width="24px" height="12px" />
                        Radix member
                      </NavLink>
                    </NavItem>
                    <NavItem>
                      <NavLink
                        className={activeTab === "5" ? "active" : ""}
                        onClick={() => {
                          toggle("5");
                        }}
                      >
                        <ChangePassword width="18px" height="15px" />
                        Change password
                      </NavLink>
                    </NavItem>
                    <NavItem>
                      <NavLink className="logout">Log out</NavLink>
                    </NavItem>
                  </Nav>
                </div>
              </div>
              <div className="need-help">
                <p>
                  Need Help? <br />
                  <span>For any help, please call us at</span>
                </p>
                <a href="tel:1800-5856-69635">1800-5856-69635</a>
              </div>
            </div>
            <TabContent activeTab={activeTab}>
              <TabPane tabId="1">
                <div className="account-detail-container">
                  <div className="account-detail-form">
                    <h3>
                      Account Details{" "}
                      <span
                        className="form-edit-icon"
                        onClick={() => setEditMode(true)}
                      >
                        <Edit width="25px" height="22px" />
                      </span>
                    </h3>
                    <AccountDetail
                      editMode={editMode}
                      setEditMode={setEditMode}
                    />
                  </div>
                </div>
              </TabPane>
              <TabPane tabId="2">
                <UsersOrder />
              </TabPane>
              <TabPane tabId="3">
                <BillingAndShipping userProfile />
              </TabPane>
            </TabContent>
          </div>
        </Container>
      </section>
    </UserAccountWrap>
  );
};

export default UserAccount;
