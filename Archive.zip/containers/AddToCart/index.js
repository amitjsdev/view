import React, { useContext, useEffect, useState } from "react";
import { Container } from "reactstrap";
import APIUtil from "../../api";
import { Link, useHistory } from "react-router-dom";
import { CartContext } from "../../context/CartContext";
import { UserDetails } from "../../constant";
//images
import { ReactComponent as Dustbin } from "../../assets/images/dustbin.svg";
import { ReactComponent as RedWish } from "../../assets/images/redwishlist.svg";
import { ReactComponent as Cert } from "../../assets/images/usb/inde-cert.svg";
import { ReactComponent as Delivery } from "../../assets/images/usb/fast-delivery.svg";
import { ReactComponent as Return } from "../../assets/images/usb/day.svg";
import { ReactComponent as Ring } from "../../assets/images/usb/wedding-rings-couple.svg";
import More1 from "../../assets/images/detail/img1.png";
import More2 from "../../assets/images/detail/img2.png";
import More3 from "../../assets/images/detail/img3.png";
import More4 from "../../assets/images/detail/img4.png";
import More5 from "../../assets/images/detail/img5.png";
import dummyImg from "../../assets/images/er-Img.jpeg";

//css
import { Cart } from "../../css/cart";
import { CustomButton } from "../../css/global";

const api = new APIUtil();

export default function AddToCart(props) {
  const {
    addProduct,
    increase,
    wishListId,
    wishProduct,
    cartItems,
    cartListId,
    cartListIdDel,
  } = useContext(CartContext);
  const [load, setLoad] = useState(false);
  const [order, setOrder] = useState();
  const history = useHistory();
  const userId = UserDetails();

  // wish
  const isInWish = (id) => {
    if (wishListId.includes(id)) {
      return true;
    } else {
      return false;
    }
  };

  // Different conditions to match while moving products to wishlist
  const addedToWish = async (id, category) => {
    if (isInWish(id)) {
      const del_data = {
        userId: userId._id.toString(),
        productId: id,
        productCategory: category,
      };

      await api.post("products/delCart", del_data).then((response) => {
        if (cartListId.includes(id)) {
          const filter = cartListId.filter(function (data) {
            return data !== id;
          });

          cartListIdDel(filter);
        }
      });
    } else if (!isInWish(id)) {
      let new_data = [
        {
          userId: userId._id.toString(),
          productId: id,
          productCategory: category,
        },
      ];

      await api.post("products/addWishlist", new_data).then((response) => {});
      const del_data = {
        userId: userId._id.toString(),
        productId: id,
        productCategory: category,
      };
      await api.post("products/delCart", del_data).then((response) => {
        if (cartListId.includes(id)) {
          const filter = cartListId.filter(function (data) {
            return data !== id;
          });

          cartListIdDel(filter);
        }
      });
    }

    setLoad(!load);
  };

  // Click handle to remove products from cart value
  const cartRemove = async (id, category) => {
    const del_data = {
      userId: userId._id.toString(),
      productId: id,
      productCategory: category,
    };
    await api.post("products/delCart", del_data).then((response) => {
      if (cartListId.includes(id)) {
        const filter = cartListId.filter(function (data) {
          return data !== id;
        });

        cartListIdDel(filter);
      }
    });
    setLoad(!load);
  };

  useEffect(() => {
    const user = userId._id.toString();
    addProduct(user);
    wishProduct(user);
  }, [load]);

  useEffect(() => {
    const token = localStorage.getItem("token");
    const headers = {
      Authorization: `Bearer ${token}`,
    };
    api.get("orders/generateOrderNo", { headers }).then((res) => {
      const data = res.data.data;
      setOrder(data);
    });

    const user = userId._id.toString();
    addProduct(user);
  }, []);

  // Getting quantity of total products
  const getQnty = () => {
    return cartItems.reduce((sum, { quantity }) => sum + +quantity, 0);
  };

  // Getting Total amount
  const totalAmount = () => {
    return cartItems.reduce(
      (sum, { price, quantity }) => sum + +quantity * +price,
      0
    );
  };

  // Click handle on proceed to checkout
  const checkout = () => {
    const arr = cartItems.map((val) => {
      const quant = val.quantity;

      let x = {};
      switch (val.productCategory) {
        case 1:
          x = {
            quantity: quant,
            studId: val.studId._id,
            productCategory: val.productCategory,
          };
          break;
        case 2:
          x = {
            quantity: quant,
            hoopsId: val.hoopsId._id,
            productCategory: val.productCategory,
          };
          break;
        case 3:
          x = {
            quantity: quant,
            dropsId: val.dropsId._id,
            productCategory: val.productCategory,
          };
          break;
        case 4:
          x = {
            quantity: quant,
            fashionId: val.fashionId._id,
            productCategory: val.productCategory,
          };
          break;
        case 5:
          x = {
            quantity: quant,
            looseDiamondId: val.looseDiamondId._id,
            productCategory: val.productCategory,
          };
          break;
        case 6:
          x = {
            quantity: quant,
            engagementRingId: val.engagementRingId._id,
            productCategory: val.productCategory,
          };
          break;
        case 7:
          x = {
            quantity: quant,
            productId: val._id,
            productCategory: val.productCategory,
          };
          break;
        default:
      }
      return x;
    });

    const body = {
      order_number: order,
      total_amount: totalAmount(),
      shipping_amount: 0,
      amount_wihout_taxes: totalAmount(),
      totalQuantity: getQnty(),
      tax: 0,
      productDetails: arr,
    };

    const token = localStorage.getItem("token");
    const headers = {
      Authorization: `Bearer ${token}`,
    };

    api.post("orders/checkout", body, { headers }).then((res) => {
      history.push({
        pathname: `/shipping`,
      });
    });
  };
  // HTML for the cart List section
  const cartListSection = () => {
    return cartItems.map((val, index) => {
      let cartListId = {};
      let cartListImg = {};
      switch (val.productCategory) {
        case 1:
          cartListId = val.studId;
          break;
        case 2:
          cartListId = val.hoopsId;
          break;
        case 3:
          cartListId = val.dropsId;
          break;
        case 4:
          cartListId = val.fashionId;
          break;
        case 5:
          cartListId = val.looseDiamondId;
          break;
        case 6:
          cartListId = val.engagementRingId;
          break;
        case 7:
          cartListId = val;
          break;
        default:
      }

      switch (val.productCategory) {
        case 1:
          cartListImg = cartListId.images.studsImages;
          break;
        case 2:
          cartListImg = cartListId.images.hoopsImages;
          break;
        case 3:
          cartListImg = cartListId.images.dropsImages;
          break;
        case 4:
          cartListImg = cartListId.images.fashionImages;
          break;
        case 5:
          cartListImg = cartListId.images?.diamondImages;
          break;
        case 6:
          cartListImg = cartListId.images?.previewImages
            ? cartListId.images?.previewImages
            : [dummyImg];
          break;
        case 7:
          cartListImg = cartListId.images?.previewImages
            ? cartListId.images?.previewImages
            : [dummyImg];
          break;
        default:
      }

      return (
        <div className="box" key={index}>
          {!!val?.data?.engagementRingId && !!val?.data?.looseDiamondId ? (
            <>
              {/* Earing Ring start */}
              <div className="left">
                <span>
                  {cartListImg &&
                    cartListImg.length > 0 &&
                    cartListImg.map((image, index) => {
                      return (
                        <img
                          style={{ width: 100, height: 100 }}
                          key={index}
                          src={image}
                          alt=""
                        />
                      );
                    })}
                </span>
              </div>
              <div className="right">
                <div>
                  <h5>Engagement Ring (Completed)</h5>
                </div>

                <div className="justify-content-between">
                  <h6>
                    {val.productCategory === 7
                      ? `${val?.data?.looseDiamondId?.caratWeight.$numberDecimal} - Carat ${val?.data?.looseDiamondId?.shapeCut} Shaped Diamond`
                      : cartListId?.name}
                  </h6>
                  {/* diamond section start */}
                  <ul className="desc">
                    <li>
                      <label>SUK - </label>
                      {val?.data?.looseDiamondId?.suk}
                    </li>
                    <li>
                      <label>Diamond Weight - </label>
                      {val?.productCategory === 7
                        ? val?.data?.looseDiamondId?.caratWeight?.$numberDecimal
                        : val?.data?.looseDiamondId?.diamondWeight
                            ?.$numberDecimal
                        ? val?.data?.looseDiamondId?.diamondWeight
                            ?.$numberDecimal
                        : val?.data?.looseDiamondId?.diamondWeight}
                      ct. tw.
                    </li>
                    {val?.productCategory === 7 ? (
                      <li>
                        {val?.data?.looseDiamondId?.shapeCut} Shaped,{" "}
                        {val?.data?.looseDiamondId?.cutGrade} Cut,{" "}
                        {val?.data?.looseDiamondId?.colorGrade}-color,{" "}
                        {val?.data?.looseDiamondId?.clarityGrade}
                        -clarity
                      </li>
                    ) : (
                      <>
                        <li>
                          <label>Color - </label>
                          {val?.data?.looseDiamondId?.diamondInformation
                            ?.maxColor
                            ? `${val?.data?.looseDiamondId?.diamondInformation?.maxColor} - ${val?.data?.looseDiamondId?.diamondInformation?.minColor}`
                            : ""}
                        </li>
                        <li>
                          <label>Clarity - </label>

                          {val?.data?.looseDiamondId?.diamondInformation
                            ?.maxClarity
                            ? `${val?.data?.looseDiamondId?.diamondInformation?.maxClarity} - ${val?.data?.looseDiamondId?.diamondInformation?.minClarity}`
                            : ""}
                        </li>
                      </>
                    )}
                  </ul>
                  {/* diamond section end */}
                  <h6>
                    {val.productCategory === 7
                      ? `${val?.data?.engagementRingId?.metalCarat}K ${" "}
                    ${val?.data?.engagementRingId?.metal}  ${
                          val?.data?.engagementRingId?.name
                        } `
                      : cartListId?.name}
                  </h6>
                  <ul className="desc">
                    <li>
                      <label> SUK - </label>
                      {val?.data?.engagementRingId?.suk}
                    </li>
                    {val?.productCategory !== 5 ? (
                      <li>
                        <label>Metal - </label>
                        {val?.data?.engagementRingId?.metalCarat === 0
                          ? ""
                          : `${val?.data?.engagementRingId?.metalCarat}K`}{" "}
                        {val?.data?.engagementRingId?.metal}
                        {val?.data?.engagementRingId?.metalCarat === 0
                          ? ""
                          : " Gold"}
                      </li>
                    ) : (
                      ""
                    )}

                    <li>
                      <label>Ring Width - </label>
                      {val?.data?.engagementRingId?.ringWidth}
                    </li>
                    <>
                      <li>
                        <label>Setting Type - </label>
                        {val?.data?.engagementRingId?.settingType
                          ? `${val?.data?.engagementRingId?.settingType}`
                          : ""}
                      </li>
                      <li>
                        <label>Diamond Shape - </label>

                        {val?.data?.engagementRingId?.diamondShape
                          ? `${val?.data?.engagementRingId?.diamondShape}`
                          : ""}
                      </li>
                    </>
                  </ul>
                </div>
                <div className="d-flex justify-content-between buttonList">
                  <button
                    className="cartRemove"
                    onClick={(e) =>
                      cartRemove(cartListId?._id, val.productCategory)
                    }
                  >
                    <Dustbin width="16px" height="19px" />
                    Remove
                  </button>
                  {isInWish(cartListId?._id) && (
                    <button
                      className="wishlist"
                      onClick={() =>
                        alert(
                          "Inside Your WishList Click Delete to Remove From Cart "
                        )
                      }
                    >
                      <RedWish width="16px" height="14px" />
                      Already in wishlist
                    </button>
                  )}
                  {!isInWish(cartListId?._id) && (
                    <button
                      className="wishlist"
                      onClick={() =>
                        addedToWish(cartListId?._id, val.productCategory)
                      }
                    >
                      <RedWish width="16px" height="14px" />
                      Move to Wishlist
                    </button>
                  )}
                  {cartListId?.status !== 2 ? (
                    <h5>{`$ ${val?.price}`} </h5>
                  ) : (
                    <h5 className="out">Out of Stock</h5>
                  )}
                </div>
              </div>
              {/* Earing Ring End */}
            </>
          ) : (
            <>
              <div className="left">
                <span>
                  {cartListImg &&
                    cartListImg.length > 0 &&
                    cartListImg.map((image, index) => {
                      return (
                        <img
                          style={{ width: 100, height: 100 }}
                          key={index}
                          src={image}
                          alt=""
                        />
                      );
                    })}
                </span>
              </div>
              <div className="right">
                <h4>
                  {val.productCategory === 5
                    ? `${cartListId.caratWeight.$numberDecimal} - Carat ${cartListId.shapeCut} Shaped Diamond`
                    : cartListId?.name}
                </h4>
                <div className="d-flex justify-content-between">
                  <ul className="desc">
                    {val?.productCategory !== 5 ? (
                      <li>
                        <label>Metal - </label>
                        {cartListId?.metalCarat === 0
                          ? ""
                          : `${cartListId?.metalCarat}K`}{" "}
                        {cartListId?.metal}
                        {cartListId?.metalCarat === 0 ? "" : " Gold"}
                      </li>
                    ) : (
                      ""
                    )}
                    <li>
                      <label>SUK - </label>
                      {cartListId?.suk}
                    </li>
                    <li>
                      <label>Diamond Weight - </label>
                      {val?.productCategory === 5
                        ? cartListId?.caratWeight?.$numberDecimal
                        : cartListId?.diamondWeight?.$numberDecimal
                        ? cartListId?.diamondWeight?.$numberDecimal
                        : cartListId?.diamondWeight}
                      ct. tw.
                    </li>
                    {val?.productCategory === 5 ? (
                      <li>
                        {cartListId?.shapeCut} Shaped, {cartListId?.cutGrade}{" "}
                        Cut, {cartListId?.colorGrade}-color,{" "}
                        {cartListId?.clarityGrade}
                        -clarity
                      </li>
                    ) : (
                      <>
                        <li>
                          <label>Color - </label>
                          {cartListId?.diamondInformation?.maxColor
                            ? `${cartListId?.diamondInformation?.maxColor} - ${cartListId?.diamondInformation?.minColor}`
                            : ""}
                        </li>
                        <li>
                          <label>Clarity - </label>

                          {cartListId?.diamondInformation?.maxClarity
                            ? `${cartListId?.diamondInformation?.maxClarity} - ${cartListId?.diamondInformation?.minClarity}`
                            : ""}
                        </li>
                      </>
                    )}
                  </ul>
                  {val?.productCategory !== 5
                    ? cartListId?.status !== 2 && (
                        <div className="quantity">
                          <button
                            disabled={val?.quantity < 2 && "disabled"}
                            onClick={(e) => increase(val, "dec")}
                          >
                            -
                          </button>

                          <span>{`${val?.quantity}`}</span>

                          <button
                            disabled={val.quantity > 4 && "disabled"}
                            onClick={(e) => increase(val, "inc")}
                          >
                            +
                          </button>
                        </div>
                      )
                    : ""}
                </div>
                <div className="d-flex justify-content-between buttonList">
                  <button
                    className="cartRemove"
                    onClick={(e) =>
                      cartRemove(cartListId?._id, val.productCategory)
                    }
                  >
                    <Dustbin width="16px" height="19px" />
                    Remove
                  </button>
                  {isInWish(cartListId?._id) && (
                    <button
                      className="wishlist"
                      onClick={() =>
                        alert(
                          "Inside Your WishList Click Delete to Remove From Cart "
                        )
                      }
                    >
                      <RedWish width="16px" height="14px" />
                      Already in wishlist
                    </button>
                  )}
                  {!isInWish(cartListId?._id) && (
                    <button
                      className="wishlist"
                      onClick={() =>
                        addedToWish(cartListId?._id, val.productCategory)
                      }
                    >
                      <RedWish width="16px" height="14px" />
                      Move to Wishlist
                    </button>
                  )}
                  {cartListId?.status !== 2 ? (
                    <h5>{`$ ${val?.price}`} </h5>
                  ) : (
                    <h5 className="out">Out of Stock</h5>
                  )}
                </div>
              </div>
            </>
          )}
        </div>
      );
    });
  };

  return (
    <Cart>
      <Container>
        <div className="mainHeading">
          <h3 className="title pt-4"> Shopping Cart</h3>
        </div>
        <div className="mainWrapCart flex-wrap">
          <h2 className="head">Shopping Cart</h2>
          <div className="leftBox">
            {cartItems.length !== 0 ? (
              cartListSection()
            ) : (
              <h4> Your Cart Is Empty </h4>
            )}
          </div>
          {totalAmount() !== 0 ? (
            <div className="rightColor position-relative">
              <div className="totalPrice">
                <ul className="listName">
                  <li>
                    <h6>Order Number</h6>
                    <span>{order}</span>
                  </li>
                  <li>
                    <h6>Number of items</h6>
                    <span>{getQnty()}</span>
                  </li>
                  <li>
                    <h6>Amount</h6>
                    <span>${totalAmount()}</span>
                  </li>
                  <li>
                    <h6>
                      <span>FedEx Priority</span> Shipping
                    </h6>
                    <span>Free</span>
                  </li>
                  <li>
                    <h6>Taxes</h6>
                    <span>$0.00</span>
                  </li>
                </ul>
                <div className="total d-flex justify-content-between">
                  <h3>Total amount</h3>
                  <h2>${totalAmount()}</h2>
                </div>
                <CustomButton dark onClick={checkout}>
                  Proceed to Checkout
                </CustomButton>
                <div className="coupon">
                  <div className="d-flex align-items-stretch">
                    <input type="text" placeholder="coupon code" />
                    <CustomButton dark>Apply</CustomButton>
                  </div>
                </div>
                <h5 className="help">
                  Need Help?{" "}
                  <a href="tel:1800585669635" rel="noreferrer">
                    1800-5856-69635
                  </a>
                </h5>
              </div>
            </div>
          ) : (
            ""
          )}
          <section className="explore-more w-100">
            <div className="container">
              <div className="explore-more-inner">
                <div className="explore-more-left">
                  <h3>
                    <span>E</span>xplore more
                  </h3>
                </div>

                <div className="explore-gallery">
                  <div className="explore-gallery-inner">
                    <div className="gallery-item">
                      <div className="gallery-img">
                        <img src={`${More1}`} alt="" />
                      </div>
                      <h6>Engagement Ring</h6>
                    </div>

                    <div className="gallery-item">
                      <div className="gallery-img">
                        <img src={`${More2}`} alt="" />
                      </div>
                      <h6>Wedding Ring</h6>
                    </div>

                    <div className="gallery-item">
                      <div className="gallery-img">
                        <img src={`${More3}`} alt="" />
                      </div>
                      <h6>Diamond</h6>
                    </div>

                    <div className="gallery-item">
                      <div className="gallery-img">
                        <img src={`${More4}`} alt="" />
                      </div>
                      <h6>Diamond Jewellry</h6>
                    </div>
                    <Link to="earring">
                      <div className="gallery-item">
                        <div className="gallery-img">
                          <img src={`${More5}`} alt="" />
                        </div>
                        <h6>Earring</h6>
                      </div>
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>
        {totalAmount() !== 0 ? (
          <div className="allInfo">
            <div className="main-points">
              <ul className="list">
                <li>
                  <Delivery width="95px" height="73px" />
                  <h5>Free Shipping</h5>
                </li>
                <li>
                  <Cert width="89px" height="80px" />
                  <h5>Independentley Certified</h5>
                </li>
                <li>
                  <Ring width="78px" height="70px" />
                  <h5>Free Resizing</h5>
                </li>
                <li>
                  <Return width="81px" height="81px" />
                  <h5>100 Day Returns</h5>
                </li>
              </ul>
            </div>
            <div className="shippingInfo">
              <h3>Shipping Information</h3>
              <ul className="list">
                <li className="d-flex">
                  <h4>Receive on</h4>
                  <p>Monday, March 03</p>
                </li>
                <li className="d-flex">
                  <h4>Shipping via</h4>
                  <p>FedEx PRIORITY OVERNIGHT</p>
                </li>
              </ul>
            </div>
            <div className="shippingInfo">
              <h3>Order Information</h3>
              <ul className="list">
                <li className="d-flex">
                  <h4>Order Number</h4>
                  <p>{order}</p>
                </li>
                <li className="d-flex">
                  <h4>Number of items</h4>
                  <p>{getQnty()}</p>
                </li>
                <li className="d-flex">
                  <h4>Items total</h4>
                  <p>${totalAmount()}</p>
                </li>
                <li className="d-flex">
                  <h4>promo code</h4>
                  <p>NEWRD50</p>
                </li>
                <li className="d-flex">
                  <h4>fedex priority </h4>
                  <p>Free</p>
                </li>
                <li className="d-flex">
                  <h4>sales tax </h4>
                  <p>$0.00</p>
                </li>
              </ul>
              <CustomButton dark onClick={checkout}>
                Proceed to Checkout
              </CustomButton>
              <h5 className="help">
                Need Help?{" "}
                <a href="tel:1800585669635" rel="noreferrer">
                  1800-5856-69635
                </a>
              </h5>
            </div>
          </div>
        ) : (
          ""
        )}
      </Container>
    </Cart>
  );
}
