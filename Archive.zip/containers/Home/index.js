import React, { useState, useEffect } from "react";
import { Container } from "reactstrap";
import APIUtil from "../../api";
import Explore from "../../components/Explore";
import Help from "../../components/Help";
import Recent from "../../components/RecentView";
import Newsletter from "../../components/Newsletter";
import USP from "../../components/USP";
import CreateYourOwn from "../../components/CreateYourOwn";
import HomeMobileBanner from "../../components/Mobile/Home/banner";

//css
import { HomeWrap } from "../../css/home";

//images
import BestSelling from "../../assets/images/home/modal-1.png";
import Dummy from "../../assets/images/home/prduct1.png";

import LosseDiamond from "../../assets/images/home/loose-diamonds.png";
import Limited from "../../assets/images/home/limited-ava.png";
import Lab from "../../assets/images/home/lab-created.png";

import { ReactComponent as LabHome } from "../../assets/images/home/home.svg";
import { ReactComponent as Lock } from "../../assets/images/home/lock.svg";
import { ReactComponent as Beauty } from "../../assets/images/home/beauty.svg";

import Product360View from "../../components/Product360View";
const api = new APIUtil();

const Home = (props) => {
  const [productData, setProductData] = useState([]);
  const [subcribe, setSubscribe] = useState();
  const [err, setErr] = useState("");

  //product display in home page fetch
  const data = async () => {
    await api.get("studs/limitedStuds").then((res) => {
      const data = res.data.data;
      setProductData(data);
    });
  };

  useEffect(() => {
    data();
  }, []);

  const clickSubscribe = async (e) => {
    const val1 = "@";
    const val2 = ".";
    if (subcribe !== undefined) {
      const check = subcribe.includes(val1 && val2);
      if (check) {
        const emailVal = {
          gender: e.target.value,
          email: subcribe,
        };

        await api
          .post(`users/newsletterSubscription`, emailVal)
          .then((res) => {
            if (res.status == 200) {
              setErr("You have Subscribed");
              setSubscribe("");
            }
          })
          .catch((err1) => {
            setErr(
              err1 == "Error: Request failed with status code 405"
                ? "Enter valid email"
                : ""
            );
          });
      } else {
        setErr("Enter valid email");
      }
    }
  };

  const formSubmit = (e) => {
    e.preventDefault();
  };
  return (
    <HomeWrap>
      <section className="banner">
        <div className="banner-caption">
          <div className="banner-caption-top">
            <div className="top-inner">
              <a href="">DIAMOND STUDS</a>
              <a href="">DIAMOND STUDS</a>
              <a href="">DIAMOND STUDS</a>
              <a href="">DIAMOND STUDS</a>
              <a href="">DIAMOND STUDS</a>
              <a href="">DIAMOND STUDS</a>
            </div>
          </div>

          <div className="banner-caption-bottom">
            <div className="bottom-inner">
              <a href="">Exclusive Collections</a>
              <a href="">Exclusive Collections</a>
              <a href="">Exclusive Collections</a>
              <a href="">Exclusive Collections</a>
              <a href="">Exclusive Collections</a>
              <a href="">Exclusive Collections</a>
            </div>
          </div>
        </div>
      </section>

      <section className="banner-mobile">
        <HomeMobileBanner />
      </section>

      <section className="best-selling">
        <div className="best-selling-inner">
          <div className="best-selling-pic">
            <img src={`${BestSelling}`} alt="" />
          </div>

          <div className="best-selling-products">
            <div className="products-heading common-heading">
              <h3>
                <span>B</span>est Selling Products
              </h3>
            </div>

            <div className="best-selling-products-container">
              <div className="product-item">
                <div className="product-img">
                  <img src={`${Dummy}`} alt="" />
                </div>
                <h4>Diamond Hoop earring</h4>
                <span className="product-weight">14k White Gold (4 ct.tw)</span>
                <div className="price-container">
                  <strike>$74585</strike>
                  $74585
                </div>
              </div>
            </div>

            <div className="arrow-custom">
              <a href="javascript:void(0);" className="prev"></a>
              <a href="javascript:void(0);" className="next"></a>
            </div>
          </div>
        </div>
      </section>

      <Explore home />

      <CreateYourOwn />

      <Help />

      <section className="loose-diamonds">
        <div className="loose-diamonds-inner">
          <div className="large-pic">
            <img src={`${LosseDiamond}`} alt="" />
            <div className="active-img">
              <img src="images/princess.png" alt="" />
            </div>
          </div>

          <div className="loose-diamond-category">
            <div className="common-heading">
              <h3>
                <span>S</span>earch for Loose Diamonds
              </h3>
            </div>

            <div className="loose-diamonds-list">
              <ul>
                <li>
                  <img src="images/princess.png" alt="" />
                  <h4>Princess</h4>
                </li>

                <li>
                  <img src="images/cushion.png" alt="" />
                  <h4>Cushion</h4>
                </li>

                <li>
                  <img src="images/oval.png" alt="" />
                  <h4>Oval</h4>
                </li>

                <li>
                  <img src="images/emerald.png" alt="" />
                  <h4>Emerald</h4>
                </li>

                <li>
                  <img src="images/pear.png" alt="" />
                  <h4>Pear</h4>
                </li>

                <li>
                  <img src="images/asscher.png" alt="" />
                  <h4>Asscher</h4>
                </li>

                <li>
                  <img src="images/heart.png" alt="" />
                  <h4>Heart</h4>
                </li>

                <li>
                  <img src="images/radiant.png" alt="" />
                  <h4>Radiant</h4>
                </li>

                <li>
                  <img src="images/Marquise.png" alt="" />
                  <h4>Marquise</h4>
                </li>
              </ul>

              <div className="arrow-custom">
                <a href="javascript:void(0);" className="prev"></a>
                <a href="javascript:void(0);" className="next"></a>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="limited-availability">
        <Container>
          <div className="limited-availability-outer">
            <div className="limited-availability-inner">
              <div className="col-1-txt">
                <div className="common-heading">
                  <h3>
                    <span>L</span>imited Availability
                  </h3>
                  <p>
                    Fall in love with this hand-selected collection of luxurious
                    lab created diamond jewelry
                  </p>
                </div>
              </div>
              <div className="col-2-txt limited-slide">
                <div className="product-item">
                  <div className="product-img">
                    <img src={`${Dummy}`} alt="" />
                  </div>
                  <h4>Diamond Hoop earring</h4>
                  <span className="product-weight">
                    14k White Gold (4 ct.tw)
                  </span>
                  <div className="price-container">
                    <strike>$74585</strike> $74585
                  </div>
                </div>
              </div>
              <div className="col-3-img">
                <img src={`${Limited}`} alt="" />
              </div>
              <div className="col-1-txt-r2 limited-slide">
                <div className="product-item">
                  <div className="product-img">
                    <img src={`${Dummy}`} alt="" />
                  </div>
                  <h4>Diamond Hoop earring</h4>
                  <span className="product-weight">
                    14k White Gold (4 ct.tw)
                  </span>
                  <div className="price-container">
                    <strike>$74585</strike> $74585
                  </div>
                </div>
              </div>
              <div className="col-2-txt-r2 limited-slide">
                <div className="product-item">
                  <div className="product-img">
                    <img src={`${Dummy}`} alt="" />
                  </div>
                  <h4>Diamond Hoop earring</h4>
                  <span className="product-weight">
                    14k White Gold (4 ct.tw)
                  </span>
                  <div className="price-container">
                    <strike>$74585</strike> $74585
                  </div>
                </div>
              </div>
              <div className="col-3-txt-r2 limited-slide">
                <div className="product-item">
                  <div className="product-img">
                    <img src={`${Dummy}`} alt="" />
                  </div>
                  <h4>Diamond Hoop earring</h4>
                  <span className="product-weight">
                    14k White Gold (4 ct.tw)
                  </span>
                  <div className="price-container">
                    <strike>$74585</strike> $74585
                  </div>
                </div>
              </div>
            </div>
          </div>
        </Container>
      </section>

      <section className="why-radix">
        <Container>
          <div className="why-radix-inner">
            <h4>Why Radix</h4>
            <p>WE ARE RUNNING HARD SINCE WE HAVE BIG VISION ON MISSION</p>
            <a href="/" rel="noreferrer" className="read-more">
              Read more
            </a>
          </div>
        </Container>
      </section>
      <USP />

      <section className="lab-created">
        <Container>
          <div className="lab-created-inner">
            <div className="left-image">
              <img src={`${Lab}`} alt="" />
            </div>

            <div className="lab-info">
              <div className="common-heading">
                <h3>
                  <span>W</span>hy lab Created Diamonds ?
                </h3>
              </div>

              <div className="lab-created-list">
                <div className="lab-item">
                  <div className="lab-icon">
                    <LabHome width="70px" height="70px" />
                  </div>
                  <div className="lab-text-info">
                    <h5>ECO FRIENDLY</h5>
                    <p>
                      For every carat of diamond that is mined nearly 100 sq ft
                      of landis disturbed and almost 6000 lbs of mineral waste
                      is created
                    </p>
                  </div>
                </div>

                <div className="lab-item">
                  <div className="lab-icon">
                    <Lock width="59px" height="67px" />
                  </div>
                  <div className="lab-text-info">
                    <h5>COMPATITIVELY PRICED</h5>
                    <p>
                      For every carat of diamond that is mined nearly 100 sq ft
                      of landis disturbed and almost 6000 lbs of mineral waste
                      is created
                    </p>
                  </div>
                </div>

                <div className="lab-item">
                  <div className="lab-icon">
                    <Beauty width="73px" height="60px" />
                  </div>
                  <div className="lab-text-info">
                    <h5>Beauty & Quality</h5>
                    <p>
                      Man made diamonds have the same physical, chemical, and
                      optical properties as mined diamonds.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </Container>
      </section>

      <div className="recentView">
        <Container>
          <Recent />
        </Container>
      </div>
      <Newsletter />
    </HomeWrap>
  );
};

export default Home;
