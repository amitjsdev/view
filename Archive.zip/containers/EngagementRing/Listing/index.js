import React, { useEffect, useState } from "react";
import APIUtil from "../../../api";
import { fetchMinMaxApi } from "../../../services/publicApi/engagementRing.js";
import PriceSlide from "../../../components/Filters/Price";
import CustomDropdown from "../../../components/Dropdown";
import { useHistory, useLocation } from "react-router-dom";
import { ringShape, StoneShape } from "../../../constant/filters";
import Metal from "../../../components/Filters/Metal";
import { CustomButton } from "../../../css/global";
import { Container } from "reactstrap";
import { UserDetails } from "../../../constant";
//images
import dummyImg from "../../../assets/images/er-Img.jpeg";
// css
import { Listing } from "../../../css/hoops";
import { Filters } from "../../../css/filters";
import ProgressStrip from "../../../components/ProgressStrip";

const api = new APIUtil();

const EngagementListing = () => {
  const history = useHistory();
  const userId = UserDetails();
  
  const search = useLocation().search;
  const diamondId = new URLSearchParams(search).get("diamondId");
  const filterPage = new URLSearchParams(search).get("filterPage");

  const [finalValue, setfinalValue] = useState([]);
  const [finalMetal, setFinalMetal] = useState([]);
  const [finalValueRange, setFinalValueRange] = useState();
  const [selectedMetal, setSelectedMetal] = useState([]);
  const [stoneShape, setStoneShape] = useState([]);
  const [loadMore, setLoadMore] = useState(1);
  const [totalPages, setTotalPages] = useState();
  const [sort, setSort] = useState("sort=1");
  const [load, setLoad] = useState(false);
  const [diamondShape, setDiamondShape] = useState();
  const [ringShapeData, setRingShapeData] = useState([]);
  const [filtersvalues, setFiltersvalues] = useState([]);
  const [tags, setTags] = useState([]);
  const [minMax, setMinMax] = useState({
    min: 0,
    max: 0,
  });

  //get price range
  const minAndMaxPrice = async () => {
    await fetchMinMaxApi().then((res) => {
      const x = res[0].min.$numberDecimal;
      const y = res[0].max.$numberDecimal;
      setMinMax({
        min: x,
        max: y,
      });
      setFinalValueRange({
        min: x,
        max: y,
      });
      setLoad(true);
    });
  };

  const caratValue =
    selectedMetal.length === 0 ? "" : `&metalWithCarat=${[...selectedMetal]}`;

  const finRingShapeData =
    ringShapeData.length === 0 ? "" : `&ring_shape=${[...ringShapeData]}`;

  const finStoneShape =
    stoneShape.length === 0 ? "" : `&stone_shape=${[...stoneShape]}`;

  const filters = async () => {
    await api
      .get(
        `engagementrings/filter?pageNumber=${loadMore}&numberRecord=20${caratValue}${finStoneShape}${finRingShapeData}&${sort}&minPrice=${finalValueRange?.min}&maxPrice=${finalValueRange?.max}`
      )
      .then((res) => {
        const data = res.data.data.EngagementRing;
        setfinalValue(data);
        setTotalPages(res.data.data.page);
      });
  };

 
  useEffect(() => {
    if (!!diamondId && !!userId?._id) {
      api.get(`products/ringReview?id=${userId._id.toString()}`).then((res) => {
        let ringReviewData = Object.values(res.data.data);
        ringReviewData &&
          ringReviewData.length > 0 &&
          ringReviewData.map((item) => {
            if (item?.looseDiamondId?._id == diamondId) {
              setDiamondShape(item.looseDiamondId?.shapeCut);
            }
          });
      });
    }
  }, []);

  useEffect(() => {
    minAndMaxPrice();
  }, []);

  useEffect(() => {
    if (load) {
      filters();
    }
  }, [
    load,
    tags,
    finalValueRange,
    selectedMetal,
    ringShapeData,
    finRingShapeData,
    caratValue,
    finStoneShape,
  ]);

  const onClickHandle = async (val) => {
    const metal = val.metal.split(" ");
    history.push({
      pathname: `/engagement-rings-details/${val._id}/${val.metalCarat}/${metal[0]}`,
    });
  };

  const images = () => {
    return (
      finalValue?.length > 0 &&
      finalValue?.map((val, i) => {
        return (
          <div className="products-listing" key={i}>
            <img
              onClick={() => onClickHandle(val)}
              src={
                val.productsPreviewImages[0]
                  ? val.productsPreviewImages[0]
                  : dummyImg
              }
              alt=""
              className="img-fluid"
            />
            <h2 onClick={() => onClickHandle(val)}>{val.name}</h2>
            <h4>({val.totalCaratWeightRing?.$numberDecimal} ct.tw)</h4>
            <div className="d-flex justify-content-between align-items-center">
              <h5>$ {val.price?.$numberDecimal} </h5>
            </div>
          </div>
        );
      })
    );
  };

  //Pagination
  const pagination = async () => {
    setLoadMore((prev) => {
      return prev + 1;
    });

    await api
      .get(
        `engagementrings/filter?pageNumber=${loadMore}&numberRecord=20${caratValue}${finStoneShape}${finRingShapeData}&${sort}&minPrice=${finalValueRange?.min}&maxPrice=${finalValueRange?.max}`
      )
      .then((res) => {
        const data = res.data.data.EngagementRing;
        setfinalValue((prevState) => [...prevState, ...data]);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const handleChange = (e, ringFilter) => {
    let singleValue;
    let options = [];
    if (ringFilter === "ringFilter") {
      singleValue = e[0]?.value;
      options = e && e[0].key ? e[0].key : [];
    } else {
      singleValue = e?.value;
      options = e && e.key ? e.key : [];
    }
    if (filtersvalues.includes(singleValue)) {
      const filter = filtersvalues.filter(function (data) {
        return data !== singleValue;
      });
      setFiltersvalues(filter);

      switch (options) {
        case "stoneshape":
          const filter1 = stoneShape.filter(function (data) {
            return data !== singleValue;
          });
          setStoneShape(filter1);

          break;
        case "ringShape":
          const filter2 = ringShapeData.filter(function (data) {
            return data !== singleValue;
          });
          setRingShapeData(filter2);
          break;
        default:
      }
    } else {
      setFiltersvalues((prevState) => {
        const x = [...prevState, singleValue];
        return x;
      });
      switch (options) {
        case "stoneshape":
          setStoneShape((prevState) => {
            const x = [...prevState, singleValue];
            return x;
          });
          setTags((prevState) => {
            const y = [...prevState, singleValue];
            return y;
          });
          break;
        case "ringShape":
          setRingShapeData((prevState) => {
            const x = [...prevState, singleValue];
            return x;
          });
          setTags((prevState) => {
            const y = [...prevState, singleValue];
            return y;
          });
          break;
        default:
      }
    }
  };

  const tagClick = (e) => {
    const filterTags = tags.filter(function (data) {
      return data !== e;
    });
    let metalTags = localStorage.getItem(filterPage+`metalData`);
    if (metalTags != null) {
      let metalData = localStorage.getItem(filterPage+`metalData`).split(",");
      const metalDataIndex = metalData.findIndex((item) => item == e);
      if (metalDataIndex !== -1) {
        metalData.splice(metalDataIndex, 1);
      }
      localStorage.setItem(filterPage+`metalData`, metalData);
    }
    let dupFilterTags = filterTags.filter(
      (v, i, a) => a.findIndex((t) => t === v) === i
    );

    const stoneIndex = stoneShape.findIndex((item) => item == e);
    if (stoneIndex !== -1) {
      stoneShape.splice(stoneIndex, 1);
    }
    if (stoneShape.length == 0) {
      localStorage.setItem(filterPage+`-stoneshape`, "");
    }

    setStoneShape(stoneShape);

    const ringShapeIndex = ringShapeData.findIndex((item) => item == e);
    if (ringShapeIndex !== -1) {
      ringShapeData.splice(ringShapeIndex, 1);
    }
    if (ringShapeData.length == 0) {
      localStorage.setItem(filterPage+`-ringShape`, "");
    }

    setRingShapeData(ringShapeData);

    const selectedMetalIndex = selectedMetal.findIndex((item) => item == e);
    if (selectedMetalIndex !== -1) {
      selectedMetal.splice(selectedMetalIndex, 1);
    }
    setSelectedMetal(selectedMetal);

    setTags(dupFilterTags);
  };

  const setSorting = (e) => {
    setSort(e);
    setLoadMore(1);
  };

  return (
    <Listing>
      {!!diamondId && <ProgressStrip ring />}
      <div className="filters">
        <Container>
          <div className="d-flex align-items-center">
            <Filters>
              <div className="filterSection">
                <h4>
                  <span>H</span>ello,
                </h4>
                <div className="d-flex filter-paragraph flex-wrap align-items-center">
                  Please help me to sort result of
                  <PriceSlide
                    minMax={minMax}
                    setMinMax={setMinMax}
                    setFinalValueRange={setFinalValueRange}
                    finalValueRange={finalValueRange}
                  />
                  with
                  <CustomDropdown
                   filterPage={filterPage}
                    diamondShape={diamondShape}
                    placeholder="Stone Shape"
                    options={StoneShape}
                    setRingShapeData
                    handleChange={handleChange}
                    setTags={setTags}
                    tags={tags}
                  />
                  and
                  <CustomDropdown
                   filterPage={filterPage}
                    placeholder="Ring Style"
                    options={ringShape}
                    setRingShapeData
                    handleChange={handleChange}
                    setTags={setTags}
                    tags={tags}
                  />
                  and
                  <Metal
                   filterPage={filterPage}
                    setSelectedMetal={setSelectedMetal}
                    selectedMetal={selectedMetal}
                    setTags={setTags}
                    tags={tags}
                    finalMetal={finalMetal}
                    setFinalMetal={setFinalMetal}
                  />
                </div>
              </div>
            </Filters>
          </div>

          <div class="sorting-wrap">
            <div className="sorting d-flex justify-content-end align-items-center">
              <select value={sort} onChange={(e) => setSorting(e.target.value)}>
                <option value={"sort=1"}>Price: Low to High</option>
                <option value={"sort=-1"}>Price: High to Low</option>
              </select>
            </div>
            <div class="sorting-tags">
              {tags.map((val) => (
                <button onClick={() => tagClick(val)}>{val}</button>
              ))}
            </div>
            <div className="d-grid productListing">{images()}</div>
            {totalPages !== loadMore && (
              <div className="show-more">
                <CustomButton onClick={pagination} cursive>
                  Show More
                </CustomButton>
              </div>
            )}
          </div>
        </Container>
      </div>
    </Listing>
  );
};

export default EngagementListing;
