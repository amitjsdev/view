import React, { useState, useEffect, useContext, useLayoutEffect } from "react";
import { Carousel, Container, CarouselItem, CarouselControl } from "reactstrap";
import APIUtil from "../../../api";
import { useParams } from "react-router";
import { Authentication, UserDetails, metalColors } from "../../../constant";
import { CartContext } from "../../../context/CartContext";
import { Tooltip } from "@material-ui/core";
import ProgressStrip from "../../../components/ProgressStrip";
import Help from "../../../components/Help";
import { toast } from "react-toastify";

//css
import { ProductDetail } from "../../../css/productDetail";
import { CustomButton } from "../../../css/global";

//images
import dummyImg from "../../../assets/images/er-Img.jpeg";
import { ReactComponent as Cart } from "../../../assets/images/addcart.svg";
import { ReactComponent as Wishlist } from "../../../assets/images/addwishlist.svg";
import { ReactComponent as EmailUs } from "../../../assets/images/emailus.svg";
import { ReactComponent as HelpImg } from "../../../assets/images/help.svg";
import LuxuryGift from "../../../assets/images/detail/ring.png";
import { ReactComponent as Truck } from "../../../assets/images/shippingTruck.svg";
import { ReactComponent as DiamondRing } from "../../../assets/images/engagementRing/diamond-ring.svg";

const api = new APIUtil();

const EngagementRingDetail = (props) => {
  const { id, carat, color } = useParams();
  const isAuth = Authentication();
  const userId = UserDetails();
  const {
    addProduct,
    wishProduct,
    wishListId,
    wishListIdDel,
    cartListIdDel,
    cartListId,
  } = useContext(CartContext);
  const [productDetails, setProductDetails] = useState({});
  const [images, setImages] = useState([]);
  const [load, setLoad] = useState(true);
  const [activeIndex, setActiveIndex] = useState(0);
  const [animating, setAnimating] = useState(false);
  const [activeTab, setActiveTab] = useState("1");
  const [ringSize, setRingSize] = useState(0);
  const [ringProduct, setRingProduct] = useState([]);
  const [diamondProduct, setDiamondProduct] = useState([]);
  const [checkSettingID, setCheckSettingID] = useState([]);
  const [checkDiamondID, setCheckDiamondID] = useState([]);
  const [metalColor, setMetalColor] = useState(metalColors);

  const metalColorSelector = () => {
    const data = metalColor.map((val, i) => {
      const matchParam = carat + "-" + color;
      if (val.value === matchParam) {
        val["clicked"] = true;
        return val;
      } else {
        return {
          ...val,
          clicked: false,
        };
      }
    });

    setMetalColor(data);
  };

  useLayoutEffect(() => {
    metalColorSelector();
  }, []);

  useEffect(() => {
    //get rigg flow data
    api
      .get(`engagementrings/engagementRingsDetails?productId=${id}`)
      .then((res) => {
        setProductDetails(res.data.data);
        const productImages = res.data.data.productsPreviewImages;
        const modelImages = res.data.data.modelPreviewImages;
        setImages([...productImages, ...modelImages]);
        const metalWithCarat = res.data.data.metalWithCarat.split(" ");
        api
          .get(
            `engagementrings/ringsSearch?searchParam={diamondWeight:${
              res.data.data.totalCaratWeightRing?.$numberDecimal
            },metal:${`'${res.data.data.metal}'`},metalCarat:${
              metalWithCarat[0] == "Platinum" ? "0" : metalWithCarat[0]
            }}`
          )
          .then((res) => {});
      });
  }, []);

  const toggle = (tab) => {
    if (activeTab !== tab) setActiveTab(tab);
  };

  // slider
  const next = () => {
    if (animating) return;
    const nextIndex = activeIndex === images.length - 1 ? 0 : activeIndex + 1;
    setActiveIndex(nextIndex);
  };

  const previous = () => {
    if (animating) return;
    const nextIndex = activeIndex === 0 ? images.length - 1 : activeIndex - 1;
    setActiveIndex(nextIndex);
  };

  const goToIndex = (newIndex) => {
    if (animating) return;
    setActiveIndex(newIndex);
  };

  // Image slider
  const imageSlides =
    images &&
    images.length > 0 &&
    images.map((item, index) => {
      return (
        <CarouselItem
          onExiting={() => setAnimating(true)}
          onExited={() => setAnimating(false)}
          key={index}
        >
          <img src={item} className="test" alt="" />
        </CarouselItem>
      );
    });
  // Image slider

  // BankWire price Calculation
  const bankWire = () => {
    const totalPrice = productDetails?.price?.$numberDecimal;
    const bankwireDiscount = 1.5 / 100;
    const finalBankWirePrice = totalPrice - totalPrice * bankwireDiscount;
    return finalBankWirePrice.toFixed(2);
  };

  // To check product is already in wishlist or not
  const isInWish = (id) => {
    if (isAuth) {
      if (wishListId.includes(id)) {
        return true;
      } else {
        return false;
      }
    }
  };

  // to check the product is already in cart or not
  const isInCart = (id) => {
    if (isAuth) {
      if (cartListId.includes(id)) {
        return true;
      } else {
        return false;
      }
    }
  };

  // add product to settings
  const handleRedirect = async (price, id, category, ringSize) => {
    if (isAuth) {
      const token = localStorage.getItem("token");
      const headers = {
        Authorization: `Bearer ${token}`,
      };
      if (ringSize == 0) {
        toast.error("Please Select Ring Size");
      } else {
        //deleted already added product from setting
        if (checkSettingID?.engagementItem) {
          let new_data = {
            userId: userId._id.toString(),
            engagementRingId: checkSettingID?.engagementItem,
          };
          await api
            .post(`products/delRingReview`, new_data, { headers })
            .then((response) => {});
        }
        //end deleted already added product from setting
        let new_data = {
          userId: userId._id.toString(),
          engagementRingId: id,
          size: parseInt(ringSize),
        };
        await api
          .post(`products/addMakeRingReview`, new_data, { headers })
          .then((res) => {
            if (!!checkDiamondID?.looseDiamondItem) {
              localStorage.setItem("secondStep", id);
              props.history.push({
                pathname: `/complete-jewel/${id}`,
                search: `?stoneShapeId=${checkDiamondID?.looseDiamondItem}`,
              });
            } else {
              localStorage.setItem("firstStep", id);
              props.history.push(`/diamond-search?engagementRingId=${id}`);
            }
          });
      }
    }
  };

  // To Remove the product for cart
  const removeFromCart = async (id, category) => {
    if (isAuth) {
      const del_data = {
        userId: userId._id.toString(),
        productId: id,
      };
      await api.post("products/delCart", del_data).then((response) => {
        if (cartListId.includes(id)) {
          const filter = cartListId.filter(function (data) {
            return data !== id;
          });
          setLoad(!load);
          cartListIdDel(filter);
        }
      });
    }
  };

  // To remove the product from wishlist
  const wishListRemove = async (id, category) => {
    if (isAuth) {
      const del_data = {
        userId: userId._id.toString(),
        productId: id,
      };

      await api.post("products/delWishlist", del_data).then((response) => {
        if (wishListId.includes(id)) {
          const filter = wishListId.filter(function (data) {
            return data !== id;
          });
          setLoad(!load);

          wishListIdDel(filter);
        }
      });
    }
  };

  const toWishClick = async (id, category) => {
    if (isAuth) {
      const body = [
        {
          userId: userId._id.toString(),
          productId: id,
          productCategory: category,
        },
      ];

      await api.post("products/addWishlist", body).then((response) => {});
      setLoad(!load);
    }
  };

  useEffect(() => {
    if (isAuth) {
      addProduct(userId._id.toString());
      wishProduct(userId._id.toString());
    }
  }, [load]);

  const handlSelect = (e) => {
    setRingSize(e.target.value);
  };

  return (
    <ProductDetail looseDiamond>
      <ProgressStrip />
      <Container>
        <div className="product-card">
          <div className="product-image">
            {imageSlides && (
              <Carousel
                activeIndex={activeIndex}
                next={next}
                previous={previous}
              >
                {imageSlides}
                <CarouselControl
                  direction="prev"
                  directionText="Previous"
                  onClickHandler={previous}
                />
                <CarouselControl
                  direction="next"
                  directionText="Next"
                  onClickHandler={next}
                />
              </Carousel>
            )}
          </div>
          {/*  Ring product with stone shape section  */}

          <div className="product-details ring">
            <h2>
              {productDetails?.name}-Carat {productDetails?.shapeCut} cut
            </h2>
            <div className="d-flex align-items-center justify-content-start">
              <ul className="type-list">
                <li>
                  <div className="position-relative">
                    <DiamondRing width="67px" height="80px" />
                    <p>14</p>
                  </div>
                </li>
                <li>
                  <div className="position-relative yellow">
                    <DiamondRing width="67px" height="80px" />
                    <p>14</p>
                  </div>
                </li>
                <li>
                  <div className="position-relative rose">
                    <DiamondRing width="67px" height="80px" />
                    <p>14</p>
                  </div>
                </li>
              </ul>
              <ul className="type-list">
                <li>
                  <div className="position-relative">
                    <DiamondRing width="67px" height="80px" />
                    <p>18</p>
                  </div>
                </li>
                <li o>
                  <div className="position-relative yellow">
                    <DiamondRing width="67px" height="80px" />
                    <p>18</p>
                  </div>
                </li>
                <li>
                  <div className="position-relative rose">
                    <DiamondRing width="67px" height="80px" />
                    <p>18</p>
                  </div>
                </li>
              </ul>
              <ul className="type-list">
                <li>
                  <div className="position-relative">
                    <DiamondRing width="67px" height="80px" />
                    <p>Pt</p>
                  </div>
                </li>
              </ul>
            </div>
            <div className="product-price">
              {productDetails?.status !== 2 ? (
                <h3 className="product-price-original">
                  ${productDetails?.price?.$numberDecimal}
                </h3>
              ) : (
                <h3 className="product-price-original">Out of Stock</h3>
              )}
              {productDetails?.status !== 2 ? (
                <>
                  <h5>Bankwire - ${bankWire()}</h5>
                  <h5>
                    Welcome offer on first purchase, use <span>WELCOME21</span>{" "}
                    code{" "}
                  </h5>
                </>
              ) : (
                ""
              )}
            </div>
            <div className="d-flex justify-content-start btn-grp">
              {isInWish(
                productDetails?._id,
                productDetails?.productCategory
              ) && (
                <CustomButton
                  dark
                  onClick={() =>
                    wishListRemove(
                      productDetails?._id,
                      productDetails?.productCategory
                    )
                  }
                  className="customButton black"
                >
                  <Wishlist width="19px" height="19px" fill="#ff5000" />
                </CustomButton>
              )}

              {!isInWish(
                productDetails?._id,
                productDetails?.productCategory
              ) && (
                <Tooltip title={isAuth ? "" : "Login First "}>
                  <CustomButton
                    dark
                    onClick={() =>
                      toWishClick(
                        productDetails?._id,
                        productDetails?.productCategory
                      )
                    }
                    className="customButton black"
                  >
                    <Wishlist width="19px" height="19px" fill="#fff" />
                  </CustomButton>
                </Tooltip>
              )}

              {isInCart(
                productDetails?._id,
                productDetails?.productCategory
              ) && (
                <CustomButton
                  dark
                  onClick={() =>
                    removeFromCart(
                      productDetails?._id,
                      productDetails?.productCategory
                    )
                  }
                  className="customButton cart black"
                >
                  <Cart width="25px" height="21px" fill="#fff" /> Remove From
                  Cart
                </CustomButton>
              )}
              {productDetails?.status !== 2 ? (
                !isInCart(
                  productDetails?._id,
                  productDetails?.productCategory
                ) && (
                  <>
                    <Tooltip title={isAuth ? "" : "Login First "}>
                      <CustomButton
                        dark
                        className="customButton cart black"
                        onClick={() =>
                          handleRedirect(
                            productDetails?.price,
                            productDetails?._id,
                            productDetails?.productCategory,
                            ringSize
                          )
                        }
                      >
                        <Cart width="25px" height="21px" fill="#fff" /> Select
                        Settings
                      </CustomButton>
                    </Tooltip>

                    <select
                      onChange={(e) => {
                        handlSelect(e);
                      }}
                    >
                      <option value="">Ring Size</option>
                      <option value="1">1</option>
                      <option value="2">2</option>
                      <option value="3">3</option>
                      <option value="4">4</option>
                      <option value="5">5</option>
                      <option value="6">6</option>
                      <option value="7">7</option>
                      <option value="8">8</option>
                      <option value="9">9</option>
                    </select>
                  </>
                )
              ) : (
                <CustomButton dark className="customButton cart black">
                  Out of Stock
                </CustomButton>
              )}
            </div>

            <div className="shippingInfo position-relative d-flex align-items-center ring">
              <Truck width="57px" height="32px" />
              <p>Get Free ship by 21 Aug, If ordered Before 10:30 PM </p>
            </div>

            <div className="helpUs">
              <ul className="list d-flex justify-content-start">
                <li>
                  <a href="mailto:info@radixdiamond.co">
                    <EmailUs width="20px" height="15px" />
                    <p> Email Us</p>
                  </a>
                </li>
                <li>
                  <a href="tel:+1-800-242-2728">
                    <h4>
                      <HelpImg width="19px" height="19px" /> Need Help ?
                    </h4>
                    <p>+1-800-242-2728</p>
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>

        <div className="diamond-details-wrap ring">
          <h2>Product Detail</h2>
          <h2>Summary</h2>
          <h2>Can be set with</h2>
          <div className="d-flex">
            <div className="ring-content">
              <h4>Crafted Elegant Classic</h4>
              <p>
                Elegant in simplicity, this petite nouveau solitaire engagement
                ring is crafted in polished 14k white gold to create a classic
                frame for your center diamond.
              </p>
            </div>
            <ul className="list">
              <li>
                <label>Shape</label>
                <h4>{productDetails?.diamondShape}</h4>
              </li>
              <li>
                <label>Metal</label>
                <h4>{productDetails?.metalWithCarat}</h4>
              </li>
              <li>
                <label>Width</label>
                <h4>{productDetails?.ringWidth}</h4>
              </li>
              <li>
                <label>Prong Metal</label>
                <h4>{productDetails?.metal}</h4>
              </li>
              <li>
                <label>Sizes Available</label>
                <h4>3-9</h4>
              </li>
            </ul>
            <ul className="list">
              <li>
                <label>Round</label>
                <h4>
                  {productDetails?.roundRange?.diamondMinWt.$numberDecimal} -{" "}
                  {productDetails?.roundRange?.diamondMaxWt.$numberDecimal}
                  Carat
                </h4>
              </li>
              <li>
                <label>Princess</label>
                <h4>
                  {productDetails?.princessRange?.diamondMinWt.$numberDecimal} -{" "}
                  {productDetails?.princessRange?.diamondMaxWt.$numberDecimal}
                  Carat
                </h4>
              </li>
              <li>
                <label>Emerald</label>
                <h4>
                  {productDetails?.emeraldRange?.diamondMinWt.$numberDecimal} -{" "}
                  {productDetails?.emeraldRange?.diamondMaxWt.$numberDecimal}
                  Carat
                </h4>
              </li>
              <li>
                <label>Asscher</label>
                <h4>
                  {productDetails?.asscherRange?.diamondMinWt.$numberDecimal} -{" "}
                  {productDetails?.asscherRange?.diamondMaxWt.$numberDecimal}
                  Carat
                </h4>
              </li>
              <li>
                <label>Marquise</label>
                <h4>
                  {productDetails?.marquiseRange?.diamondMinWt.$numberDecimal} -{" "}
                  {productDetails?.marquiseRange?.diamondMaxWt.$numberDecimal}
                  Carat
                </h4>
              </li>
              <li>
                <label>Oval</label>
                <h4>
                  {productDetails?.ovalRange?.diamondMinWt.$numberDecimal} -{" "}
                  {productDetails?.ovalRange?.diamondMaxWt.$numberDecimal}
                  Carat
                </h4>
              </li>
              <li>
                <label>Radiant</label>
                <h4>
                  {productDetails?.radiantRange?.diamondMinWt.$numberDecimal} -{" "}
                  {productDetails?.radiantRange?.diamondMaxWt.$numberDecimal}
                  Carat
                </h4>
              </li>
              <li>
                <label>Pear</label>
                <h4>
                  {productDetails?.pearRange?.diamondMinWt.$numberDecimal} -{" "}
                  {productDetails?.pearRange?.diamondMaxWt.$numberDecimal}
                  Carat
                </h4>
              </li>
              <li>
                <label>Heart</label>
                <h4>
                  {productDetails?.heartRange?.diamondMinWt.$numberDecimal} -{" "}
                  {productDetails?.heartRange?.diamondMaxWt.$numberDecimal}
                  Carat
                </h4>
              </li>
              <li>
                <label>Cushion</label>
                <h4>
                  {productDetails?.cushionRange?.diamondMinWt.$numberDecimal} -{" "}
                  {productDetails?.cushionRange?.diamondMaxWt.$numberDecimal}
                  Carat
                </h4>
              </li>
            </ul>
          </div>
        </div>
      </Container>

      <Help />
      <section className="feel-luxury">
        <Container>
          <div className="feel-luxury-inner">
            <div className="feel-luxury-caption">
              <h2>
                <span>F</span>eel Luxury
              </h2>
              <p>
                Radix Provides you a Real Luxury Experience For Special Family
                members just like you and makes Purchase for specials and more
                Royal{" "}
              </p>
            </div>

            <div className="feel-luxury-img">
              <img className="img-fluid" src={`${LuxuryGift}`} alt="" />
            </div>
          </div>
        </Container>
      </section>
    </ProductDetail>
  );
};

export default EngagementRingDetail;
