import React from "react";
import { Container } from "reactstrap";
import CreateYourOwn from "../../../components/CreateYourOwn";
import Help from "../../../components/Help";
import Recent from "../../../components/RecentView";
import { Link, useHistory,useLocation } from "react-router-dom";

// css
import { RingWrap } from "../../../css/ring";
import { CustomButton } from "../../../css/global";

// images
import Ring from "../../../assets/images/engagementRing/ring1.png";
import LD from "../../../assets/images/engagementRing/looseDiamond.png";
import Dummy from "../../../assets/images/engagementRing/ring-dummy.png";
import Dummy2 from "../../../assets/images/engagementRing/dummyring-2.png";
import gal from "../../../assets/images/engagementRing/gallery1.png";
import gal1 from "../../../assets/images/engagementRing/gallery2.png";
import gal2 from "../../../assets/images/engagementRing/gallery3.png";
import gal3 from "../../../assets/images/engagementRing/gallery4.png";
import { ReactComponent as DiamondRing } from "../../../assets/images/engagementRing/diamond-ring.svg";

const EngagementRing = () => {
  const history = useHistory();
const pathname  = useLocation().pathname.replace(/[^a-zA-Z ]/g,'');
  //redirect to eangagement ring filter page with selected value
  const onClickHandle = (e) => {
    let localData = localStorage.getItem("ringShape");
    if (localData == null || localData == "") {
      localStorage.setItem("ringFilter", e);
    } else {
      let currentData = JSON.parse(localStorage.getItem("ringShape"));
      let ringFilterIndex = currentData.findIndex((item) => item.value == e);
      if (ringFilterIndex == -1) {
        localStorage.setItem("ringFilter", e);
      }
    }

    history.push({
      pathname: `/build-your-own-ring/settings`,
      search: `filterPage=${pathname}`,
    });
  };
  const onClickHandleMetal = (e) => {
    let localData = localStorage.getItem(pathname+"metalData");
    if (localData == null || localData == "") {
      localStorage.setItem(pathname+"metalData", e);
    } else {
      let currentData = localStorage.getItem(pathname+"metalData");
      if (!currentData.split(",").includes(e)) {
        let metalData = currentData + "," + e;
        localStorage.setItem(pathname+"metalData", metalData);
      }
    }
    history.push({
      pathname: `/build-your-own-ring/settings`,
      search: `filterPage=${pathname}`,
    });
  };
  return (
    <RingWrap>
      <div className="banner ring">
        <Container className="position-relative">
          <div className="bantext">
            <h1>Engagement</h1>
            <h2>Engagement Rings</h2>
            <p>
              Every Engagement Rings is handcrafted quadruple-checked and made
              to order for the perfect fit
            </p>
            <div className="d-flex btnGroup">
              <div className="ring-btn">
                <span>
                  <img src={`${Ring}`} alt="" />
                </span>
                <Link to={`/build-your-own-ring/settings?filterPage=${pathname}`}>
                  <CustomButton cursive className="customButton">
                    Shop Engagement Rings
                  </CustomButton>
                </Link>
              </div>
              <div className="diamond-btn">
                <span>
                  <img src={`${LD}`} alt="" />
                </span>
                <Link to="/diamond-search">
                  <CustomButton cursive className="customButton">
                    Shop Loose diamonds
                  </CustomButton>
                </Link>
              </div>
            </div>
          </div>
        </Container>
      </div>
      <div className="ring-style">
        <Container>
          <div className="common-heading">
            <h3>
              <span>E</span>
              ngagement Ring by style
            </h3>
          </div>
          <div className="style-list">
            <ul className="list">
              <li
                onClick={() => {
                  onClickHandle("Solitaire");
                }}
              >
                <span>
                  <img className="img-fluid" src={`${Dummy}`} alt="" />
                </span>
                <h4>Solitaire</h4>
              </li>
              <li
                onClick={() => {
                  onClickHandle("Pave");
                }}
              >
                <span>
                  <img className="img-fluid" src={`${Dummy}`} alt="" />
                </span>
                <h4>Pave</h4>
              </li>
              <li
                onClick={() => {
                  onClickHandle("Channel Set");
                }}
              >
                <span>
                  <img className="img-fluid" src={`${Dummy}`} alt="" />
                </span>
                <h4>Channel Set</h4>
              </li>
              <li
                onClick={() => {
                  onClickHandle("Sidestone");
                }}
              >
                <span>
                  <img className="img-fluid" src={`${Dummy}`} alt="" />
                </span>
                <h4>Sidestone</h4>
              </li>
              <li
                onClick={() => {
                  onClickHandle("3 Stone");
                }}
              >
                <span>
                  <img className="img-fluid" src={`${Dummy}`} alt="" />
                </span>
                <h4>3 Stone</h4>
              </li>
              <li
                onClick={() => {
                  onClickHandle("Halo");
                }}
              >
                <span>
                  <img className="img-fluid" src={`${Dummy}`} alt="" />
                </span>
                <h4>Halo</h4>
              </li>
              <li
                onClick={() => {
                  onClickHandle("Vintage");
                }}
              >
                <span>
                  <img className="img-fluid" src={`${Dummy}`} alt="" />
                </span>
                <h4>Vintage</h4>
              </li>
              <li
                onClick={() => {
                  onClickHandle("Unique");
                }}
              >
                <span>
                  <img className="img-fluid" src={`${Dummy}`} alt="" />
                </span>
                <h4>Unique</h4>
              </li>
            </ul>
          </div>
        </Container>
      </div>
      <div className="metal-type">
        <Container>
          <div className="d-flex align-items-center justify-content-center">
            <h2>Browse by Metal Type</h2>
            <ul className="type-list">
              <li
                onClick={() => {
                  onClickHandleMetal("Platinum");
                }}
              >
                <div className="position-relative">
                  <DiamondRing width="67px" height="80px" />
                  <p>14</p>
                </div>
                <h4>White Gold</h4>
              </li>
              <li
                onClick={() => {
                  onClickHandleMetal("Yellow 14");
                }}
              >
                <div className="position-relative yellow">
                  <DiamondRing width="67px" height="80px" />
                  <p>14</p>
                </div>
                <h4>Yellow Gold</h4>
              </li>
              <li
                onClick={() => {
                  onClickHandleMetal("Rose 14");
                }}
              >
                <div className="position-relative rose">
                  <DiamondRing width="67px" height="80px" />
                  <p>14</p>
                </div>
                <h4>Rose Gold</h4>
              </li>
            </ul>
            <ul className="type-list">
              <li
                onClick={() => {
                  onClickHandleMetal("White 18");
                }}
              >
                <div className="position-relative">
                  <DiamondRing width="67px" height="80px" />
                  <p>18</p>
                </div>
                <h4>White Gold</h4>
              </li>
              <li
                onClick={() => {
                  onClickHandleMetal("Yellow 18");
                }}
              >
                <div className="position-relative yellow">
                  <DiamondRing width="67px" height="80px" />
                  <p>18</p>
                </div>
                <h4>Yellow Gold</h4>
              </li>
              <li
                onClick={() => {
                  onClickHandleMetal("Rose 18");
                }}
              >
                <div className="position-relative rose">
                  <DiamondRing width="67px" height="80px" />
                  <p>18</p>
                </div>
                <h4>Rose Gold</h4>
              </li>
            </ul>
            <ul className="type-list">
              <li
                onClick={() => {
                  onClickHandleMetal("Platinum");
                }}
              >
                <div className="position-relative">
                  <DiamondRing width="67px" height="80px" />
                  <p>Pt</p>
                </div>
                <h4>Platinum</h4>
              </li>
            </ul>
          </div>
        </Container>
      </div>
      <CreateYourOwn />
      <div className="ring-by">
        <Container>
          <div className="common-heading">
            <h3 className="justify-content-end">
              <span>E</span>
              ngagement Ring by style
            </h3>
          </div>
          <div className="gallery-selection">
            <span className="white-stripe"></span>
            <ul className="list">
              <li>
                <span>
                  <img className="img-fluid" src={`${Dummy2}`} alt="" />
                </span>
                <p>The Gallery collection Halo Diamond Engagement Ring</p>
              </li>
              <li>
                <span>
                  <img className="img-fluid" src={`${Dummy2}`} alt="" />
                </span>
                <p>The Gallery collection Halo Diamond Engagement Ring</p>
              </li>
              <li>
                <span>
                  <img className="img-fluid" src={`${Dummy2}`} alt="" />
                </span>
                <p>The Gallery collection Halo Diamond Engagement Ring</p>
              </li>
              <li>
                <span>
                  <img className="img-fluid" src={`${Dummy2}`} alt="" />
                </span>
                <p>The Gallery collection Halo Diamond Engagement Ring</p>
              </li>
            </ul>
          </div>
        </Container>
      </div>
      <Help />
      <div className="engagement-story">
        <Container>
          <h2>There's nothing more personal than an engagement ring</h2>
          <p>
            View our genuine customer engagement moments from around the world.
            Get inspired by our collection of proposal stories from James Allen
            customers, and view the diamond rings behind the moments. Read the
            stories for proposal inspiration or share your own James Allen
            engagement moment!
          </p>
        </Container>
        <div className="gallery">
          <ul className="d-flex">
            <li>
              <span>
                <img src={`${gal}`} className="img-fluid" alt="" />
              </span>
              <div className="overlay">
                <h4>Joy&Lara</h4>
              </div>
            </li>
            <li>
              <span>
                <img src={`${gal1}`} className="img-fluid" alt="" />
              </span>
              <div className="overlay">
                <h4>Joy&Lara</h4>
              </div>
            </li>
            <li>
              <span>
                <img src={`${gal2}`} className="img-fluid" alt="" />
              </span>
              <div className="overlay">
                <h4>Joy&Lara</h4>
              </div>
            </li>
            <li>
              <span>
                <img src={`${gal3}`} className="img-fluid" alt="" />
              </span>
              <div className="overlay">
                <h4>Joy&Lara</h4>
              </div>
            </li>
          </ul>
        </div>
      </div>
      <div className="recentView">
        <Container>
          <Recent />
        </Container>
      </div>
    </RingWrap>
  );
};

export default EngagementRing;
