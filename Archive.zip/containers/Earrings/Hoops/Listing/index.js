import React, { useContext, useEffect, useState } from "react";
import { Col, Container, Row } from "reactstrap";
import CustomFilters from "../../../../components/Filters/EarringsFilters";
import APIUtil from "../../../../api";
import { CartContext } from "../../../../context/CartContext";
import { useHistory,useLocation } from "react-router-dom";
import GiftCard from "../../../../components/Gift";
import Recent from "../../../../components/RecentView";
//css
import { Listing } from "../../../../css/hoops";
import { CustomButton } from "../../../../css/global";
// images
import Banner from "../../../../assets/images/hoops/listing/listingBan.png";

const api = new APIUtil();

const HoopsListing = () => {
  const history = useHistory();
  const search = useLocation().search;
  const filterPage = new URLSearchParams(search).get("filterPage");

  const [finalValueRange, setFinalValueRange] = useState();
  const [finalMetal, setFinalMetal] = useState(["Rose"]);
  const [values, setValues] = useState([]);
  const [tags, setTags] = useState([]);
  const [selectedMetal, setSelectedMetal] = useState([]);
  const [stoneShape, setStoneShape] = useState([]);
  const [hoopSizes, setHoopSizes] = useState([]);
  const [hoopProngs, setHoopProngs] = useState([]);
  const [backType, setBackType] = useState([]);
  const { ranges, priceRangeValues } = useContext(CartContext);
  const [finalValue, setfinalValue] = useState([]);
  const [sort, setSort] = useState("sort=1");
  const [load, setLoad] = useState(false);
  const [loadMore, setLoadMore] = useState(1);
  const [totalPages, setTotalPages] = useState();
  const [filtersvalues, setFiltersvalues] = useState([]);
  const [minMax, setMinMax] = useState({
    min: 0,
    max: 0,
  });

  const caratValue =
    selectedMetal.length === 0 ? "" : `&metalWithCarat=${[...selectedMetal]}`;

  const finStoneShape =
    stoneShape.length === 0 ? "" : `&stone_shape=${[...stoneShape]}`;

  const finHoopSizes =
    hoopSizes.length === 0 ? "" : `&product_type: ${[...hoopSizes]}`;

  const finHoopProngs =
    hoopProngs.length === 0 ? "" : `&setting_type: ${[...hoopProngs]}`;

  const finBackType =
    backType.length === 0 ? "" : `&earring_back=${[...backType]}`;

  const data = () => {
    api
      .get(
        `hoops/hoopsFilter?pageNumber=${loadMore}&numberRecord=20${finHoopSizes}${finHoopProngs}${caratValue}${finStoneShape}${finBackType}&${sort}&minPrice=${finalValueRange.min}&maxPrice=${finalValueRange.max}`
      )
      .then((res) => {
        const data = res.data.data.Hoops;
        setfinalValue(data);
        setTotalPages(res.data.data.page);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const priceRanges = async () => {
    await api.get(`hoops/minMaxPrice`).then((res) => {
      const x = res.data.data[0].min.$numberDecimal;
      const y = res.data.data[0].max.$numberDecimal;
      const hopsPrice = localStorage.getItem("hoopsPrice");
      setFinalValueRange({ min: hopsPrice != null ? hopsPrice : x, max: y });
      setMinMax({ min: hopsPrice != null ? hopsPrice : x, max: y });

      // priceRangeValues({ min: hopsPrice != null ? hopsPrice : x, max: y });
      // setMinMaxPrice({ min: hopsPrice != null ? hopsPrice : x, max: y });

      setLoad(true);
    });
  };

  useEffect(() => {
    priceRanges();
  }, []);

  useEffect(() => {
    if (load) {
      data();
    }
  }, [
    load,
    sort,
    minMax,
    values,
    selectedMetal,
    finHoopSizes,
    finHoopProngs,
    finStoneShape,
    backType,
    caratValue,
    finalValueRange,
    tags,
  ]);

  const onClickHandle = (val) => {
    history.push({
      pathname: `/productDetail/${val._id}/${val.metalCarat}/${val.metal}`,
    });
  };

  const selectedColor = (weight, metalCarat, name) => {
    api
      .get(
        `hoops/hoopsDetails?searchParam={diamondWeight:${weight},metal:${`'${name}'`},metalCarat:${metalCarat}}`
      )
      .then((res) => {
        history.push({
          pathname: `/productDetail/${res.data.data._id}/${metalCarat}/${name}`,
        });
      });
  };

  const images = () => {
    return finalValue.map((val, i) => {
      return (
        <div className="products-listing" key={i}>
          <img
            onClick={() => onClickHandle(val)}
            src={val.images.hoopsImages}
            alt=""
            className="img-fluid"
          />
          <h2 onClick={() => onClickHandle(val)}>{val.name}</h2>
          <h4>
            {val.metalCarat}K {val.metal} Gold (
            {val.diamondWeight.$numberDecimal} ct.tw)
          </h4>
          <div className="d-flex justify-content-between align-items-center">
            <ul className="icons">
              <li
                className="rose"
                onClick={() =>
                  selectedColor(
                    val.diamondWeight.$numberDecimal,
                    val.metalCarat,
                    "Rose"
                  )
                }
              ></li>
              <li
                className="white"
                onClick={() =>
                  selectedColor(
                    val.diamondWeight.$numberDecimal,
                    val.metalCarat,
                    "White"
                  )
                }
              ></li>
              <li
                className="yellow"
                onClick={() =>
                  selectedColor(
                    val.diamondWeight.$numberDecimal,
                    val.metalCarat,
                    "Yellow"
                  )
                }
              ></li>
            </ul>
            <h5>$ {val.totalPrice.$numberDecimal} </h5>
          </div>
        </div>
      );
    });
  };

  const tagClick = (e) => {
    const filterTags = tags.filter(function (data) {
      return data !== e;
    });

    let metalTags = localStorage.getItem("metalData");
    if (metalTags != null) {
      let metalData = localStorage.getItem("metalData").split(",");
      const metalDataIndex = metalData.findIndex((item) => item == e);
      if (metalDataIndex !== -1) {
        metalData.splice(metalDataIndex, 1);
      }
      localStorage.setItem(filterPage+"metalData", metalData);
    }

    let dupFilterTags = filterTags.filter(
      (v, i, a) => a.findIndex((t) => t === v) === i
    );
    const stoneIndex = stoneShape.findIndex((item) => item == e);
    if (stoneIndex !== -1) {
      stoneShape.splice(stoneIndex, 1);
    }
    if (stoneShape.length == 0) {
      localStorage.setItem(filterPage+"-stoneshape", "");
    }
    setStoneShape(stoneShape);
    const backTypeIndex = backType.findIndex((item) => item == e);

    if (backTypeIndex !== -1) {
      backType.splice(backTypeIndex, 1);
    }
    if (backType.length == 0) {
      localStorage.setItem(filterPage+"-backtype", "");
    }
    setBackType(backType);

    const hoopSizesIndex = hoopSizes.findIndex((item) => item == e);
    if (hoopSizesIndex !== -1) {
      hoopSizes.splice(hoopSizesIndex, 1);
    }
    if (hoopSizes.length == 0) {
      localStorage.setItem(filterPage+"-hoopsizes", "");
    }

    setHoopSizes(hoopSizes);

    const hoopProngsIndex = hoopProngs.findIndex((item) => item == e);
    if (hoopProngsIndex !== -1) {
      hoopProngs.splice(hoopProngsIndex, 1);
    }
    if (hoopProngs.length == 0) {
      localStorage.setItem(filterPage+"-hoopprongs", "");
    }
    setHoopProngs(hoopProngs);

    const selectedMetalIndex = selectedMetal.findIndex((item) => item == e);
    if (selectedMetalIndex !== -1) {
      selectedMetal.splice(selectedMetalIndex, 1);
    }
    setSelectedMetal(selectedMetal);

    setTags(dupFilterTags);
  };

  // Pagination
  const pagination = async () => {
    setLoadMore((prev) => {
      return prev + 1;
    });
    const next = loadMore + 1;

    await api
      .get(
        `hoops/hoopsFilter?pageNumber=${loadMore}&numberRecord=20${finHoopSizes}${finHoopProngs}${caratValue}${finStoneShape}${finBackType}&${sort}&minPrice=${
          ranges?.min !== undefined ? ranges?.min : 0
        }&maxPrice=${ranges?.max !== undefined ? ranges?.max : 0}`
      )
      .then((res) => {
        const data = res.data.data.Hoops;
        setfinalValue((prevState) => [...prevState, ...data]);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const setSorting = (e) => {
    setSort(e);
    setLoadMore(1);
  };

  return (
    <Listing>
      <div className="banner">
        <Container>
          <Row className="align-items-center">
            <h1>Valentine</h1>
            <Col md={6}>
              <h2>Valentine Special Gift Guide </h2>
            </Col>
            <Col md={6}>
              <h4>
                Fall in love with this hand-selected collection of luxurious lab
                created diamond jewelry
              </h4>
            </Col>
          </Row>
        </Container>
      </div>

      <div className="filters">
        <Container>
          <div className="d-flex align-items-center">
            <CustomFilters
              hoops
              minMax={minMax}
              setMinMax={setMinMax}
              selectedMetal={selectedMetal}
              setSelectedMetal={setSelectedMetal}
              setValues={setValues}
              setTags={setTags}
              tags={tags}
              values={values}
              stoneShape={stoneShape}
              setStoneShape={setStoneShape}
              hoopSizes={hoopSizes}
              setHoopSizes={setHoopSizes}
              hoopProngs={hoopProngs}
              setHoopProngs={setHoopProngs}
              backType={backType}
              setBackType={setBackType}
              finalMetal={finalMetal}
              setFinalMetal={setFinalMetal}
              setFinalValueRange={setFinalValueRange}
              finalValueRange={finalValueRange}
              setFiltersvalues={setFiltersvalues}
              filtersvalues={filtersvalues}
              filterPage={filterPage}
            />
            <div className="ban">
              <img className="img-fluid" src={`${Banner}`} alt="" />
            </div>
          </div>
          <div class="sorting-wrap">
            <div className="sorting d-flex justify-content-end align-items-center">
              <select value={sort} onChange={(e) => setSorting(e.target.value)}>
                <option value={"sort=1"}>Price: Low to High</option>
                <option value={"sort=-1"}>Price: High to Low</option>
              </select>
            </div>
            <div class="sorting-tags">
              {tags.map((val) => (
                <button onClick={() => tagClick(val)}>{val}</button>
              ))}
            </div>
            <div className="d-grid productListing">{images()}</div>
            {totalPages !== loadMore && (
              <div className="show-more">
                <CustomButton onClick={pagination} cursive>
                  Show More
                </CustomButton>
              </div>
            )}
          </div>
        </Container>
      </div>
      <GiftCard />
      <div className="recentView">
        <Container>
          <Recent />
        </Container>
      </div>
    </Listing>
  );
};

export default HoopsListing;
