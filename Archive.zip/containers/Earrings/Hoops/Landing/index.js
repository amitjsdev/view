import React from "react";
import { Container } from "reactstrap";
import { Link,useLocation } from "react-router-dom";

//css
import { Hoops } from "../../../../css/hoops";
import { CustomButton } from "../../../../css/global";
//images
import Size1 from "../../../../assets/images/hoops/landing/hoopsize1.png";
import Size2 from "../../../../assets/images/hoops/landing/hoopsize2.png";
import Size3 from "../../../../assets/images/hoops/landing/hoopsize3.png";
import Size4 from "../../../../assets/images/hoops/landing/hoopsize4.png";
import Dummy from "../../../../assets/images/hoops/landing/dummy1.png";

import Recent from "../../../../components/RecentView";
import Newsletter from "../../../../components/Newsletter";
import GiftCard from "../../../../components/Gift";

const HoopsLanding = () => {
  const pathname  = useLocation().pathname.replace(/[^a-zA-Z ]/g,'');
  const handliStartPrice = (e) => {
    localStorage.setItem("hoopsPrice", e);
  };

  return (
    <Hoops>
      <div className="banner">
        <Container className="position-relative">
          <div className="bantext">
            <h1>Valentine</h1>
            <h2>Valentine Special Gift Guide</h2>
            <p>
              Fall in love with this hand-selected collection of luxurious lab
              created diamond jewelry
            </p>
            <Link to={`/hoops/listing?filterPage=${pathname}`}>
              <CustomButton cursive className="customButton">
                Shop now
              </CustomButton>
            </Link>
          </div>
        </Container>
      </div>

      <div className="hoopSize">
        <Container>
          <div className="d-flex align-items-center">
            <div className="left">
              <div className="image">
                <span>
                  <img className="img-fluid" src={`${Size1}`} alt="" />
                  <h2>Diamond eternity Hoops</h2>
                </span>
              </div>
            </div>
            <div className="right">
              <div className="products">
                <span>
                  <img className="img-fluid" src={`${Dummy}`} alt="" />
                </span>
                <span>
                  <img className="img-fluid" src={`${Dummy}`} alt="" />
                </span>
              </div>
              <Link to={`/hoops/listing?filterPage=${pathname}`}>
                <CustomButton
                  onClick={() => handliStartPrice(900)}
                  cursive
                  className="customButton"
                >
                  Starting From $900
                </CustomButton>
              </Link>
            </div>
          </div>
          <div className="d-flex align-items-center flex-row-reverse">
            <div className="left">
              <div className="image">
                <span>
                  <img className="img-fluid" src={`${Size2}`} alt="" />
                  <h2>Channel set huggie hoops</h2>
                </span>
              </div>
            </div>
            <div className="right">
              <div className="products">
                <span>
                  <img className="img-fluid" src={`${Dummy}`} alt="" />
                </span>
                <span>
                  <img className="img-fluid" src={`${Dummy}`} alt="" />
                </span>
              </div>
              <Link to={`/hoops/listing?filterPage=${pathname}`}>
                <CustomButton
                  onClick={() => handliStartPrice(600)}
                  cursive
                  className="customButton"
                >
                  Starting From $600
                </CustomButton>
              </Link>
            </div>
          </div>
          <div className="d-flex align-items-center">
            <div className="left">
              <div className="image">
                <span>
                  <img className="img-fluid" src={`${Size3}`} alt="" />
                  <h2>Diamond Hoop</h2>
                </span>
              </div>
            </div>
            <div className="right">
              <div className="products">
                <span>
                  <img className="img-fluid" src={`${Dummy}`} alt="" />
                </span>
                <span>
                  <img className="img-fluid" src={`${Dummy}`} alt="" />
                </span>
              </div>
              <Link to={`/hoops/listing?filterPage=${pathname}`}>
                <CustomButton
                  onClick={() => handliStartPrice(900)}
                  cursive
                  className="customButton"
                >
                  Starting From $900
                </CustomButton>
              </Link>
            </div>
          </div>
          <div className="d-flex align-items-center flex-row-reverse">
            <div className="left">
              <div className="image">
                <span>
                  <img className="img-fluid" src={`${Size4}`} alt="" />
                  <h2>Patite Diamond huggies hoops</h2>
                </span>
              </div>
            </div>
            <div className="right">
              <div className="products">
                <span>
                  <img className="img-fluid" src={`${Dummy}`} alt="" />
                </span>
                <span>
                  <img className="img-fluid" src={`${Dummy}`} alt="" />
                </span>
              </div>
              <Link to={`/hoops/listing?filterPage=${pathname}`}>
                <CustomButton
                  onClick={() => handliStartPrice(800)}
                  cursive
                  className="customButton"
                >
                  Starting From $800
                </CustomButton>
              </Link>
            </div>
          </div>
          <div className="d-flex align-items-center">
            <div className="left">
              <div className="image">
                <span>
                  <img className="img-fluid" src={`${Size3}`} alt="" />
                  <h2>Long Diamond Hoops</h2>
                </span>
              </div>
            </div>
            <div className="right">
              <div className="products">
                <span>
                  <img className="img-fluid" src={`${Dummy}`} alt="" />
                </span>
                <span>
                  <img className="img-fluid" src={`${Dummy}`} alt="" />
                </span>
              </div>
              <Link to={`/hoops/listing?filterPage=${pathname}`}>
                <CustomButton
                  onClick={() => handliStartPrice(700)}
                  cursive
                  className="customButton"
                >
                  Starting From $700
                </CustomButton>
              </Link>
            </div>
          </div>
        </Container>
      </div>
      <GiftCard />

      <div className="recentView">
        <Container>
          <Recent />
        </Container>
      </div>

      <Container className="text-center">
        <Newsletter />
      </Container>
    </Hoops>
  );
};

export default HoopsLanding;
