import React, {
  useState,
  useEffect,
  useRef,
  useContext,
  useLayoutEffect,
} from "react";
import APIUtil from "../../../../api";
import { useParams } from "react-router-dom";
import Slider from "../../../../components/SimilarSlider";
import { Tooltip } from "@material-ui/core";
import {
  Carousel,
  CarouselItem,
  CarouselControl,
  Container,
  Row,
  Col,
} from "reactstrap";
import { CartContext } from "../../../../context/CartContext";
import { Authentication, UserDetails, metalColors } from "../../../../constant";

//images
import { ReactComponent as Cart } from "../../../../assets/images/addcart.svg";
import { ReactComponent as Wishlist } from "../../../../assets/images/addwishlist.svg";
import { ReactComponent as EmailUs } from "../../../../assets/images/emailus.svg";
import { ReactComponent as Help } from "../../../../assets/images/help.svg";
import DetailImg from "../../../../assets/images/detail/studDetail.png";
import LuxuryGift from "../../../../assets/images/detail/ring.png";
import Client from "../../../../assets/images/detail/client.png";
import Rating from "../../../../assets/images/detail/rating.svg";

import { ReactComponent as Truck } from "../../../../assets/images/shippingTruck.svg";
//css
import { CustomButton } from "../../../../css/global";
import { ProductDetail } from "../../../../css/productDetail";
import USP from "../../../../components/USP";

const api = new APIUtil();

const ProductDetailPage = (props) => {
  const {
    addProduct,
    wishProduct,
    wishListId,
    wishListIdDel,
    cartListIdDel,
    cartListId,
  } = useContext(CartContext);
  const isCancelled = useRef(true);
  const userId = UserDetails();
  var isAuth = Authentication();
  const imgRef = useRef();
  const { id, metalWeight, metal } = useParams();

  var value;

  const [productDetails, setProductDetails] = useState({});
  const [images, setImages] = useState([]);
  const [activeIndex, setActiveIndex] = useState(0);
  const [animating, setAnimating] = useState(false);
  const [activeTab, setActiveTab] = useState("1");
  const [load, setLoad] = useState(true);
  const [similar, setSimilar] = useState([]);

  // 14 Carat filter state
  const [metalColor, setMetalColor] = useState(metalColors);

  // 18 Carat filter state
  const [noFilter, setNoFilter] = useState(false);

  const [metalValue, setMetalValue] = useState();
  const [dimension, setDimensions] = useState({ height: null, width: null });

  // To fetch product information form database
  const data = async () => {
    await api.get(`fashion/fashionDetails?productId=${id}`).then((res) => {
      const data = res.data.data;
      console.log(data);
      setProductDetails(data);
      setImages(data.images.fashionImages);
      const metalWithCarat = data.metalWithCarat.split(" ");

      api
        .get(
          `fashion/fashionDetails?searchParam={diamondWeight:${
            data.diamondWeight?.$numberDecimal
          },metal:${`'${data.metal}'`},metalCarat:${
            data.metal == "platinum" ? "0" : metalWithCarat[1]
          }}`
        )
        .then((res) => {
          setNoFilter(true);
        });
    });
  };

  // To active the filter according to selected product from the URL for metal only
  const metalColorSelector = () => {
    const data = metalColor.map((val, i) => {
      function capitalizeFirstLetter(string) {
        return string.charAt(0).toLowerCase() + string.slice(1);
      }
      const lower = capitalizeFirstLetter(metal);
      const matchParam = lower + "-" + metalWeight;

      if (val.value === matchParam) {
        val["clicked"] = true;
        return val;
      } else {
        return {
          ...val,
          clicked: false,
        };
      }
    });

    setMetalColor(data);
  };

  // to check the product is already in cart or not
  const isInCart = (id) => {
    if (isAuth) {
      if (cartListId.includes(id)) {
        return true;
      } else {
        return false;
      }
    }
  };

  // To check product is already in wishlist or not
  const isInWish = (id) => {
    if (isAuth) {
      if (wishListId.includes(id)) {
        return true;
      } else {
        return false;
      }
    }
  };

  // To add product in add to cart
  const addToCart = async (price, id, category) => {
    if (isAuth) {
      const body = {
        userId: userId._id.toString(),
        quantity: 1,
        price: price,
        productCategory: category,
        productId: id,
      };

      await api.post("products/addCart", body).then((response) => {});
      setLoad(!load);
      props.history.push("/addtocart");
    }
  };

  // To add product in wishList
  const toWishClick = async (id, category) => {
    if (isAuth) {
      const body = [
        {
          userId: userId._id.toString(),
          productId: id,
          productCategory: category,
        },
      ];

      await api.post("products/addWishlist", body).then((response) => {});
      setLoad(!load);
    }
  };

  useEffect(() => {
    if (isAuth) {
      addProduct(userId._id.toString());
      wishProduct(userId._id.toString());
    }
  }, [load]);

  useEffect(() => {
    if (isCancelled.current) {
      data();
      similarStudsdata();
    } else {
      selectedMetal();
    }

    return () => {
      isCancelled.current = false;
    };
  }, []);

  useLayoutEffect(() => {
    metalColorSelector();
  }, []);

  const toggle = (tab) => {
    if (activeTab !== tab) setActiveTab(tab);
  };

  const next = () => {
    if (animating) return;
    const nextIndex = activeIndex === images.length - 1 ? 0 : activeIndex + 1;
    setActiveIndex(nextIndex);
  };

  const previous = () => {
    if (animating) return;
    const nextIndex = activeIndex === 0 ? images.length - 1 : activeIndex - 1;
    setActiveIndex(nextIndex);
  };

  const goToIndex = (newIndex) => {
    if (animating) return;
    setActiveIndex(newIndex);
  };

  const similarStudsdata = async () => {
    await api.get(`studs/similarStuds`).then((res) => {
      const data = res.data.data;
      setSimilar(data);
    });
  };

  const click = (redirect) => {};

  const imgDimension = () => {
    setTimeout(() => {
      const currentHeight = imgRef.current.offsetHeight;
      const currentWidth = imgRef.current.offsetWidth;
    }, 1);
  };

  // Image slider
  const imageSlides = images.map((item, index) => {
    return (
      <CarouselItem
        onExiting={() => setAnimating(true)}
        onExited={() => setAnimating(false)}
        key={index}
      >
        <img
          src={item}
          className="test"
          ref={imgRef}
          // onLoad={imgDimension}
          alt=""
        />
      </CarouselItem>
    );
  });
  // Image slider

  // 14K and 18k metal color filters. It will update url and http request both
  const metalColorButton = () => {
    return metalColor.map((val, index) => {
      return (
        <button
          onClick={(e) => selectedMetal(e, "value")}
          key={index}
          id={val.id}
          className={`${
            val.clicked ? `${val.className} active` : val.className
          }`}
          value={val.value}
        ></button>
      );
    });
  };

  const selectedMetal = (e) => {
    value = e.target.getAttribute("value");
    const finalValue = value.split("-");
    const colorValue = finalValue[0];
    const metalValue = finalValue[1];
    function capitalizeFirstLetter(string) {
      return string.charAt(0).toUpperCase() + string.slice(1);
    }
    const colorval = capitalizeFirstLetter(colorValue);

    const updateValues = metalColor.map((val) => {
      if (val.value === value) {
        val["clicked"] = true;
        return val;
      } else {
        return {
          ...val,
          clicked: false,
        };
      }
    });
    setMetalColor(updateValues);

    // To set metal carat eg. 14,18,0(platinum) in url and http request
    const metalCaratValue = () => {
      return value === "platinum" ? "0" : metalValue;
    };
    // ,settingType:${`'${data.diamondInformation.settingType}'`}
    api
      .get(
        `fashion/fashionDetails?searchParam={diamondWeight:${
          productDetails.diamondWeight?.$numberDecimal
        },metal:${`'${colorval}'`},metalCarat:${metalCaratValue()}}`
      )
      .then((res) => {
        const otherProductData = res.data.data;
        setProductDetails(otherProductData);
        setImages(otherProductData.images.hoopsImages);
        const productyId = otherProductData._id;
        const metals = `${colorValue}`;
        props.history.push(
          `/productDetail/${productyId}/${metalCaratValue()}/${metals}`
        );
      });
  };
  // 14K metal color filters

  // To remove the product from wishlist
  const wishListRemove = async (id, category) => {
    if (isAuth) {
      const del_data = {
        userId: userId._id.toString(),
        productId: id,
      };

      await api.post("products/delWishlist", del_data).then((response) => {
        if (wishListId.includes(id)) {
          const filter = wishListId.filter(function (data) {
            return data !== id;
          });
          setLoad(!load);

          wishListIdDel(filter);
        }
      });
    }
  };

  // To Remove the product for cart
  const removeFromCart = async (id, category) => {
    if (isAuth) {
      const del_data = {
        userId: userId._id.toString(),
        productId: id,
      };

      await api.post("products/delCart", del_data).then((response) => {
        if (cartListId.includes(id)) {
          const filter = cartListId.filter(function (data) {
            return data !== id;
          });
          setLoad(!load);
          cartListIdDel(filter);
        }
      });
      setLoad(!load);
    }
  };

  // BankWire price Calculation
  const bankWire = () => {
    const totalPrice = productDetails.totalPrice?.$numberDecimal;
    const bankwireDiscount = 1.5 / 100;
    const finalBankWirePrice = totalPrice - totalPrice * bankwireDiscount;
    return finalBankWirePrice.toFixed(2);
  };

  return (
    <ProductDetail>
      <Container>
        <div className="product-card">
          <div className="product-details">
            <h2>{productDetails.name}</h2>

            {/* <h3 ref={imgRef}>({productDetails.diamondWeight} ct. tw.)</h3> */}
            <div className="selected-filter pt-3 d-flex align-items-center justify-content-end">
              <div className="d-flex">
                <label>Color - </label>
                <b>
                  <em>
                    {productDetails.diamondInformation !== undefined
                      ? `${productDetails.diamondInformation.avgColor}`
                      : ""}
                  </em>
                </b>
              </div>
              <div className="d-flex">
                <label>Clarity - </label>
                <b>
                  <em>
                    {productDetails.diamondInformation !== undefined
                      ? `${productDetails.diamondInformation.avgClarity}`
                      : ""}
                  </em>
                </b>
              </div>
            </div>
            <div className="earringInfo">
              <Container>
                <Row>
                  <Col xs="6">Stock Number</Col>
                  <Col xs="6" className="p-0">
                    {productDetails.suk}
                  </Col>
                </Row>
                <Row>
                  <Col xs="6">Metal</Col>
                  <Col xs="6" className="p-0">
                    {productDetails?.metalInformation?.metalCarat}K{" "}
                    {productDetails.metal} Gold
                  </Col>
                </Row>
                <Row>
                  <Col xs="6">Backing</Col>
                  <Col xs="6" className="p-0">
                    {productDetails.backType}
                  </Col>
                </Row>
                <Row>
                  <Col xs="6">Rhodium Plated</Col>
                  <Col xs="6" className="p-0">
                    {productDetails.rhodiumFinish}
                  </Col>
                </Row>
                <Row>
                  <Col xs="6">Width</Col>
                  <Col xs="6" className="p-0">
                    {productDetails.width}
                  </Col>
                </Row>
                <Row>
                  <Col xs="6">Diameter</Col>
                  <Col xs="6" className="p-0">
                    {productDetails.diameter}
                  </Col>
                </Row>
              </Container>
            </div>
            {/* <div className="earringInfo desc">
                <p>
                  Great product title for a great product and all of the extra
                  things a product might need to make it fill an entire card.
                </p>
              </div> */}
            <div className="shippingInfo position-relative d-flex align-items-center">
              <p>Get Free ship by 21 Aug, If ordered Before 10:30 PM </p>
              <Truck width="165px" height="45px" />
            </div>
          </div>
          <div className="product-image">
            <Carousel activeIndex={activeIndex} next={next} previous={previous}>
              {imageSlides}
              <CarouselControl
                direction="prev"
                directionText="Previous"
                onClickHandler={previous}
              />
              <CarouselControl
                direction="next"
                directionText="Next"
                onClickHandler={next}
              />
            </Carousel>
          </div>
          <div className="product-choices product-details">
            <div className={`product-color-choices ${noFilter && "not"}`}>
              <h2>Metal</h2>
              {metalColorButton()}
            </div>
            <div className="product-price">
              {productDetails.status !== 2 ? (
                <h3 className="product-price-original">
                  ${productDetails.totalPrice?.$numberDecimal}
                </h3>
              ) : (
                <h3 className="product-price-original">Out of Stock</h3>
              )}
              {productDetails.status !== 2 ? (
                <>
                  <h5>Get 1.5% off with bankwire - ${bankWire()}</h5>
                  <h5>
                    Welcome offer on first purchase, use <span>WELCOME21</span>{" "}
                    code{" "}
                  </h5>
                </>
              ) : (
                ""
              )}
            </div>
            <div className="d-flex justify-content-between">
              {isInWish(productDetails._id) && (
                <CustomButton
                  dark
                  onClick={() =>
                    wishListRemove(
                      productDetails._id,
                      productDetails.productCategory
                    )
                  }
                  className="customButton black"
                >
                  <Wishlist width="19px" height="19px" fill="#ff5000" />
                </CustomButton>
              )}
              {!isInWish(productDetails._id) && (
                <Tooltip title={isAuth ? "" : "Login First "}>
                  <CustomButton
                    dark
                    onClick={() =>
                      toWishClick(
                        productDetails._id,
                        productDetails.productCategory
                      )
                    }
                    className="customButton black"
                  >
                    <Wishlist width="19px" height="19px" fill="#fff" />
                  </CustomButton>
                </Tooltip>
              )}

              {isInCart(productDetails._id) && (
                <CustomButton
                  dark
                  onClick={() =>
                    removeFromCart(
                      productDetails._id,
                      productDetails.productCategory
                    )
                  }
                  className="customButton cart black"
                >
                  <Cart width="25px" height="21px" fill="#fff" /> Remove From
                  Cart
                </CustomButton>
              )}
              {productDetails.status !== 2 ? (
                !isInCart(productDetails._id) && (
                  <Tooltip title={isAuth ? "" : "Login First "}>
                    <CustomButton
                      dark
                      className="customButton cart black"
                      onClick={() =>
                        addToCart(
                          productDetails.totalPrice?.$numberDecimal,
                          productDetails._id,
                          productDetails.productCategory
                        )
                      }
                    >
                      <Cart width="25px" height="21px" fill="#fff" /> Add to
                      cart
                    </CustomButton>
                  </Tooltip>
                )
              ) : (
                <CustomButton dark className="customButton cart black">
                  Out of Stock
                </CustomButton>
              )}
            </div>
            <div className="helpUs">
              <ul className="list d-flex justify-content-start">
                <li>
                  <a href="mailto:info@radixdiamond.co">
                    <EmailUs width="20px" height="15px" />
                    <p> Email Us</p>
                  </a>
                </li>
                <li>
                  <a href="tel:+1-800-242-2728">
                    <h4>
                      <Help width="19px" height="19px" /> Need Help ?
                    </h4>
                    <p>+1-800-242-2728</p>
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </Container>
      <Container>
        <div className="productDetail">
          <span>
            <img src={`${DetailImg}`} alt="" />
          </span>
          <div className="detailInfo">
            <h3>Diamond Details</h3>
            <ul className="list">
              <li className="d-flex">
                <h4>Number of Center Round Diamonds</h4>
                <p>{productDetails.noOfDiamonds}</p>
              </li>
              <li className="d-flex">
                <h4>Minimum Carat Total Weight (ct. tw.)</h4>
                <p>{productDetails.diamondWeight?.$numberDecimal}</p>
              </li>
              <li className="d-flex">
                <h4>Enhancement</h4>
                <p>Not Enhanced</p>
              </li>
              <li className="d-flex">
                <h4>Minimum Color</h4>
                <p>
                  {productDetails.diamondInformation !== undefined
                    ? productDetails.diamondInformation.minColor
                    : ""}
                </p>
              </li>
              <li className="d-flex">
                <h4>Minimum Clarity</h4>
                <p>
                  {productDetails.diamondInformation !== undefined
                    ? productDetails.diamondInformation.minClarity
                    : ""}
                </p>
              </li>
              <li className="d-flex">
                <h4>Minimum Cut</h4>
                <p>Good</p>
              </li>
              <li className="d-flex">
                <h4>Setting Type</h4>
                <p>
                  {" "}
                  {productDetails.diamondInformation !== undefined
                    ? productDetails.diamondInformation.settingType
                    : ""}
                </p>
              </li>
            </ul>
          </div>
          <div className="detailInfo">
            <h3>Earring Details</h3>
            <ul className="list">
              <li className="d-flex">
                <h4>Stock Number</h4>
                <p>{productDetails.suk}</p>
              </li>
              <li className="d-flex">
                <h4>Metal</h4>
                <p>{productDetails.metal}</p>
              </li>
              <li className="d-flex">
                <h4>Diameter</h4>
                <p>{productDetails.diameter}</p>
              </li>

              <li className="d-flex">
                <h4>Width</h4>
                <p>{productDetails.width}</p>
              </li>
              <li className="d-flex">
                <h4>Backing</h4>
                <p>{productDetails.backType}</p>
              </li>
              <li className="d-flex">
                <h4>Rhodium Plated</h4>
                <p>{productDetails.rhodiumFinish}</p>
              </li>
            </ul>
          </div>
        </div>
      </Container>
      {/* <div className="luxury">
            <Container>
              <div className="left">
                <h2>
                  <span>F</span>eel Luxury
                </h2>
                <p>
                  Radix Provides you a Real Luxury Experience For Special Family
                  members just like you and makes Purchase for specials and more
                  Royal.
                </p>
              </div>
              <div className="right">
                <span>
                  <img src={`${LuxuryGift}`} alt="" />{" "}
                </span>
              </div>
            </Container>
          </div> */}
      <USP />
      <section className="feel-luxury">
        <Container>
          <div className="feel-luxury-inner">
            <div className="feel-luxury-caption">
              <h2>
                <span>F</span>eel Luxury
              </h2>
              <p>
                Radix Provides you a Real Luxury Experience For Special Family
                members just like you and makes Purchase for specials and more
                Royal{" "}
              </p>
            </div>

            <div className="feel-luxury-img">
              <img className="img-fluid" src={`${LuxuryGift}`} alt="" />
            </div>
          </div>
        </Container>
      </section>
      <section className="testimonials">
        <div className="container">
          <div className="testimonial-heading">
            <h2>
              <span>T</span>estmonial's
            </h2>
          </div>

          <div className="testimonial-container">
            <div className="testimonial-img">
              <img src={`${Client}`} alt="" />
            </div>

            <div className="testimonial-caption">
              <span className="client-name">Linda Syoeo</span>
              <div className="rating">
                <a href="">
                  <img src={`${Rating}`} alt="" />
                </a>
                <a href="">
                  <img src={`${Rating}`} alt="" />
                </a>
                <a href="">
                  <img src={`${Rating}`} alt="" />
                </a>
                <a href="">
                  <img src={`${Rating}`} alt="" />
                </a>
                <a href="">
                  <img src={`${Rating}`} alt="" />
                </a>
              </div>

              <blockquote>
                One best site to buy Diamonds jewellry online
              </blockquote>
            </div>
          </div>
        </div>
      </section>

      <div className="similar text-center">
        <Container>
          <h2>
            <span>S</span>imilar <br /> <b>Items</b>
          </h2>
          <Slider data={similar} onClick={click} />
        </Container>
      </div>
    </ProductDetail>
  );
};

export default ProductDetailPage;
