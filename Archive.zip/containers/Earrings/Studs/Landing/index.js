import React, { useEffect, useState } from "react";
import {
  Carousel,
  CarouselItem,
  CarouselControl,
  CarouselIndicators,
  Container,
  Row,
  Col,
} from "reactstrap";
import APIUtil from "../../../../api";
import { useHistory } from "react-router-dom";
import { Colors, Clarities } from "../../../../constant";

//css
import { EarringLanding } from "../../../../css/earringLanding";
import { Listing } from "../../../../css/hoops";
import { CustomButton } from "../../../../css/global";

//images
import Diamond from "../../../../assets/images/model/big-diamond.png";

const api = new APIUtil();

const Earring = (props) => {
  const history = useHistory();
  var finalValue;

  // States
  const [products, setProducts] = useState([]);
  const [color, setColor] = useState("D");
  const [clarity, setClarity] = useState("FL");
  const [activeColor, setActiveColor] = useState(Colors);
  const [activeClarity, setActiveClarity] = useState(Clarities);
  const [productImage, setProductImage] = useState([]);
  const [animating, setAnimating] = useState(false);
  const [activeIndex, setActiveIndex] = useState(0);
  const [load, setLoad] = useState(false);
  const [products4, setProducts4] = useState([]);
  const [color4, setColor4] = useState("D");
  const [clarity4, setClarity4] = useState("IF");
  const [activeColor4, setActiveColor4] = useState(Colors);
  const [activeClarity4, setActiveClarity4] = useState(Clarities);

  const data = async () => {
    await api
      .get(
        `studs/studsLanding?color=${color}&clarity=${clarity}&settingType=3 Prong`
      )
      .then((res) => {
        const data = res.data.data;
        data.sort((a, b) =>
          a.diamondWeight?.$numberDecimal.localeCompare(
            b.diamondWeight?.$numberDecimal
          )
        );
        setProducts(data);
      });
  };

  const fourProngsData = async () => {
    await api
      .get(
        `studs/studsLanding?color=${color4}&clarity=${clarity4}&settingType=4 Prong`
      )
      .then((res) => {
        const data = res.data.data;
        data.sort((c, d) =>
          c.diamondWeight?.$numberDecimal.localeCompare(
            d.diamondWeight?.$numberDecimal
          )
        );
        setProducts4(data);
      });
  };

  // Loading data at initial load
  useEffect(() => {
    data();
  }, [color, clarity]);

  useEffect(() => {
    fourProngsData();
  }, [color4, clarity4]);

  const redirectPath = (id) => {
    history.push({
      pathname: `/productDetail/${id._id}/${id.metalCarat}/${id.metal}/${id.diamondWeight?.$numberDecimal}`,
      setLoad: setLoad,
      load: load,
    });
  };

  // Next slide
  const next = () => {
    if (animating) return;
    const nextIndex =
      activeIndex === productImage.length - 1 ? 0 : activeIndex + 1;
    setActiveIndex(nextIndex);
  };

  // Pre slide
  const previous = () => {
    if (animating) return;
    const nextIndex =
      activeIndex === 0 ? productImage.length - 1 : activeIndex - 1;
    setActiveIndex(nextIndex);
  };

  // Selected index for slider
  const goToIndex = (newIndex) => {
    if (animating) return;
    setActiveIndex(newIndex);
  };

  // Dynamic product images
  const imageSlides = productImage.map((item, index) => {
    return (
      <CarouselItem
        onExiting={() => setAnimating(true)}
        onExited={() => setAnimating(false)}
        key={index}
      >
        <img src={item} alt="" />
      </CarouselItem>
    );
  });

  // Color Hover
  const colorHover = (e, value, setting) => {
    value = e.target.getAttribute("value");
    finalValue = value.split("-")[0];
    const updateColor = activeColor.map((item) => {
      if (item.name == value) {
        return {
          ...item,
          clicked: true,
        };
      } else {
        return {
          ...item,
          clicked: false,
        };
      }
    });
    if (setting == "3 Prongs") {
      setActiveColor(updateColor);
      setColor(finalValue);
    } else if (setting == "4 Prongs") {
      setActiveColor4(updateColor);
      setColor4(finalValue);
    }
  };

  // Clarity Hover
  const clarityHover = (e, value, setting) => {
    value = e.target.getAttribute("value");
    finalValue = value.split("-")[0];
    const updateClarity = activeClarity.map((item) => {
      if (item.name == value) {
        return {
          ...item,
          clicked: true,
        };
      } else {
        return {
          ...item,
          clicked: false,
        };
      }
    });
    if (setting == "3 Prongs") {
      setActiveClarity(updateClarity);
      setClarity(finalValue);
    } else if (setting == "4 Prongs") {
      setActiveClarity4(updateClarity);
      setClarity4(finalValue);
    }
  };

  // Color filters
  const colorItems = (setting) => {
    switch (setting) {
      case "3 Prongs":
        return activeColor.map((item, index) => {
          return (
            <li
              onMouseEnter={(e) => colorHover(e, "value", setting)}
              className={item.clicked ? "active" : ""}
              value={item.value}
              name={item.name}
              key={index}
            >
              {item.color}
            </li>
          );
        });
      case "4 Prongs":
        return activeColor4.map((item, index) => {
          return (
            <li
              onMouseEnter={(e) => colorHover(e, "value", setting)}
              className={item.clicked ? "active" : ""}
              value={item.value}
              name={item.name}
              key={index}
            >
              {item.color}
            </li>
          );
        });
      default:
    }
  };

  // Clarity filters
  const clarityItems = (setting) => {
    switch (setting) {
      case "3 Prongs":
        return activeClarity.map((item, index) => {
          return (
            <li
              onMouseEnter={(e) => clarityHover(e, "value", setting)}
              className={item.clicked ? "active" : ""}
              value={item.value}
              name={item.name}
              key={index}
            >
              {item.clarity}
            </li>
          );
        });
      case "4 Prongs":
        return activeClarity4.map((item, index) => {
          return (
            <li
              onMouseEnter={(e) => clarityHover(e, "value", setting)}
              className={item.clicked ? "active" : ""}
              value={item.value}
              name={item.name}
              key={index}
            >
              {item.clarity}
            </li>
          );
        });
      default:
    }
  };

  return (
    <EarringLanding>
      <Listing>
        <div className="banner">
          <Container>
            <Row className="align-items-center">
              <h1>Valentine</h1>
              <Col md={6}>
                <h2>Valentine Special Gift Guide </h2>
              </Col>
              <Col md={6}>
                <h4>
                  Fall in love with this hand-selected collection of luxurious
                  lab created diamond jewelry
                </h4>
              </Col>
            </Row>
          </Container>
        </div>
      </Listing>
      <div className="ProductCategories d-flex align-items-stretch">
        <div className="col-md-3 px-0">
          <div className="left h-100 d-flex">
            <div className="image"></div>
          </div>
        </div>
        <div className="col-md-9 px-5">
          <div className="right">
            <div className="mainslider">
              <div className="heading">
                <h2>Three Prong stud Earrings</h2>
              </div>
            </div>
            <div className="d-flex justify-content-between w-100">
              <div className="slider">
                <Carousel
                  activeIndex={activeIndex}
                  next={next}
                  previous={previous}
                >
                  <CarouselIndicators
                    items={productImage}
                    activeIndex={activeIndex}
                    onClickHandler={goToIndex}
                  />
                  {imageSlides}
                  <CarouselControl
                    direction="prev"
                    directionText="Previous"
                    onClickHandler={previous}
                  />
                  <CarouselControl
                    direction="next"
                    directionText="Next"
                    onClickHandler={next}
                  />
                </Carousel>
              </div>
              <div className="d-flex flex-column align-items-end">
                <div className="filters">
                  <h3>Color</h3>
                  <ul className="list d-flex justify-content-center">
                    {colorItems("3 Prongs")}
                  </ul>
                </div>
                <div className="filters">
                  <h3>Clarity</h3>
                  <ul className="list d-flex justify-content-center">
                    {clarityItems("3 Prongs")}
                  </ul>
                </div>
              </div>
            </div>
            <div className="productListing">
              <ul className="productlist">
                {products.map((val, index) => {
                  return (
                    <li key={index} className={`diamond${index}`}>
                      <div
                        className="productWrap"
                        onClick={() => redirectPath(val)}
                      >
                        <span>
                          <img
                            className="img-fluid"
                            key={index}
                            width={`${Math.floor(20) + index * 5}px`}
                            src={`${Diamond}`}
                            alt=""
                          />
                        </span>
                        <h4>{val.diamondWeight?.$numberDecimal} CT</h4>
                        <span className="price">$ {val.price}</span>
                      </div>
                    </li>
                  );
                })}
              </ul>
            </div>
          </div>
        </div>
      </div>
      <div className="ProductCategories d-flex align-items-stretch flex-row-reverse">
        <div className="col-md-3 px-0">
          <div className="left h-100 d-flex flex-row-reverse">
            <div className="image"></div>
          </div>
        </div>
        <div className="col-md-9 px-5">
          <div className="right">
            <div className="mainslider">
              <div className="heading">
                <h2>Four Prong stud Earrings</h2>
              </div>
            </div>
            <div className="d-flex justify-content-between w-100 flex-row-reverse">
              <div className="slider">
                <Carousel
                  activeIndex={activeIndex}
                  next={next}
                  previous={previous}
                >
                  <CarouselIndicators
                    items={productImage}
                    activeIndex={activeIndex}
                    onClickHandler={goToIndex}
                  />
                  {imageSlides}
                  <CarouselControl
                    direction="prev"
                    directionText="Previous"
                    onClickHandler={previous}
                  />
                  <CarouselControl
                    direction="next"
                    directionText="Next"
                    onClickHandler={next}
                  />
                </Carousel>
              </div>
              <div className="d-flex flex-column align-items-start">
                <div className="filters">
                  <h3>Color</h3>
                  <ul className="list d-flex justify-content-center">
                    {colorItems("4 Prongs")}
                  </ul>
                </div>
                <div className="filters">
                  <h3>Clarity</h3>
                  <ul className="list d-flex justify-content-center">
                    {clarityItems("4 Prongs")}
                  </ul>
                </div>
              </div>
            </div>
            <div className="productListing">
              <ul className="productlist">
                {products4.map((val, index) => {
                  return (
                    <li key={index} className={`diamond${index}`}>
                      <div
                        className="productWrap"
                        onClick={() => redirectPath(val)}
                      >
                        <span>
                          <img
                            className="img-fluid"
                            key={index}
                            width={`${Math.floor(20) + index * 5}px`}
                            src={`${Diamond}`}
                            alt=""
                          />
                        </span>
                        <h4>{val.diamondWeight?.$numberDecimal} CT</h4>
                        <span className="price">$ {val.price}</span>
                      </div>
                    </li>
                  );
                })}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </EarringLanding>
  );
};

export default Earring;
