import React from "react";
import { Col, Container, Row } from "reactstrap";
import CreateYourOwn from "../../../components/CreateYourOwn";
import Help from "../../../components/Help";
import Recent from "../../../components/RecentView";
import { Link } from "react-router-dom";
// css
import { CustomButton } from "../../../css/global";
import { LooseDiamondsWrap } from "../../../css/looseDiamonds";

//images
import { ReactComponent as Round } from "../../../assets/images/looseDiamonds/round.svg";
import { ReactComponent as Princess } from "../../../assets/images/looseDiamonds/princess.svg";
import { ReactComponent as Cushion } from "../../../assets/images/looseDiamonds/cushion.svg";
import { ReactComponent as Oval } from "../../../assets/images/looseDiamonds/oval.svg";
import { ReactComponent as Emerald } from "../../../assets/images/looseDiamonds/emerald.svg";
import { ReactComponent as Pear } from "../../../assets/images/looseDiamonds/pear.svg";
import { ReactComponent as Asscher } from "../../../assets/images/looseDiamonds/asscher.svg";
import { ReactComponent as Heart } from "../../../assets/images/looseDiamonds/heart.svg";
import { ReactComponent as Radiant } from "../../../assets/images/looseDiamonds/radiant.svg";
import { ReactComponent as Marquise } from "../../../assets/images/looseDiamonds/marquise.svg";
import { ReactComponent as Mail } from "../../../assets/images/home/mail.svg";
import { ReactComponent as Phone } from "../../../assets/images/home/phone.svg";
import { ReactComponent as Live } from "../../../assets/images/home/live-chat.svg";
import HowDiamond from "../../../assets/images/looseDiamonds/how-diamond.png";
import Learn1 from "../../../assets/images/looseDiamonds/learn1.png";
import Learn2 from "../../../assets/images/looseDiamonds/learn2.png";
import Learn3 from "../../../assets/images/looseDiamonds/learn3.png";

const LooseDiamonds = () => {
  return (
    <LooseDiamondsWrap>
      <div className="banner loose-diamond">
        <Container className="position-relative">
          <div className="bantext">
            <h1>Diamond</h1>
            <h2>Loose Diamond</h2>
            <p>
              Our Collection is Responsibly Sourced and offers Scintillating
              fire and Exceptional Quality
            </p>
            <Link to="/diamond-search">
              <CustomButton cursive className="customButton">
                Shop now
              </CustomButton>
            </Link>
          </div>
        </Container>
      </div>
      <div className="diamond-Category">
        <Container>
          <h2>
            <span>S</span>earch for Loose Diamonds
          </h2>
          <ul className="list d-flex align-items-center">
            <li>
              <Link to="/diamond-search">
                <Round width="65px" height="65px" />
                Round
              </Link>
            </li>
            <li>
              <Link to="/diamond-search">
                <Princess width="60px" height="60px" />
                Princess
              </Link>
            </li>
            <li>
              <Link to="/diamond-search">
                <Cushion width="57px" height="57px" />
                Cushion
              </Link>
            </li>
            <li>
              <Link to="/diamond-search">
                <Oval width="39px" height="59px" />
                Oval
              </Link>
            </li>
            <li>
              <Link to="/diamond-search">
                <Emerald width="42px" height="62px" />
                Emerald
              </Link>
            </li>
            <li>
              <Link to="/diamond-search">
                <Pear width="43px" height="68px" />
                Pear
              </Link>
            </li>
            <li>
              <Link to="/diamond-search">
                <Asscher width="60px" height="60px" />
                Asscher
              </Link>
            </li>
            <li>
              <Link to="/diamond-search">
                <Heart width="71px" height="68px" />
                Heart
              </Link>
            </li>
            <li>
              <Link to="/diamond-search">
                <Radiant width="48px" height="66px" />
                Radiant
              </Link>
            </li>
            <li>
              <Link to="/diamond-search">
                <Marquise width="76px" height="71px" />
                Marquise
              </Link>
            </li>
          </ul>
        </Container>
      </div>

      <CreateYourOwn />
      <div className="how-to-choose-diamond">
        <Container>
          <Row>
            <Col md={5}>
              <div className="left">
                <span>
                  <img className="img-fluid" src={`${HowDiamond}`} alt="" />
                </span>
              </div>
            </Col>
            <Col md={7}>
              <div className="right">
                <div className="common-heading">
                  <h3>
                    <span>H</span> ow to choose a Diamond
                  </h3>
                </div>
                <p>
                  Our diamond specialists are available to share their expertise
                  and empower you with the information and tools you need to
                  select the perfect diamond.
                </p>
                <div className="consultation">
                  <h6>Schedule a personalized consultations</h6>
                  <ul>
                    <li>
                      <Mail width="48px" height="38px" />
                      <a href="mailto:help@radix.com">help@radix.com</a>
                    </li>
                    <li>
                      <Phone width="38px" height="38px" />
                      <a href="tel:1800-858-6936">1800-858-6936</a>
                    </li>
                    <li>
                      <Live width="39px" height="39px" />
                      <a href="">Live chat Room</a>
                    </li>
                  </ul>
                </div>
              </div>
            </Col>
          </Row>
        </Container>
      </div>
      <div className="conflict-free-diamond">
        <Container fluid className="px-0 d-flex justify-content-between">
          <div className="left">
            <h4>Conflict Free Diamonds</h4>
            <p>
              Every loose diamond on Radix is conflict-free and certified by one
              of the top 3 grading laboratories: GIA, AGS or IGI. The diamond
              certificates are displayed along with the loose diamond on our
              site
            </p>
          </div>
          <div className="right">
            <h4>Lab Created Diamonds</h4>
            <p>
              Our lab-created diamonds offer identical sparkle and chemical
              composition as Earth-Created diamonds. The core difference between
              them is their origin: Earth-Created diamonds are sourced from
              below the earth’s surface and offer a timeless effect.
            </p>
          </div>
        </Container>
      </div>
      <Help />

      <div className="learning-center">
        <Container>
          <div className="common-heading">
            <h3>
              <span>L</span> earning Center
            </h3>
          </div>
          <ul className="guide-list d-flex align-items-center">
            <li>
              <span>
                <img src={`${Learn1}`} alt="" className="img-fluid" />
              </span>
              <h4>
                Learn About <br /> 4c's
              </h4>
            </li>
            <li>
              <span>
                <img src={`${Learn2}`} alt="" className="img-fluid" />
              </span>
              <h4>
                Engagement Ring <br /> Guide
              </h4>
            </li>
            <li>
              <span>
                <img src={`${Learn3}`} alt="" className="img-fluid" />
              </span>
              <h4>
                Lifetime Diamond <br /> Upgrad
              </h4>
            </li>
          </ul>
        </Container>
      </div>
      <div className="recentView">
        <Container>
          <Recent />
        </Container>
      </div>
    </LooseDiamondsWrap>
  );
};

export default LooseDiamonds;
