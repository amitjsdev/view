import React, { useState, useEffect } from "react";
import {
  TabContent,
  TabPane,
  Nav,
  NavItem,
  NavLink,
  Container,
  Dropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
  Col,
  Row,
} from "reactstrap";
import Pagination from "@material-ui/lab/Pagination";
import LooseDiamondFilter from "../../../components/Filters/LooseDiamondFilter";
import { useHistory, useLocation } from "react-router-dom";
import APIUtil from "../../../api";
import ProgressStrip from "../../../components/ProgressStrip";
import { UserDetails } from "../../../constant";
// css
import { DiamondListWrap } from "../../../css/looseDiamonds";

//images
import Big from "../../../assets/images/looseDiamonds/bigDiamond.png";
import { ReactComponent as Fast } from "../../../assets/images/looseDiamonds/fastdelivery.svg";
import { ReactComponent as Weight } from "../../../assets/images/looseDiamonds/weight.svg";
import { ReactComponent as ListView } from "../../../assets/images/looseDiamonds/listView.svg";
import { ReactComponent as GridView } from "../../../assets/images/looseDiamonds/gridView.svg";
import { ReactComponent as PreviewDummy } from "../../../assets/images/looseDiamonds/diamond-preview-dummy.svg";
import { ReactComponent as View } from "../../../assets/images/looseDiamonds/view.svg";
import { ReactComponent as Ring } from "../../../assets/images/looseDiamonds/ringloose.svg";
import { ReactComponent as Pendant } from "../../../assets/images/looseDiamonds/pendant.svg";
import { ReactComponent as Basket } from "../../../assets/images/looseDiamonds/basket.svg";
import { ReactComponent as Down } from "../../../assets/images/looseDiamonds/arrowDown.svg";

const api = new APIUtil();

const DiamondList = (props) => {
  const history = useHistory();
  const userId = UserDetails();
  const [activeTab, setActiveTab] = useState("1");
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [dropdownOpenOne, setDropdownOpenOne] = useState(false);
  const [dropdownOpenTwo, setDropdownOpenTwo] = useState(false);
  const [listView, setListView] = useState(false);
  const [gridView, setGridView] = useState(true);
  const [diamondPreview, setDiamondPreview] = useState([]);
  const [diamondSizeAndDepth, setDiamondSizeAndDepth] = useState(false);
  const [diamondList, setDiamondList] = useState([]);
  const [hover, setHover] = useState();
  const [stoneShape, setStoneShape] = useState();
  const [page, setPage] = useState(1);
  const [count, setCount] = useState(0);
  const [sorting, setSorting] = useState({
    carat: 1,
    color: 1,
    clarity: 1,
    cut: 1,
    price: 1,
  });
  const [compareDiamonds, setCompareDiamonds] = useState();
  const [cutRange, setCutRange] = useState({
    min: 1,
    max: 4,
  });

  const [colorRange, setColorRange] = useState({
    min: 1,
    max: 8,
  });

  const [clarityRange, setClarityRange] = useState({
    min: 1,
    max: 10,
  });

  const [caratValue, setCaratValue] = useState({
    min: 0,
    max: 0,
  });

  const [minMax, setMinMax] = useState({
    min: 0,
    max: 0,
  });

  const [finalValueRange, setFinalValueRange] = useState();
  const [caratRange, setCaratRange] = useState();

  const toggle = (tab) => {
    if (activeTab !== tab) setActiveTab(tab);
  };
  const dropdownToggle = () => setDropdownOpen((prevState) => !prevState);
  const dropdownToggleOne = () => setDropdownOpenOne((prevState) => !prevState);
  const dropdownToggleTwo = () => setDropdownOpenTwo((prevState) => !prevState);

  // ListView
  const onHandleListView = () => {
    setListView(true);
    setGridView(false);
  };

  // gridView
  const onHandleGridView = () => {
    setListView((prevState) => !prevState);
    setGridView((prevState) => !prevState);
  };

  const defaultPrice = () => {
    api.get("looseDiamonds/minMaxPrice").then((res) => {
      const x = res.data.data[0].min.$numberDecimal;
      const y = res.data.data[0].max.$numberDecimal;
      setFinalValueRange({ min: x, max: y });
      setMinMax({ min: x, max: y });
    });
  };

  const defaultCarat = () => {
    api.get("looseDiamonds/minMaxcCarat").then((res) => {
      const x = res.data.data[0].min.$numberDecimal;
      const y = res.data.data[0].max.$numberDecimal;
      setCaratRange({ min: x, max: y });
      setCaratValue({ min: x, max: y });
    });
  };

  useEffect(() => {
    defaultPrice();
    defaultCarat();
    diamondDetail();
  }, []);
  //selected shape from engagement rings page
  const search = useLocation().search;
  const engagementRingId = new URLSearchParams(search).get("engagementRingId");

  useEffect(() => {
    if (!!engagementRingId && Object.keys(userId).length > 0) {
      api.get(`products/ringReview?id=${userId._id.toString()}`).then((res) => {
        let ringReviewData = Object.values(res.data.data);
        ringReviewData &&
          ringReviewData.length > 0 &&
          ringReviewData.map((item) => {
            if (item?.engagementRingId?._id === engagementRingId) {
              setStoneShape(item.engagementRingId.diamondShape);
            }
          });
      });
    }
  }, []);
  //&sort={'price': ${sorting.price}, 'caratWeight': ${sorting.carat}, 'colorNumber': ${sorting.color},'clarityNumber': ${sorting.clarity}, 'cutNumber': ${sorting.cut}}
  useEffect(() => {
    if (finalValueRange && caratRange) {
      const stones = `&stone_shape=${stoneShape ? stoneShape : ""}`;
      // Checking here if the values are empty then remove the key from params.
      function removeEmptyParams(query) {
        return query.replace(/[^=&]+=(?:&|$)/g, "");
      }
      const finalStoneShapes = removeEmptyParams(stones);
      api
        .get(
          `looseDiamonds/looseDiamondsFilter?pageNumber=${page}&numberRecord=10&minPrice=${finalValueRange?.min}&maxPrice=${finalValueRange?.max}&minCaratWeight=${caratRange.min}&maxCaratWeight=${caratRange.max}&minClarityNumber=${clarityRange.min}&maxClarityNumber=${clarityRange.max}&minCutNumber=${cutRange.min}&maxCutNumber=${cutRange.max}&minColorNumber=${colorRange.min}&maxColorNumber=${colorRange.max}${finalStoneShapes}&sort={'price': ${sorting.price}, 'caratWeight': ${sorting.carat}, 'colorNumber': ${sorting.color},'clarityNumber': ${sorting.clarity}, 'cutNumber': ${sorting.cut}}`
        )
        .then((res) => {
          setDiamondList(res.data.data.LooseDiamonds);
          setCount(res.data.data.page);
          if (page > res.data.data.page) {
            setPage(1);
          }
        });
    }
  }, [
    finalValueRange,
    caratRange,
    colorRange,
    cutRange,
    clarityRange,
    stoneShape,
    page,
    count,
    sorting,
  ]);

  const diamondDetail = (id) => {
    const x = diamondList.filter((val) => val._id === id);
    const y = x.map((val, i) => {
      if (val._id === id) {
        setHover(id);
      }
      return (
        <ul key={i} className="list">
          <li>
            <h4>SUK</h4>
            <p>{val.suk}</p>
          </li>
          <li>
            <h4>Symmetry</h4>
            <p>{val.symmetry}</p>
          </li>
          <li>
            <h4>Polish</h4>
            <p>{val.polish}</p>
          </li>
          <li>
            <h4>Measurement</h4>
            <p>{val.measurements}</p>
          </li>
          <li>
            <h4>Table</h4>
            <p>{val.tableSize}</p>
          </li>
          <li>
            <h4>Girdle</h4>
            <p>{val.girdleThickness}</p>
          </li>
          <li>
            <h4>Depth</h4>
            <p>{val.totalDepth}</p>
          </li>
          <li>
            <h4>Culet</h4>
            <p>{val.culet}</p>
          </li>
        </ul>
      );
    });
    const z = x.map((val, i) => {
      return (
        <div key={i}>
          <span className="table-size position-absolute">{val.tableSize}</span>
          <span className="depth position-absolute">{val.totalDepth}</span>
        </div>
      );
    });
    setDiamondSizeAndDepth(z);
    setDiamondPreview(y);
  };

  // Detail page direction
  const onClickHandle = async (val) => {
    history.push({
      pathname: `/diamond-details/${val._id}`,
    });
    //   if(!!engagementRingId){
    //   let new_data = {
    //     userId: userId._id.toString(),
    //     looseDiamondId: val._id,
    //     size: parseInt(0),
    //   };
    //   const token = localStorage.getItem("token");
    //   const headers = {
    //     Authorization: `Bearer ${token}`,
    //   };
    //   await api.post(`products/addMakeRingReview`, new_data, { headers }).then((response) => {
    //     if (response) {
    //       window.location.replace( `/engagement-rings-details/${engagementRingId}?stoneShapeId=${val._id}`);
    //     }
    //   });
    // }else{
    //   history.push({
    //     pathname: `/diamond-details/${val._id}`,
    //   });
    // }
  };

  // Fetch diamond list in grid View
  const gridProducts = () => {
    return diamondList.map((val, i) => {
      return (
        <div
          className={`product ${val._id === hover ? "hover" : "noHover"}`}
          onMouseEnter={() => diamondDetail(val._id)}
          key={i}
        >
          <span onClick={() => onClickHandle(val)}>
            {val.images.diamondImages.map((val, i) => {
              return <img key={i} className="img-fluid" src={val} alt="" />;
            })}
          </span>
          <div className="desc">
            <h4 onClick={() => onClickHandle(val)}>
              {val.caratWeight.$numberDecimal}-Carat {val.shapeCut} cut
            </h4>
            <h5>${val.price?.$numberDecimal}</h5>
            <div className="d-flex align-items-center justify-content-between">
              <Fast width="21px" height="20px" />
              <Weight
                onClick={() => compareDiamondsHandle(val)}
                width="26px"
                height="26px"
              />
            </div>
          </div>
        </div>
      );
    });
  };

  // Fetch diamond list in list View
  const listViewProducts = () => {
    return diamondList.map((val, i) => {
      return (
        <li
          key={i}
          className={`product ${val._id === hover ? "hover" : "noHover"}`}
          onMouseEnter={() => diamondDetail(val._id)}
        >
          <p>
            <Fast width="33px" height="31px" />
          </p>
          <p>
            {val.images.diamondImages.map((val, i) => {
              return <img key={i} className="img-fluid" src={val} alt="" />;
            })}
          </p>
          <p>{val.shapeCut}</p>
          <p>{val.caratWeight?.$numberDecimal}</p>
          <p>{val.colorGrade}</p>
          <p>{val.clarityGrade}</p>
          <p>{val.cutGrade}</p>
          <p>IGI</p>
          <p>${val.price?.$numberDecimal}</p>
          <button onClick={() => onClickHandle(val)}>
            <View width="17px" height="11px" className="mr-2" />
            Detail
          </button>
        </li>
      );
    });
  };

  const handlePageChange = (event, value) => {
    setPage(value);
  };

  const compareDiamondsHandle = (e) => {
    const arr = [];
    const id = e._id;
    arr.push(e._id);
    console.log(...arr);
    // setCompareDiamonds((prevState) => {
    //   return { ...prevState, id };
    // });
  };

  useEffect(() => {
    if (compareDiamonds) {
      api.get(`looseDiamonds/compareDiamonds?productId=${compareDiamonds}`);
    }
  }, [compareDiamonds]);

  return (
    <DiamondListWrap>
      {!!engagementRingId && (
        <div className="pb-5">
          <ProgressStrip engagementRingId={engagementRingId} />
        </div>
      )}
      <LooseDiamondFilter
        stoneShape={stoneShape}
        engagementRingId={engagementRingId}
        finalValueRange={finalValueRange}
        setFinalValueRange={setFinalValueRange}
        setMinMax={setMinMax}
        minMax={minMax}
        caratValue={caratValue}
        setCaratValue={setCaratValue}
        caratRange={caratRange}
        setCaratRange={setCaratRange}
        cutRange={cutRange}
        setCutRange={setCutRange}
        colorRange={colorRange}
        setColorRange={setColorRange}
        clarityRange={clarityRange}
        setSelectShape={setStoneShape}
        setClarityRange={setClarityRange}
      />
      <Container className="pb-5 mb-5">
        <Row>
          <Col
            md={activeTab === "3" ? 0 : 3}
            className={activeTab === "3" ? "d-none" : ""}
          >
            <div className="diamond-preview">
              <h2>Diamond Preview</h2>
              {diamondPreview.length > 0 ? (
                <>
                  <div className="position-relative preview-inner">
                    <PreviewDummy width="413px" height="413px" />
                    {diamondSizeAndDepth}
                  </div>
                  {diamondPreview}
                </>
              ) : (
                <h6>Hover over any diamond to see diamond details</h6>
              )}
            </div>
          </Col>
          <Col md={activeTab === "3" ? 12 : 9}>
            <div className="d-flex title justify-content-between align-items-center">
              <Nav tabs>
                <NavItem>
                  <NavLink
                    className={activeTab === "1" ? "active" : ""}
                    onClick={() => {
                      toggle("1");
                    }}
                  >
                    All Diamonds
                  </NavLink>
                </NavItem>
                <NavItem>
                  <NavLink
                    className={activeTab === "2" ? "active" : ""}
                    onClick={() => {
                      toggle("2");
                    }}
                  >
                    Recently Viewed
                  </NavLink>
                </NavItem>
                <NavItem>
                  <NavLink
                    className={activeTab === "3" ? "active" : ""}
                    onClick={() => {
                      toggle("3");
                    }}
                  >
                    Comparison
                  </NavLink>
                </NavItem>
              </Nav>
              <div
                className={`view align-items-center ${
                  activeTab === "3" ? "d-none" : "d-flex"
                }`}
              >
                <label>View</label>
                <ListView
                  width="30px"
                  height="30px"
                  onClick={onHandleListView}
                  className={`mr-2 ${listView ? "active" : ""}`}
                />
                <GridView
                  width="30px"
                  height="30px"
                  onClick={onHandleGridView}
                  className={gridView ? "active" : ""}
                />
              </div>
            </div>
            <div className="diamond-filters-dropdown d-flex justify-content-between align-items-center py-3">
              <div className="fast-shipping d-flex align-items-center">
                <label>
                  <input type="checkbox" />
                  <Fast width="21px" height="20px" />
                  Fast Shipping
                </label>
              </div>

              <div className="inner-filter date mr-5">
                <label>Ship Diamond by</label>
                <Dropdown isOpen={dropdownOpen} toggle={dropdownToggle}>
                  <DropdownToggle caret>Any Date</DropdownToggle>
                  <DropdownMenu>
                    <DropdownItem>Any Date</DropdownItem>
                    <DropdownItem>Friday, April 02</DropdownItem>
                  </DropdownMenu>
                </Dropdown>
              </div>

              <div className="inner-filter sort">
                <label>Sort by</label>
                <Dropdown isOpen={dropdownOpenOne} toggle={dropdownToggleOne}>
                  <DropdownToggle caret>Best Match</DropdownToggle>
                  <DropdownMenu>
                    <DropdownItem>
                      <div className="min-max">
                        <h6>Date</h6>
                        <ul>
                          <li>
                            <span>Soonest</span>
                            <span>Latest</span>
                          </li>
                        </ul>
                      </div>
                    </DropdownItem>
                    <DropdownItem>
                      <div className="min-max">
                        <h6>Carat</h6>
                        <ul>
                          <li>
                            <span
                              onClick={() =>
                                setSorting((prevState) => {
                                  return {
                                    ...prevState,
                                    carat: 1,
                                  };
                                })
                              }
                            >
                              Low to High
                            </span>
                            <span
                              onClick={() =>
                                setSorting((prevState) => {
                                  return {
                                    ...prevState,
                                    carat: -1,
                                  };
                                })
                              }
                            >
                              High to Low
                            </span>
                          </li>
                        </ul>
                      </div>
                    </DropdownItem>
                    <DropdownItem>
                      <div className="min-max">
                        <h6>Color</h6>
                        <ul>
                          <li>
                            <span
                              onClick={() =>
                                setSorting((prevState) => {
                                  return {
                                    ...prevState,
                                    color: 1,
                                  };
                                })
                              }
                            >
                              Low to High
                            </span>
                            <span
                              onClick={() =>
                                setSorting((prevState) => {
                                  return {
                                    ...prevState,
                                    color: -1,
                                  };
                                })
                              }
                            >
                              High to Low
                            </span>
                          </li>
                        </ul>
                      </div>
                    </DropdownItem>
                    <DropdownItem>
                      <div className="min-max">
                        <h6>Clarity</h6>
                        <ul>
                          <li>
                            <span
                              onClick={() =>
                                setSorting((prevState) => {
                                  return {
                                    ...prevState,
                                    clarity: 1,
                                  };
                                })
                              }
                            >
                              Low to High
                            </span>
                            <span
                              onClick={() =>
                                setSorting((prevState) => {
                                  return {
                                    ...prevState,
                                    clarity: -1,
                                  };
                                })
                              }
                            >
                              High to Low
                            </span>
                          </li>
                        </ul>
                      </div>
                    </DropdownItem>
                    <DropdownItem>
                      <div className="min-max">
                        <h6>Cut</h6>
                        <ul>
                          <li>
                            <span
                              onClick={() =>
                                setSorting((prevState) => {
                                  return {
                                    ...prevState,
                                    cut: 1,
                                  };
                                })
                              }
                            >
                              Low to High
                            </span>
                            <span
                              onClick={() =>
                                setSorting((prevState) => {
                                  return {
                                    ...prevState,
                                    cut: -1,
                                  };
                                })
                              }
                            >
                              High to Low
                            </span>
                          </li>
                        </ul>
                      </div>
                    </DropdownItem>
                    <DropdownItem>
                      <div className="min-max">
                        <h6>Price</h6>
                        <ul>
                          <li>
                            <span
                              onClick={() =>
                                setSorting((prevState) => {
                                  return {
                                    ...prevState,
                                    price: 1,
                                  };
                                })
                              }
                            >
                              Low to High
                            </span>
                            <span
                              onClick={() =>
                                setSorting((prevState) => {
                                  return {
                                    ...prevState,
                                    price: -1,
                                  };
                                })
                              }
                            >
                              High to Low
                            </span>
                          </li>
                        </ul>
                      </div>
                    </DropdownItem>
                  </DropdownMenu>
                </Dropdown>
              </div>
            </div>
            <TabContent activeTab={activeTab}>
              <TabPane tabId="1">
                {gridView && (
                  <div className="grid-view d-grid">{gridProducts()}</div>
                )}
                {listView && (
                  <div className="list-view">
                    <div className="listview-title">
                      <ul className="header">
                        <li />
                        <li />
                        <li>Shape</li>
                        <li>
                          Carat <Down width="17px" height="9px" />
                        </li>
                        <li>
                          Color <Down width="17px" height="9px" />
                        </li>
                        <li>
                          Clarity <Down width="17px" height="9px" />
                        </li>
                        <li>
                          Cut <Down width="17px" height="9px" />
                        </li>
                        <li>
                          Certified <Down width="17px" height="9px" />
                        </li>
                        <li>
                          Price <Down width="17px" height="9px" />
                        </li>
                        <li />
                      </ul>
                    </div>
                    <ul className="product">{listViewProducts()}</ul>
                  </div>
                )}
                <Pagination
                  className="my-3"
                  count={count}
                  page={page}
                  siblingCount={1}
                  boundaryCount={1}
                  variant="outlined"
                  showFirstButton
                  showLastButton
                  shape="rounded"
                  onChange={handlePageChange}
                />
              </TabPane>
              <TabPane tabId="2">
                {gridView && (
                  <div className="grid-view d-grid">{gridProducts()}</div>
                )}
                {listView && (
                  <div className="list-view">
                    <div className="listview-title">
                      <ul className="header">
                        <li />
                        <li />
                        <li>Shape</li>
                        <li>
                          Carat <Down width="17px" height="9px" />
                        </li>
                        <li>
                          Color <Down width="17px" height="9px" />
                        </li>
                        <li>
                          Clarity <Down width="17px" height="9px" />
                        </li>
                        <li>
                          Cut <Down width="17px" height="9px" />
                        </li>
                        <li>
                          Certified <Down width="17px" height="9px" />
                        </li>
                        <li>
                          Price <Down width="17px" height="9px" />
                        </li>
                        <li />
                      </ul>
                    </div>
                    <ul className="product">{listViewProducts()}</ul>
                  </div>
                )}
              </TabPane>
              <TabPane tabId="3">
                <div className="comparison d-flex">
                  <div className="header">
                    <ul className="list">
                      <li />
                      <li>
                        <p>View Details</p>
                      </li>
                      <li>
                        <p>Add to</p>
                      </li>
                      <li>
                        <p>Price</p>
                      </li>
                      <li>
                        <p>Carat Weight</p>
                      </li>
                      <li>
                        <p>Shape</p>
                      </li>
                      <li>
                        <p>Cut</p>
                      </li>
                      <li>
                        <p>Color</p>
                      </li>
                      <li>
                        <p>Clarity</p>
                      </li>
                      <li>
                        <p>L/W ratio</p>
                      </li>
                      <li>
                        <p>Depth</p>
                      </li>
                      <li>
                        <p>Table</p>
                      </li>
                      <li>
                        <p>Polish</p>
                      </li>
                      <li>
                        <p>Symmentry</p>
                      </li>
                      <li>
                        <p>Culet</p>
                      </li>
                      <li>
                        <p>Fluorescence</p>
                      </li>
                      <li>
                        <p>Measurments</p>
                      </li>
                    </ul>
                  </div>
                  <div className="body">
                    <ul className="list">
                      <li>
                        <span>
                          <img src={`${Big}`} alt="" />
                        </span>
                      </li>
                      <li>
                        <p>LFHYHVGF525615</p>
                      </li>
                      <li className="dropdownBtn">
                        <Dropdown
                          isOpen={dropdownOpenTwo}
                          toggle={dropdownToggleTwo}
                        >
                          <DropdownToggle caret>Add to</DropdownToggle>
                          <DropdownMenu>
                            <DropdownItem>
                              <Ring
                                width="20px"
                                height="21px"
                                className="mr-2"
                              />
                              Ring
                            </DropdownItem>
                            <DropdownItem>
                              <Pendant
                                width="20px"
                                height="21px"
                                className="mr-2"
                              />
                              Pendant
                            </DropdownItem>
                            <DropdownItem>
                              <Basket
                                width="20px"
                                height="21px"
                                className="mr-2"
                              />
                              Basket
                            </DropdownItem>
                          </DropdownMenu>
                        </Dropdown>
                      </li>
                      <li>
                        <p>$3600</p>
                      </li>
                      <li>
                        <p>1.28</p>
                      </li>
                      <li>
                        <p>RD</p>
                      </li>
                      <li>
                        <p>Ideal</p>
                      </li>
                      <li>
                        <p>K</p>
                      </li>
                      <li>
                        <p>SI1</p>
                      </li>
                      <li>
                        <p>1.00</p>
                      </li>
                      <li>
                        <p>63.1</p>
                      </li>
                      <li>
                        <p>55</p>
                      </li>
                      <li>
                        <p>Excellent</p>
                      </li>
                      <li>
                        <p>Excellent</p>
                      </li>
                      <li>
                        <p>Pointed</p>
                      </li>
                      <li>
                        <p>None</p>
                      </li>
                      <li>
                        <p>6.90*6.81*4.34</p>
                      </li>
                    </ul>
                  </div>
                </div>
              </TabPane>
            </TabContent>
          </Col>
        </Row>
      </Container>
    </DiamondListWrap>
  );
};

export default DiamondList;
