import React, { useState, useEffect, useContext } from "react";
import {
  Carousel,
  Container,
  CarouselItem,
  CarouselControl,
  TabContent,
  TabPane,
  Nav,
  NavItem,
  NavLink,
} from "reactstrap";
import APIUtil from "../../../api";
import { useParams, useLocation } from "react-router";
import { Authentication, UserDetails } from "../../../constant";
import { CartContext } from "../../../context/CartContext";
import { Tooltip } from "@material-ui/core";

import Help from "../../../components/Help";
//css
import { ProductDetail } from "../../../css/productDetail";
import { CustomButton } from "../../../css/global";

//images
import { ReactComponent as Cart } from "../../../assets/images/addcart.svg";
import { ReactComponent as PreviewDummy } from "../../../assets/images/looseDiamonds/diamond-preview-dummy.svg";
import { ReactComponent as Wishlist } from "../../../assets/images/addwishlist.svg";
import { ReactComponent as EmailUs } from "../../../assets/images/emailus.svg";
import { ReactComponent as HelpImg } from "../../../assets/images/help.svg";
import DetailImg from "../../../assets/images/detail/studDetail.png";
import LuxuryGift from "../../../assets/images/detail/ring.png";
import Diamond from "../../../assets/images/model/big-diamond.png";
import { ReactComponent as Truck } from "../../../assets/images/shippingTruck.svg";
import Coin from "../../../assets/images/looseDiamonds/coin.png";
import DEF from "../../../assets/images/looseDiamonds/def.png";
import GHIJ from "../../../assets/images/looseDiamonds/ghij.png";
import KLM from "../../../assets/images/looseDiamonds/klm.png";
import NQPR from "../../../assets/images/looseDiamonds/nqpr.png";
import STUV from "../../../assets/images/looseDiamonds/stuv.png";
import Dummy from "../../../assets/images/looseDiamonds/table-dummy.png";
import { toast } from "react-toastify";
import ProgressStrip from "../../../components/ProgressStrip";

const api = new APIUtil();

const LooseDiamondDetail = (props) => {
  const { id } = useParams();

  const isAuth = Authentication();
  const userId = UserDetails();
  const {
    addProduct,
    wishProduct,
    wishListId,
    wishListIdDel,
    cartListIdDel,
    cartListId,
  } = useContext(CartContext);
  const [productDetails, setProductDetails] = useState({});
  const [images, setImages] = useState([]);
  const [load, setLoad] = useState(true);
  const [activeIndex, setActiveIndex] = useState(0);
  const [animating, setAnimating] = useState(false);
  const [activeTab, setActiveTab] = useState("1");
  const [ringProduct, setRingProduct] = useState([]);
  const [totalPrice, setTotalPrice] = useState(0);
  const [diamondProduct, setDiamondProduct] = useState([]);
  const [checkSettingID, setCheckSettingID] = useState([]);
  const [checkDiamondID, setCheckDiamondID] = useState([]);

  const search = useLocation().search;
  const stoneShapeId = new URLSearchParams(search).get("stoneShapeId");
  const toggle = (tab) => {
    if (activeTab !== tab) setActiveTab(tab);
  };

  // slider
  const next = () => {
    if (animating) return;
    const nextIndex = activeIndex === images.length - 1 ? 0 : activeIndex + 1;
    setActiveIndex(nextIndex);
  };

  const previous = () => {
    if (animating) return;
    const nextIndex = activeIndex === 0 ? images.length - 1 : activeIndex - 1;
    setActiveIndex(nextIndex);
  };

  const goToIndex = (newIndex) => {
    if (animating) return;
    setActiveIndex(newIndex);
  };

  // Image slider
  const imageSlides = images?.map((item, index) => {
    return (
      <CarouselItem
        onExiting={() => setAnimating(true)}
        onExited={() => setAnimating(false)}
        key={index}
      >
        <img src={item} className="test" alt="" />
      </CarouselItem>
    );
  });
  // Image slider

  useEffect(() => {
    api
      .get(`looseDiamonds/looseDiamondsDetails?productId=${id}`)
      .then((res) => {
        setProductDetails(res.data.data);
        setImages(res.data.data?.images?.diamondImages);
      });
  }, []);

  //update total price
  useEffect(() => {
    if (!!stoneShapeId && !!productDetails?._id) {
      api.get(`products/ringReview?id=${userId._id.toString()}`).then((res) => {
        let ringReviewData = Object.values(res.data.data);
        let maineData = [];
        ringReviewData &&
          ringReviewData.length > 0 &&
          ringReviewData.map((item) => {
            if (item?.engagementRingId?._id == productDetails?._id) {
              setRingProduct(item.engagementRingId);
            }
            if (item?.looseDiamondId?._id == stoneShapeId) {
              setDiamondProduct(item.looseDiamondId);
            }
          });
      });
    } else {
      if (!!userId && !!userId?._id && Object.keys(userId).length > 0 && !!productDetails) {
        api
          .get(`products/ringReview?id=${userId._id.toString()}`)
          .then((res) => {
            let ringReviewData = Object.values(res.data.data);
            let maineData = [];
            ringReviewData &&
              ringReviewData.length > 0 &&
              ringReviewData.map((item) => {
                if (item?.looseDiamondId?._id) {
                  setCheckDiamondID({
                    looseDiamondItem: item.looseDiamondId?._id,
                  });
                }
                if (item?.engagementRingId?._id) {
                  setCheckSettingID({
                    engagementItem: item.engagementRingId?._id,
                  });
                }
              });
          });
      }
    }
  }, [productDetails]);

  // BankWire price Calculation
  const bankWire = () => {
    const totalPrice = productDetails?.price?.$numberDecimal;
    const bankwireDiscount = 1.5 / 100;
    const finalBankWirePrice = totalPrice - totalPrice * bankwireDiscount;
    return finalBankWirePrice.toFixed(2);
  };

  // To check product is already in wishlist or not
  const isInWish = (id) => {
    if (isAuth) {
      if (wishListId.includes(id)) {
        return true;
      } else {
        return false;
      }
    }
  };

  // to check the product is already in cart or not
  const isInCart = (id) => {
    if (isAuth) {
      if (cartListId.includes(id)) {
        return true;
      } else {
        return false;
      }
    }
  };

  const addToCart = async (price, id, category) => {
    if (isAuth) {
      const body = {
        userId: userId._id.toString(),
        quantity: 1,
        price: price,
        productCategory: category,
        productId: id,
      };

      await api.post("products/addCart", body).then((response) => {});
      props.history.push("/addtocart");
    }
  };

  // To Remove the product for cart
  const removeFromCart = async (id, category) => {
    if (isAuth) {
      const del_data = {
        userId: userId._id.toString(),
        productId: id,
      };

      await api.post("products/delCart", del_data).then((response) => {
        if (cartListId.includes(id)) {
          const filter = cartListId.filter(function (data) {
            return data !== id;
          });
          setLoad(!load);
          cartListIdDel(filter);
        }
      });
    }
  };

  // To remove the product from wishlist
  const wishListRemove = async (id, category) => {
    if (isAuth) {
      const del_data = {
        userId: userId._id.toString(),
        productId: id,
      };

      await api.post("products/delWishlist", del_data).then((response) => {
        if (wishListId.includes(id)) {
          const filter = wishListId.filter(function (data) {
            return data !== id;
          });
          setLoad(!load);

          wishListIdDel(filter);
        }
      });
    }
  };

  const toWishClick = async (id, category) => {
    if (isAuth) {
      const body = [
        {
          userId: userId._id.toString(),
          productId: id,
          productCategory: category,
        },
      ];

      await api.post("products/addWishlist", body).then((response) => {});
      setLoad(!load);
    }
  };

  useEffect(() => {
    if (isAuth) {
      addProduct(userId._id.toString());
      wishProduct(userId._id.toString());
    }
  }, [load]);

  const addToRing = async (id) => {
    if (isAuth) {
      const body = {
        userId: userId._id.toString(),
        looseDiamondId: id,
        size: 0,
      };
      const token = localStorage.getItem("token");
      const headers = {
        Authorization: `Bearer ${token}`,
      };
      if (checkDiamondID?.looseDiamondItem) {
        let new_data = {
          userId: userId._id.toString(),
          looseDiamondId: checkDiamondID?.looseDiamondItem,
        };
        await api
          .post(`products/delRingReview`, new_data, { headers })
          .then((response) => {});
      }
      await api
        .post(`products/addMakeRingReview`, body, { headers })
        .then((response) => {
          console.log("response", checkSettingID, response, response.message);
          if (!!checkSettingID?.engagementItem) {
            props.history.push({
              pathname: `/complete-jewel/${checkSettingID?.engagementItem}`,
              search: `?stoneShapeId=${id}`,
            });
          } else {
            props.history.push({
              pathname: `/build-your-own-ring/settings`,
              search: `?diamondId=${id}`,
            });
          }
        });
    }
  };

  return (
    <ProductDetail looseDiamond>
      <ProgressStrip />
      <Container>
        <div className="product-card">
          <div className="product-image">
            <Carousel activeIndex={activeIndex} next={next} previous={previous}>
              {imageSlides}
              <CarouselControl
                direction="prev"
                directionText="Previous"
                onClickHandler={previous}
              />
              <CarouselControl
                direction="next"
                directionText="Next"
                onClickHandler={next}
              />
            </Carousel>
          </div>
          <div className="product-details">
            <h2>
              {productDetails?.caratWeight?.$numberDecimal}-Carat{" "}
              {productDetails?.shapeCut} Shaped Diamond
            </h2>
            <div className="selected-filter pt-3 d-flex align-items-center">
              <div className="d-flex">
                <label>Cut - </label>
                <b>
                  <em>{productDetails?.cutGrade}</em>
                </b>
              </div>
              <div className="d-flex">
                <label>Color - </label>
                <b>
                  <em>{productDetails?.colorGrade}</em>
                </b>
              </div>
              <div className="d-flex">
                <label>Clarity - </label>
                <b>
                  <em>{productDetails?.clarityGrade}</em>
                </b>
              </div>
            </div>
            <div className="product-price">
              {productDetails?.status !== 2 ? (
                <h3 className="product-price-original">
                  ${productDetails?.price?.$numberDecimal}
                </h3>
              ) : (
                <h3 className="product-price-original">Out of Stock</h3>
              )}
              {productDetails?.status !== 2 ? (
                <>
                  <h5>Bankwire - ${bankWire()}</h5>
                  <h5>
                    Welcome offer on first purchase, use <span>WELCOME21</span>{" "}
                    code{" "}
                  </h5>
                </>
              ) : (
                ""
              )}
            </div>
            <div className="d-flex justify-content-start btn-grp">
              {isInWish(
                productDetails?._id,
                productDetails?.productCategory
              ) && (
                <CustomButton
                  dark
                  onClick={() =>
                    wishListRemove(
                      productDetails?._id,
                      productDetails?.productCategory
                    )
                  }
                  className="customButton black"
                >
                  <Wishlist width="19px" height="19px" fill="#ff5000" />
                </CustomButton>
              )}

              {!isInWish(
                productDetails?._id,
                productDetails?.productCategory
              ) && (
                <Tooltip title={isAuth ? "" : "Login First "}>
                  <CustomButton
                    dark
                    onClick={() =>
                      toWishClick(
                        productDetails?._id,
                        productDetails?.productCategory
                      )
                    }
                    className="customButton black"
                  >
                    <Wishlist width="19px" height="19px" fill="#fff" />
                  </CustomButton>
                </Tooltip>
              )}

              {isInCart(
                productDetails?._id,
                productDetails?.productCategory
              ) && (
                <CustomButton
                  dark
                  onClick={() =>
                    removeFromCart(
                      productDetails?._id,
                      productDetails?.productCategory
                    )
                  }
                  className="customButton cart black"
                >
                  <Cart width="25px" height="21px" fill="#fff" /> Remove From
                  Cart
                </CustomButton>
              )}
              <Tooltip title={isAuth ? "" : "Login First "}>
                <CustomButton
                  dark
                  className="customButton cart black"
                  onClick={() =>
                    addToRing(
                      productDetails?._id,
                      productDetails?.productCategory,
                      productDetails?.price
                    )
                  }
                >
                  <Cart width="25px" height="21px" fill="#fff" /> Add to Ring
                </CustomButton>
              </Tooltip>
              {productDetails?.status !== 2 ? (
                !isInCart(
                  productDetails?._id,
                  productDetails?.productCategory
                ) && (
                  <Tooltip title={isAuth ? "" : "Login First "}>
                    <CustomButton
                      dark
                      className="customButton cart black"
                      onClick={() =>
                        addToCart(
                          productDetails?.price?.$numberDecimal,
                          productDetails?._id,
                          productDetails?.productCategory
                        )
                      }
                    >
                      <Cart width="25px" height="21px" fill="#fff" /> Add to
                      cart
                    </CustomButton>
                  </Tooltip>
                )
              ) : (
                <CustomButton dark className="customButton cart black">
                  Out of Stock
                </CustomButton>
              )}
            </div>
            <div className="shippingInfo position-relative d-flex align-items-center">
              <Truck width="57px" height="32px" />
              <p>Get Free ship by 21 Aug, If ordered Before 10:30 PM </p>
            </div>

            <div className="helpUs">
              <ul className="list d-flex justify-content-start">
                <li>
                  <a href="mailto:info@radixdiamond.co">
                    <EmailUs width="20px" height="15px" />
                    <p> Email Us</p>
                  </a>
                </li>
                <li>
                  <a href="tel:+1-800-242-2728">
                    <h4>
                      <HelpImg width="19px" height="19px" /> Need Help ?
                    </h4>
                    <p>+1-800-242-2728</p>
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>

        <div className="diamond-details-wrap">
          <h2>Diamond Details</h2>
          <div className="d-flex">
            <span className="diamond-skeleton">
              <PreviewDummy width="327px" height="299px" />
            </span>
            <ul className="list">
              <li>
                <label>Shape</label>
                <h4>{productDetails?.shapeCut}</h4>
              </li>
              <li>
                <label>Cut</label>
                <h4>{productDetails?.cutGrade}</h4>
              </li>
              <li>
                <label>Color</label>
                <h4>{productDetails?.colorGrade}</h4>
              </li>
              <li>
                <label>Clarity</label>
                <h4>{productDetails?.clarityGrade}</h4>
              </li>
              <li>
                <label>Carat weight</label>
                <h4>{productDetails?.caratWeight?.$numberDecimal}</h4>
              </li>
              <li>
                <label>Depth %</label>
                <h4>{productDetails?.totalDepth}</h4>
              </li>
              <li>
                <label>Table %</label>
                <h4>{productDetails?.tableSize}</h4>
              </li>
              <li>
                <label>Polish</label>
                <h4>{productDetails?.polish}</h4>
              </li>
            </ul>
            <ul className="list">
              <li>
                <label>Girdle</label>
                <h4>{productDetails?.girdleThickness}</h4>
              </li>
              <li>
                <label>Culet</label>
                <h4>{productDetails?.culet}</h4>
              </li>
              <li>
                <label>Measurement</label>
                <h4>{productDetails?.measurements}</h4>
              </li>
              <li>
                <label>Stock Number</label>
                <h4>{productDetails?.suk}</h4>
              </li>
            </ul>
          </div>
        </div>

        <div className="diamond-education-wrap">
          <Nav tabs>
            <NavItem>
              <NavLink
                className={activeTab === "1" ? "active" : ""}
                onClick={() => {
                  toggle("1");
                }}
              >
                Carat Weight
              </NavLink>
            </NavItem>
            <NavItem>
              <NavLink
                className={activeTab === "2" ? "active" : ""}
                onClick={() => {
                  toggle("2");
                }}
              >
                Clarity
              </NavLink>
            </NavItem>
            <NavItem>
              <NavLink
                className={activeTab === "3" ? "active" : ""}
                onClick={() => {
                  toggle("3");
                }}
              >
                Colors
              </NavLink>
            </NavItem>
            <NavItem>
              <NavLink
                className={activeTab === "4" ? "active" : ""}
                onClick={() => {
                  toggle("4");
                }}
              >
                Cut
              </NavLink>
            </NavItem>
          </Nav>
          <TabContent activeTab={activeTab}>
            <TabPane tabId="1">
              <div className="d-flex align-items-center">
                <p>
                  Carat refers to the actual weight of a diamond and is a unit
                  of measure equal to 0.2gm. In all diamonds, size is a large
                  contributor to the price of the stone.
                </p>
                <span>
                  <img
                    className="img-fluid"
                    width={`${Math.floor(20) + 6 * 5}px`}
                    src={`${Diamond}`}
                    alt=""
                  />
                </span>
                <span>
                  <img
                    className="img-fluid"
                    width={`${Math.floor(20) + 7 * 5}px`}
                    src={`${Diamond}`}
                    alt=""
                  />
                </span>
                <span>
                  <img
                    className="img-fluid"
                    width={`${Math.floor(20) + 8 * 5}px`}
                    src={`${Diamond}`}
                    alt=""
                  />
                </span>
                <span>
                  <img
                    className="img-fluid"
                    width={`${Math.floor(20) + 9 * 5}px`}
                    src={`${Diamond}`}
                    alt=""
                  />
                </span>
                <span>
                  <img
                    className="img-fluid"
                    width={`${Math.floor(20) + 10 * 5}px`}
                    src={`${Diamond}`}
                    alt=""
                  />
                </span>
                <span>
                  <img className="img-fluid" src={`${Coin}`} alt="" />
                </span>
              </div>
            </TabPane>
            <TabPane tabId="2">
              <p>
                When we talk about color in diamonds we actually are talking
                about the absence of color. The color of a diamond is graded on
                an alphabetical scale starting at D and ranging all the way down
                to Z with D being a colorless diamond and Z being yellow. The
                yellow in a diamond can actually leach the sunlight and minimize
                the stones light refraction and sparkle.
              </p>
              <div className="d-flex align-items-center">
                <span>
                  <img src={`${DEF}`} alt="" className="img-fluid" />
                  <h6>D E F</h6>
                </span>
                <span>
                  <img src={`${GHIJ}`} alt="" className="img-fluid" />
                  <h6>G H I J</h6>
                </span>
                <span>
                  <img src={`${KLM}`} alt="" className="img-fluid" />
                  <h6>K L M</h6>
                </span>
                <span>
                  <img src={`${NQPR}`} alt="" className="img-fluid" />
                  <h6>N O P Q R</h6>
                </span>
                <span>
                  <img src={`${STUV}`} alt="" className="img-fluid" />
                  <h6>S T U V W X</h6>
                </span>
              </div>
            </TabPane>
            <TabPane tabId="3">
              <div className="d-flex align-items-center">
                <p>
                  Clarity measures the amount of inclusions or imperfections
                  found in a diamond. The best clarity is IF/FL followed by
                  VVS1, VVS2, VS1, VS2, SI1, and SI2. Although other levels of
                  clarity exist, we only carry diamonds with quality we can
                  stand behind.
                </p>
                <div className="d-flex align-items-center">
                  <div className="clarity-inner">
                    <p>IF</p>
                    <p>Internally Flawless</p>
                  </div>
                  <div className="clarity-inner">
                    <p>VVS1-VVS2</p>
                    <p>Ivery very slightly include</p>
                  </div>
                  <div className="clarity-inner">
                    <p>VS1-VS2</p>
                    <p> very slightly include</p>
                  </div>
                  <div className="clarity-inner">
                    <p>SI1-SI2</p>
                    <p> slightly include</p>
                  </div>
                </div>
              </div>
            </TabPane>
            <TabPane tabId="4">
              <div className="d-flex align-items-center">
                <p>
                  The shape of the stone refers to whether the stone is a round
                  cut diamond, princess cut diamond, cushion cut etc. A
                  diamond’s cut is actually an assessment of the skill of the
                  artisan who plans, maps and hand cuts the facets on each
                  individual diamond which is the most important factor in
                  determining its quality in terms of fire, brilliance, and
                  scintillation.
                </p>
                <div className="d-flex align-items-center">
                  <div className="cut-inner">
                    <h6>Ideal</h6>
                    <h6>Excellent</h6>
                    <h6>Very Good</h6>
                    <h6>Good</h6>
                  </div>
                  <span>
                    <img src={`${Dummy}`} alt="" className="img-fluid" />
                  </span>
                </div>
              </div>
            </TabPane>
          </TabContent>
        </div>
      </Container>

      <Help />
      <section className="feel-luxury">
        <Container>
          <div className="feel-luxury-inner">
            <div className="feel-luxury-caption">
              <h2>
                <span>F</span>eel Luxury
              </h2>
              <p>
                Radix Provides you a Real Luxury Experience For Special Family
                members just like you and makes Purchase for specials and more
                Royal{" "}
              </p>
            </div>

            <div className="feel-luxury-img">
              <img className="img-fluid" src={`${LuxuryGift}`} alt="" />
            </div>
          </div>
        </Container>
      </section>
    </ProductDetail>
  );
};

export default LooseDiamondDetail;
