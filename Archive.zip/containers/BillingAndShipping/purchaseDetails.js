import React, { useState } from "react";
import { CustomButton } from "../../css/global";

const PurchaseDetails = (props) => {
  const [tax, setTax] = useState("");
  const [setShippingAmount] = useState("");
  const [total, setTotal] = useState("");
  const [amountTaxes, setAmountTaxes] = useState("");

  new Promise(async (resolve, reject) => {
    try {
      const taxValue = await props.data.tax.$numberDecimal;
      setTax(taxValue);
      const price = props.data.total_amount.$numberDecimal;
      setTotal(price);
      const priceWithoutTax = props.data.amount_wihout_taxes.$numberDecimal;
      setAmountTaxes(priceWithoutTax);
      const shippingValue = await props.data.shipping_amount.$numberDecimal;
      setShippingAmount(shippingValue);
      resolve();
    } catch (error) {
      //   reject("Promise rejected");
    }
  });

  return (
    <div className="orderInfo">
      <ul className="list">
        <li>
          <label>Order Number</label>
          <p>{props.data.order_number}</p>
        </li>
        <li>
          <label>Number of Items</label>
          <p>{props.data.totalQuantity}</p>
        </li>

        <li>
          <label>Amount</label>
          <p>${amountTaxes}</p>
        </li>

        {props.second && (
          <li>
            <label>
              Promo code{" "}
              <strong>
                <em>RADIXFAM21</em>
              </strong>{" "}
              Remove
            </label>
            <p>$90</p>
          </li>
        )}
        {!props.second && (
          <li>
            <label>
              Discount <em>New</em>
            </label>
            <p>$90</p>
          </li>
        )}
        {props.second && (
          <li>
            <label>Shipping Partner</label>
            <p>fedEx priority</p>
          </li>
        )}
        {!props.second && (
          <li>
            <label>
              <em>FedEx Priority</em> Shipping
            </label>
            <p>Free</p>
          </li>
        )}
        <li>
          <label>Taxes</label>
          <p>${tax}</p>
        </li>
        {!props.second && (
          <li>
            <label>Total amount</label>
            <p>${total}</p>
          </li>
        )}
      </ul>
      <CustomButton dark onClick={props.submit}>
        Continue
      </CustomButton>
      <div className="checkout-item">
        <p className="need-help">
          Need Help? <a href="tel:1800-5856-69635">1800-5856-69635</a>
        </p>
      </div>
    </div>
  );
};

export default PurchaseDetails;
