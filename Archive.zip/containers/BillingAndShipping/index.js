import React, { useEffect, useState, useCallback, useRef } from "react";
import { Container, Row, Col, Button } from "reactstrap";
import APIUtil from "../../api";
import { withRouter, useLocation } from "react-router-dom";
import { toast } from "react-toastify";
import BillList from "./billList";
import ShipList from "./shipList";
import PurchaseDetails from "./purchaseDetails";
import BillingAndShippingForm from "./form";
import USP from "../../components/USP";

//css
import { Billing } from "../../css/billing";
import { CustomButton } from "../../css/global";

const api = new APIUtil();

const BillingAndShipping = (props) => {
  const location = useLocation();
  const pageLocation = location.pathname === "/shipping";
  const ref = useRef();
  const [checked, setChecked] = useState(true);
  const [disabled, setDisabled] = useState(true);
  const [addShip, setAddShip] = useState(false);
  const [orderDetail, setOrderDetail] = useState({});
  const [ship, setShip] = useState();
  const [bill, setBill] = useState();

  const [shippingAddress, setShippingAddress] = useState([]);
  const [billingAddress, setBillingAddress] = useState([]);

  const [order, setOrder] = useState();
  const [editBillingForm, setEditBillingForm] = useState({});
  const [displayForm, setDisplayForm] = useState(false);
  const [formType, setFormType] = useState(false);
  const [billingId, setBillingId] = useState("");
  const [shippingId, setShippingId] = useState("");
  const [editingForm, setEditingForm] = useState(true);
  const [phone, setPhone] = useState("");
  const [selectedCountry, setSelectedCountry] = useState("");
  const [selectedRegion, setSelectedRegion] = useState("");

  const orderInformation = useCallback(async () => {
    const token = localStorage.getItem("token");
    const headers = {
      Authorization: `Bearer ${token}`,
    };

    const fetchOrderNumber = await api.get("orders/generateOrderNo", {
      headers,
    });
    setOrder(fetchOrderNumber.data.data);
    await api
      .get(`orders/checkout?order_number=${fetchOrderNumber.data.data}`, {
        headers,
      })
      .then((res) => {
        const data = res.data.data;
        setOrderDetail(data);
      });
  }, []);

  useEffect(() => {
    !props.userProfile && orderInformation();
  }, [orderInformation]);

  //Shipping page select billing and shipping address
  const billingShippingOnSubmit = () => {
    const token = localStorage.getItem("token");
    const headers = {
      Authorization: `Bearer ${token}`,
    };
    const body = {
      order_number: order,
      shipping_id: shippingId,
      billing_id: billingId,
    };
    if(!!order){
    api.post("orders/order_address", body, { headers }).then((res) => {
      props.history.push({
        pathname: `/payment`,
      });
    });
  }else{
    toast.error('Order Number is required')
  }
  };

  const billingOnSubmit = (values) => {
    //return false
    const token = localStorage.getItem("token");
    const headers = {
      Authorization: `Bearer ${token}`,
    };
    if (formType === "edit-billing") {
      api
        .post("address/billingAddressUpdate", values, { headers })
        .then((res) => {
          toast.success(res.data.message);
        })
        .catch((err) => {
          toast.error("Some error occured!");
        });
    } else if (formType === "edit-shipping") {
      api
        .post("address/shippingAddressUpdate", values, { headers })
        .then((res) => {
          toast.success(res.data.message);
          setShip(res.data.data);
        })
        .catch((err) => {
          toast.error("Some error occured!");
        });
    } else if (checked) {
      api.post("address/billingAddress", values, { headers }).then((res) => {
        setBill(res.data.data);
        const bill = res.data.data;
        billIdfetch();
        api.post("address/ShippingAddress", values, { headers }).then((res) => {
          toast.success(res.data.message);
          setShip(res.data.data);
          const ship = res.data.data;
          shipIdFetch();
          const body = {
            order_number: order,
            shipping_id: ship,
            billing_id: bill,
          };
          if (pageLocation) {
            api.post("orders/order_address", body, { headers }).then((res) => {
              props.history.push({
                pathname: `/payment`,
              });
            });
          }
        });
      });
    } else if (!checked && !addShip) {
      api.post("address/billingAddress", values, { headers }).then((res) => {
        toast.success(res.data.message);
        setBill(res.data.data);
        setAddShip(true);
        setBillingId(res.data.data);
        billIdfetch();
      });
    } else if (!checked && addShip) {
      api.post("address/ShippingAddress", values, { headers }).then((res) => {
        toast.success(res.data.message);
        setShip(res.data.data);
        const ship = res.data.data;
        const body = {
          order_number: order,
          shipping_id: ship,
          billing_id: bill,
        };
        api.post("orders/order_address", body, { headers }).then((res) => {
          props.history.push({
            pathname: `/payment`,
          });
        });
      });
    }
  };

  const billIdfetch = () => {
    const myBill = { bill: bill };
    const token = localStorage.getItem("token");
    const headers = {
      Authorization: `Bearer ${token}`,
    };
    api.get(`address/billingAddress`, { headers }).then((res) => {
      setDisabled(false);
      let billingData = Object.values(res.data);
      setBillingAddress(billingData[2]);
    });
  };

  const shipIdFetch = () => {
    const myship = { ship: ship };

    const token = localStorage.getItem("token");
    const headers = {
      Authorization: `Bearer ${token}`,
    };
    api.get(`address/shippingAddress`, { headers }).then((res) => {
      setDisabled(false);
      let shippingData = Object.values(res.data);
      setShippingAddress(shippingData[2]);
    });
  };

  useEffect(() => {
    billIdfetch();
    shipIdFetch();
  }, []);

  const triggerSubmit = () => {
    if (billingId === "" && shippingId == "" || !shippingId) {
      toast.error("Billing and shipping address must required");
    } else {
      billingShippingOnSubmit();
    }
  };

  const editForm = (data, type) => {
    setEditBillingForm(data);
    setDisplayForm(true);
    setFormType(type);
    setEditingForm(false);
    setChecked(false);
  };

  const handleBillingEdit = (e) => {
    setEditBillingForm({ ...editBillingForm, [e.target.name]: e.target.value });
  };

  const addressIds = (type, id) => {
    if (type === "billingId") {
      setBillingId(id);
    }
    if (type === "shippingId") {
      setShippingId(id);
    }
  };

  return (
    <Billing>
      <Container>
        <Row className="flex-nowrap justify-content-around">
          {editingForm && (
            <div className="d-flex flex-wrap pr-5 py-5 mainflex">
              <BillList
                billingAddress={billingAddress}
                addressIds={addressIds}
                billingId={billingId}
                editForm={editForm}
              />
              <ShipList
                shippingAddress={shippingAddress}
                addressIds={addressIds}
                shippingId={shippingId}
                editForm={editForm}
              />

              <div className="address_new_btn">
                <CustomButton
                  dark
                  onClick={() => {
                    editForm("", "add-new");
                  }}
                >
                  Add New
                </CustomButton>

                <CustomButton className="ml-3" onClick={triggerSubmit} dark>
                  Continue
                </CustomButton>
              </div>
            </div>
          )}
          {/* Edit billing form  start */}
          {displayForm && (
            <div className="justify-content-between">
              <div
                className={`billing-shipping-left ${
                  props.userProfile && "expand"
                }`}
              >
                {!props.userProfile && (
                  <div className="mainHeading">
                    <h3 className="title py-3">Billing And Shipping Address</h3>
                  </div>
                )}
                <div className="common-form">
                  <BillingAndShippingForm
                    billingSubmit={billingOnSubmit}
                    handleChange={handleBillingEdit}
                    checked={checked}
                    setEditBillingForm={setEditBillingForm}
                    editBillingForm={editBillingForm}
                    editForm={formType !== "add-new" ? true : false}
                    setChecked={setChecked}
                    setAddShip={setAddShip}
                    setSelectedCountry={setSelectedCountry}
                    setSelectedRegion={setSelectedRegion}
                    selectedCountry={selectedCountry}
                    shipStatus={addShip}
                    setPhone={setPhone}
                    phone={phone}
                    setEditingForm={setEditingForm}
                    setDisplayForm={setDisplayForm}
                    refSubmitButtom={ref}
                    userProfile={props.userProfile}
                    formType={formType}
                    setFormType={setFormType}
                  />
                  {formType === "add-new" && (
                    <div className="checkbox">
                      <input
                        type="checkbox"
                        name="sameaddress"
                        id="sameaddress"
                        onChange={(e) => setChecked(e.target.checked)}
                        checked={checked === true ? checked : false}
                      />
                      <label htmlFor="sameaddress">
                        I have same Shipping Address
                      </label>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
          {/* Edit billing form  end */}
          {pageLocation && (
            <div className="justify-content-between">
              {!props.userProfile && (
                <div
                  className={
                    billingAddress && billingAddress.length === 0
                      ? `billing-shipping-right`
                      : `billing-shipping-purchase`
                  }
                >
                  <div className="checkout-div">
                    <PurchaseDetails
                      data={orderDetail}
                      submit={triggerSubmit}
                    />
                  </div>
                </div>
              )}
            </div>
          )}
        </Row>
      </Container>
      {!props.userProfile && (
        <>
          <USP />
          <section className="shipping-order-info">
            <Container>
              <Row>
                <Col md={6}>
                  <div className="information shipping-info">
                    <h4>Shipping Information</h4>
                    <p>Estimated arrival 1-6 days</p>
                    <p>
                      <span>By FedEx Ground Shipping</span>
                    </p>

                    <h4>Contact Details</h4>
                    <p className="need-help-bottom">
                      Need any help ? call our customer service at
                      <br /> <a href="tel:1800-5856-69635">1800-5856-69635</a>
                    </p>
                  </div>
                </Col>

                <Col md={6}>
                  <div className="information order-info">
                    <h4>Order information</h4>
                    <PurchaseDetails data={orderDetail} second />
                  </div>
                </Col>
              </Row>
            </Container>
          </section>
        </>
      )}
    </Billing>
  );
};

export default withRouter(BillingAndShipping);
