import React, { useState } from "react";
import { useForm, Controller } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as Yup from "yup";
import { Form } from "reactstrap";
import "react-phone-number-input/style.css";
import PhoneInput from "react-phone-number-input";
import { CountryDropdown, RegionDropdown } from "react-country-region-selector";

//css
import { CustomButton } from "../../css/global";
import { useSelector } from "react-redux";

const BillingAndShippingForm = (props) => {
  const userValues = useSelector((val) => val.auth.user);
  const [values, setValues] = useState({
    first_name: userValues.first_name,
    last_name: userValues.last_name,
    email: userValues.email,
  });
  const [country, setCountry] = useState(
    props.editBillingForm?.country ? props.editBillingForm.country : ""
  );
  const [province, setProvince] = useState(
    props.editBillingForm?.state ? props.editBillingForm.state : ""
  );

  // Validations
  const validationSchema = Yup.object().shape({
    first_name: Yup.string()
      .required("Required")
      .min(2, "Too Short!")
      .max(50, "Too Long!"),
    last_name: Yup.string()
      .required("Required")
      .min(2, "Too Short!")
      .max(50, "Too Long!"),
    email: Yup.string().email("Invalid email").required("Required"),
    phone: Yup.string().required("Required"),
    zip_code: Yup.string().required("Required"),
    street_address: Yup.string().required("Required"),
    address_type: Yup.string().required("Please select one value."),
    city: Yup.string().required("Required!"),
    state: Yup.string().required("Required!"),
    country: Yup.string().required("Required!"),
  });

  const { register, errors, handleSubmit, control } = useForm({
    resolver: yupResolver(validationSchema),
    defaultValues: {
      country: props.editBillingForm?.country
        ? props.editBillingForm.country
        : "",
      state: props.editBillingForm?.state ? props.editBillingForm.state : "",
      phone: props.editBillingForm?.phone
        ? props.editBillingForm?.phone.toString()
        : "",
    },
  });

  const onSubmit = async (data, e) => {
    if (props.editForm) {
      props.billingSubmit(data);
    } else {
      if (!props.checked && !props.shipStatus) {
        props.billingSubmit(data);
      } else if (!props.checked && props.shipStatus) {
        props.setChecked(false);
        props.billingSubmit(data);
      } else {
        props.billingSubmit(data);
      }
    }
    // props.setEditingForm(true);
  };

  const onChange = (e) => {
    const init = e.target.value;
    setValues({
      ...values,
      [e.target.name]: init,
    });
  };
  return (
    <>
      <div className="d-flex align-items-center justify-content-between">
        {props.formType === "edit-billing" && !props.checked && (
          <h4> Billing Address</h4>
        )}
        {props.formType === "edit-shipping" && !props.checked && (
          <h4> Shipping Address</h4>
        )}

        {props.formType === "add-new" && props.checked && !props.shipStatus ? (
          <h4>Billing Address - Shipping Address</h4>
        ) : !props.checked && props.shipStatus ? (
          <h4>Shipping Address</h4>
        ) : (
          props.formType !== "edit-billing" &&
          props.formType !== "edit-shipping" &&
          !props.shipStatus && <h4> Billing Address</h4>
        )}

        <h6
          onClick={() => {
            props.setEditingForm(true);
            props.setFormType(!props.formType);
            props.setDisplayForm(false);
            props.setChecked(!props.checked);
          }}
        >
          Go Back
        </h6>
      </div>
      <Form
        id="billandship"
        className="form-container"
        onSubmit={handleSubmit(onSubmit)}
        noValidate
        autoComplete="off"
      >
        <div className="row">
          <div className="form-group col-lg-6">
            <input
              type="text"
              name="first_name"
              ref={register}
              placeholder="First Name"
              className="form-control"
              value={
                props.editBillingForm?.first_name
                  ? props.editBillingForm?.first_name
                  : values.first_name
              }
              onChange={(e) =>
                props.editBillingForm?.first_name
                  ? props.handleChange(e)
                  : onChange(e)
              }
            />
            {errors.first_name && (
              <span className="errorMessage">{errors.first_name.message}</span>
            )}
          </div>

          <div className="form-group col-lg-6">
            <input
              type="text"
              name="last_name"
              ref={register}
              placeholder="Last Name"
              className="form-control"
              value={
                props.editBillingForm?.last_name
                  ? props.editBillingForm?.last_name
                  : values.last_name
              }
              onChange={(e) =>
                props.editBillingForm?.last_name
                  ? props.handleChange(e)
                  : onChange(e)
              }
            />
            {errors.last_name && (
              <span className="errorMessage">{errors.last_name.message}</span>
            )}
          </div>

          <div className="form-group col-lg-6">
            <input
              type="email"
              name="email"
              ref={register}
              placeholder="Email"
              className="form-control"
              value={
                props.editBillingForm?.email
                  ? props.editBillingForm?.email
                  : values.email
              }
              onChange={(e) =>
                props.editBillingForm?.email
                  ? props.handleChange(e)
                  : onChange(e)
              }
            />
            {errors.email && (
              <span className="errorMessage">{errors.email.message}</span>
            )}
          </div>

          <div className="form-group col-lg-6">
            <Controller
              name="phone"
              control={control}
              value={
                props.editBillingForm?.phone
                  ? props.editBillingForm?.phone.toString()
                  : props.phone
              }
              onChange={(value) => {
                props.editBillingForm?.phone
                  ? props.setEditBillingForm((prevState) => {
                      return { ...prevState, value };
                    })
                  : props.setPhone(value);
              }}
              render={(props) => {
                return (
                  <PhoneInput
                    placeholder="Phone number"
                    className="form-control"
                    value={props.value}
                    onChange={props.onChange}
                  />
                );
              }}
            />
            {errors.phone && (
              <span className="errorMessage">{errors.phone.message}</span>
            )}
          </div>

          <div className="form-group col-lg-6">
            <input
              type="number"
              name="zip_code"
              onChange={(e) => props.handleChange(e)}
              ref={register}
              placeholder="Zip code"
              value={props.editBillingForm?.zip_code}
              className="form-control"
            />
            {errors.zip_code && (
              <span className="errorMessage">{errors.zip_code.message}</span>
            )}
          </div>

          <div className="form-group col-lg-6 select-container">
            <Controller
              name="country"
              control={control}
              value={country}
              render={(props) => {
                return (
                  <CountryDropdown
                    value={props.value}
                    className="form-control"
                    onChange={(value) => {
                      props.onChange(value);
                      setCountry(value);
                    }}
                  />
                );
              }}
            />
            {errors.country && (
              <span className="errorMessage">{errors.country.message}</span>
            )}
          </div>

          <div className="form-group col-lg-6 select-container">
            <Controller
              name="state"
              control={control}
              value={province}
              render={(props) => {
                return (
                  <RegionDropdown
                    country={country}
                    value={props.value}
                    blankOptionLabel="State"
                    defaultOptionLabel="State"
                    className="form-control"
                    onChange={(value) => {
                      props.onChange(value);
                      setProvince(value);
                    }}
                  />
                );
              }}
            />

            {errors.state && (
              <span className="errorMessage">{errors.state.message}</span>
            )}
          </div>

          <div className="form-group col-lg-6 select-container">
            <input
              type="text"
              className="form-control"
              name="city"
              ref={register}
              placeholder="Enter City"
              onChange={(e) => props.handleChange(e)}
              value={
                props.editBillingForm?.city
                  ? props.editBillingForm?.city
                  : values.city
              }
            />
            {errors.city && (
              <span className="errorMessage">{errors.city.message}</span>
            )}
          </div>

          <div className="form-group col-lg-12">
            <input
              type="text"
              onChange={(e) => props.handleChange(e)}
              value={props.editBillingForm?.street_address}
              name="street_address"
              placeholder="Street Address"
              className="form-control"
              ref={register}
            />
            {errors.street_address && (
              <span className="errorMessage">
                {errors.street_address.message}
              </span>
            )}
          </div>

          <div className="form-group col-lg-12">
            <label>Address type</label>
            <div className="radio-btn">
              <input
                onChange={(e) => props.handleChange(e)}
                type="radio"
                checked={
                  props.editBillingForm?.address_type === "home" ? true : false
                }
                ref={register}
                name="address_type"
                id="home"
                value="home"
              />
              <label htmlFor="home">Home</label>
            </div>

            <div className="radio-btn">
              <input
                onChange={(e) => props.handleChange(e)}
                checked={
                  props.editBillingForm?.address_type === "office"
                    ? true
                    : false
                }
                type="radio"
                name="address_type"
                ref={register}
                id="office"
                value="office"
              />
              <label htmlFor="office">Office</label>
            </div>
            {errors.address_type && (
              <span className="errorMessage">
                <span className="errorMessage">Please select one value</span>
              </span>
            )}
          </div>
          {!!props.editBillingForm ? (
            <div className="form-group col-lg-12">
              <CustomButton dark type="submit">
                Submit
              </CustomButton>
            </div>
          ) : (
            <div className="form-group col-lg-12">
              {!props.checked && !props.shipStatus ? (
                <CustomButton dark>Continue</CustomButton>
              ) : (
                <CustomButton dark ref={props.refSubmitButtom} type="submit">
                  Proceed to pay
                </CustomButton>
              )}
            </div>
          )}
        </div>
      </Form>
    </>
  );
};

export default BillingAndShippingForm;
