import React from "react";

//images
import { ReactComponent as Edit } from "../../assets/images/account/edit-1.svg";

const ShipList = (props) => {
  return (
    <div className="billing-shipping-div">
      <div className="mainHeading">
        <h3 className="title py-3">Shipping Address</h3>
      </div>
      <div className="common-form">
        {props.shippingAddress?.length > 0
          ? props.shippingAddress?.map((item, i) => (
              <div
                key={i}
                onClick={() => props.addressIds("shippingId", item._id)}
                className={
                  item._id === props.shippingId
                    ? `billingDiv col-lg-12 active`
                    : `billingDiv col-lg-12`
                }
              >
                <div className="d-flex">
                  <div className="userName billData col-lg-6">
                    <h5>{`${item.first_name} ${item.last_name}  `}</h5>
                  </div>
                  <div className="billIcon billData col-lg-6">
                    <Edit
                      onClick={() => {
                        props.editForm(item, "edit-shipping");
                      }}
                      width="25px"
                      height="22px"
                    />
                  </div>
                </div>
                <div className="d-flex">
                  <div className="billData col-lg-6">
                    {`${item.address_type}, ${item.street_address} `}
                    {`${item.city}, ${item.state} ${item.zip_code} ${item.country} ${item.zip_code}`}
                  </div>
                  <div className="billData col-lg-6">
                    <a href={`mailto:${item.email}`}>{`${item.email}`}</a>
                    <p>{`${item.phone}`}</p>
                  </div>
                </div>
              </div>
            ))
          : "No Addresses"}
      </div>
    </div>
  );
};

export default ShipList;
