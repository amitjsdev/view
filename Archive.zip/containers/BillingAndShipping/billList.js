import React from "react";

//images
import { ReactComponent as Edit } from "../../assets/images/account/edit-1.svg";

const BillList = (props) => {
  return (
    <div className="billing-shipping-div">
      <div className="mainHeading">
        <h3 className="title py-3">Billing Address</h3>
      </div>
      <div className="common-form">
        {props.billingAddress?.length > 0
          ? props.billingAddress?.map((item, i) => (
              <div
                onClick={() => props.addressIds("billingId", item._id)}
                className={
                  item._id === props.billingId
                    ? `billingDiv active`
                    : `billingDiv`
                }
                key={i}
              >
                <div className="d-flex">
                  <div className="userName billData col-lg-6">
                    <h5>{`${item.first_name} ${item.last_name}`}</h5>
                  </div>
                  <div className="billIcon billData col-lg-6">
                    <Edit
                      onClick={() => {
                        props.editForm(item, "edit-billing");
                      }}
                      width="25px"
                      height="22px"
                    />
                  </div>
                </div>
                <div className="d-flex">
                  <div className="billData col-lg-6">
                    {`${item.address_type}, ${item.street_address} `}
                    {`${item.city}, ${item.state} ${item.zip_code} ${item.country} ${item.zip_code}`}
                  </div>
                  <div className="billData col-lg-6">
                    <p>
                      <a href={`mailto:${item.email}`}>{`${item.email}`}</a>
                    </p>
                    <p>
                      <a href={`tel:${item.phone}`}>{`${item.phone}`}</a>
                    </p>
                  </div>
                </div>
              </div>
            ))
          : "No Addresses"}
      </div>
    </div>
  );
};

export default BillList;
