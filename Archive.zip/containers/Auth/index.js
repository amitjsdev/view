import React, { useState } from "react";
import { useHistory, Redirect } from "react-router-dom";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import { useDispatch, connect } from "react-redux";
import { Col, Container, Form, FormGroup, Label, Row } from "reactstrap";
import * as Yup from "yup";
import * as actions from "../../store/actions/index";
import Benefits from "./Benefits";
import ForgotPassword from "../../components/ForgotPassword";
import APIUtil from "../../api";
import { toast } from "react-toastify";
//css
import { LoginWrap } from "../../css/login";
import { CustomButton } from "../../css/global";

// images
// import { ReactComponent as Fb } from "../../assets/images/fb.svg";
// import { ReactComponent as Twitter } from "../../assets/images/twitter.svg";
// import { ReactComponent as Google } from "../../assets/images/google.svg";

const api = new APIUtil();

const validationSchema = Yup.object().shape({
  email: Yup.string().required("Email is required").email("Email is invalid"),
  password: Yup.string()
    .required("Password is required")
    .matches(
      /^(?=.*[A-Za-z])(?=.*\d)(?=.*[!"#$%&'()*+,-./:;<=>?@[\]^_`{|}~])[A-Za-z\d!"#$%&'()*+,-./:;<=>?@[\]^_`{|}~]{8,}$/,
      "Password must contain one capital letter, one number, one special character and atleast eight characters."
    ),
});

const Auth = (props) => {
  const dispatch = useDispatch();
  const history = useHistory();

  //State
  const [forget, setForget] = useState(false);

  const { register, errors, handleSubmit, formState } = useForm({
    resolver: yupResolver(validationSchema),
    mode: "onChange",
  });

  // onSubmit
  const onSubmit = async (data) => {
    dispatch(actions.auth(data));
  };

  // redirection after login successfull
  if (props.isAuthenticated) {
    return <Redirect to="/" />;
  }

  // redirection to register form
  const redirect = () => {
    history.push("/register");
  };

  // Forgot password toggle
  const forgetHandle = () => {
    setForget(!forget);
  };

  // Forgot password HTTP request
  const forgotHandle = async (data) => {
    await api
      .post("users/forgetPassword", data)
      .then((response) => {
        if (response.data.message === "No user found.") {
          toast.error("No user Found!");
        } else {
          toast.success(response.data.message);
          setForget(!forget);
        }
      })
      .catch((error) => {
        if (error.response) {
          toast.error("incorrect email");
        }
      });
  };

  return (
    <LoginWrap>
      <Container>
        <Row className="justify-content-between">
          <Col md={6} className="form">
            <div className="formWrap">
              {!forget ? (
                <>
                  <h2>Sign In</h2>
                  <Form
                    onSubmit={handleSubmit(onSubmit)}
                    noValidate
                    autoComplete="off"
                  >
                    <FormGroup className="email">
                      <Label>Email</Label>
                      <div className="icon"></div>
                      <input type="email" name="email" ref={register} />
                      {errors.email && (
                        <span className="errorMessage">
                          {errors.email.message}
                        </span>
                      )}
                    </FormGroup>
                    <FormGroup className="pass">
                      <Label>Password</Label>
                      <div className="icon"></div>

                      <input type="password" name="password" ref={register} />
                      {errors.password && (
                        <span className="errorMessage">
                          {errors.password.message}
                        </span>
                      )}
                    </FormGroup>
                    <FormGroup className="forget" onClick={forgetHandle}>
                      Forgot Password?
                    </FormGroup>
                    <div className="d-flex justify-content-between">
                      <CustomButton
                        dark
                        type="submit"
                        disabled={!formState.isValid}
                      >
                        Sign In
                      </CustomButton>
                      {/* <ul className="list d-flex">
                        <li>
                          <Fb width="51px" height="51px" />{" "}
                        </li>
                        <li>
                          <Twitter width="51px" height="51px" />{" "}
                        </li>
                        <li>
                          <Google width="51px" height="51px" />{" "}
                        </li>
                      </ul> */}
                    </div>
                  </Form>

                  <p>
                    Enjoy additional benefits when you become a Radix member.
                  </p>
                  <h6>Not a member yet?</h6>
                  <button className="newAccount" onClick={redirect}>
                    Create New Account
                  </button>
                </>
              ) : (
                <ForgotPassword
                  forgotHandle={forgotHandle}
                  forgotToggle={forgetHandle}
                />
              )}
            </div>
          </Col>
          <Col md={5}>
            <Benefits />
          </Col>
        </Row>
      </Container>
    </LoginWrap>
  );
};

const mapStateToProps = (state) => {
  return {
    isAuthenticated: state.auth.token !== null,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    onError: () => dispatch(actions.authFail()),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(Auth);
