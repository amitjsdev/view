import React, { useState, useEffect } from "react";
import { Link, useParams } from "react-router-dom";
import { Formik, Field, Form, ErrorMessage } from "formik";
import * as Yup from "yup";
import APIUtil from "../../../api";
import { toast } from "react-toastify";
import { Col, Container, Row } from "reactstrap";
import { LoginWrap } from "../../../css/login";
import Benefits from "../Benefits";
import { CustomButton } from "../../../css/global";

const api = new APIUtil();

function ForgotPassword({ history }) {
  const TokenStatus = {
    Validating: "Validating",
    Valid: "Valid",
    Invalid: "Invalid",
  };

  const [token, setToken] = useState(null);
  const [tokenStatus, setTokenStatus] = useState(TokenStatus.Validating);
  const [loading, setLoading] = useState(true);
  let params = useParams();

  useEffect(() => {
    const validateToken = async () => {
      const token = params.userId;

      await api
        .get(`users/verifyToken/${token}`)
        .then((response) => {
          setToken(token);
          setTokenStatus(TokenStatus.Valid);
          setLoading(false);
        })
        .catch(() => {
          setTokenStatus(TokenStatus.Invalid);
          setLoading(false);
        });
    };
    validateToken();
  }, []);

  function getForm() {
    const initialValues = {
      password: "",
      confirmPassword: "",
    };

    const validationSchema = Yup.object().shape({
      password: Yup.string()
        .max(20, "Password must not be more than 20 characters")
        .matches(
          /^(?=.*[A-Za-z])(?=.*\d)(?=.*[!"#$%&'()*+,-./:;<=>?@[\]^_`{|}~])[A-Za-z\d!"#$%&'()*+,-./:;<=>?@[\]^_`{|}~]{8,}$/
        )
        .required("Password is required"),
      confirmPassword: Yup.string()
        .oneOf([Yup.ref("password"), null], "Passwords don't match")
        .required("Confirm password is required"),
    });

    const onSubmit = (values, { setSubmitting }) => {
      const data = {
        ...values,
        // token: token,
      };

      const headers = {
        Authorization: `Bearer ${token}`,
      };
      api
        .post(`users/resetPassword`, data, {
          headers: headers,
        })
        .then(() => {
          toast.success("Password has been changed successfully.", {
            keepAfterRouteChange: true,
          });
          history.push("/login");
        })
        .catch((error) => {
          setSubmitting(false);
          toast.error(error);
        });
    };
    const validationMsg =
      "Password must be at least 8 characters and should contain at least one letter, one number and one special character.";
    return (
      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        onSubmit={onSubmit}
      >
        {({ errors, touched, isSubmitting }) => (
          <Form>
            <div className="form-group">
              <label>Password</label>
              <Field
                name="password"
                type="password"
                className={
                  "form-control" +
                  (errors.password && touched.password ? " is-invalid" : "")
                }
              />
              <ErrorMessage
                name="password"
                render={() => (
                  <div className="invalid-feedback">{validationMsg}</div>
                )}
              />
            </div>
            <div className="form-group">
              <label>Confirm Password</label>
              <Field
                name="confirmPassword"
                type="password"
                className={
                  "form-control" +
                  (errors.confirmPassword && touched.confirmPassword
                    ? " is-invalid"
                    : "")
                }
              />
              <ErrorMessage
                name="confirmPassword"
                component="div"
                className="invalid-feedback"
              />
            </div>
            <div className="form-row">
              <div className="form-group col">
                <CustomButton dark type="submit" disabled={isSubmitting}>
                  {isSubmitting && (
                    <span className="spinner-border spinner-border-sm mr-1"></span>
                  )}
                  Submit
                </CustomButton>
                <Link to="/login" className="btn btn-link">
                  Cancel
                </Link>
              </div>
            </div>
          </Form>
        )}
      </Formik>
    );
  }

  function getBody() {
    switch (tokenStatus) {
      case loading:
        return loading();
      case TokenStatus.Valid:
        return getForm();
      case TokenStatus.Invalid:
        return (
          <div>
            Token validation failed, your token has expired. Go back to{" "}
            <Link to="/login">login</Link> page.
          </div>
        );
      case TokenStatus.Validating:
        return <div>Validating token...</div>;
      default:
    }
  }

  return (
    <LoginWrap>
      <Container>
        <Row className="justify-content-between">
          <Col md={6} className="form">
            <div className="formWrap">
              <h2>Reset Password</h2>
              <div>{getBody()}</div>
            </div>
          </Col>
          <Col md={5}>
            <Benefits />
          </Col>
        </Row>
      </Container>
    </LoginWrap>
  );
}

export default ForgotPassword;
