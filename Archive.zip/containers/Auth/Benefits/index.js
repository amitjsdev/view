import React from "react";

import { ReactComponent as Icon1 } from "../../../assets/images/signup/history.svg";
import { ReactComponent as Icon2 } from "../../../assets/images/signup/shopping-cart.svg";
import { ReactComponent as Icon3 } from "../../../assets/images/signup/gift.svg";
import { ReactComponent as Icon4 } from "../../../assets/images/signup/gdpr.svg";
import { ReactComponent as Icon5 } from "../../../assets/images/signup/transfer.svg";
import { ReactComponent as Icon6 } from "../../../assets/images/signup/money-bag-of-dollars.svg";
import { ReactComponent as Icon7 } from "../../../assets/images/signup/quality.svg";

export default function Benefits() {
  return (
    <div className="benefits">
      <h2>Benefits of becoming a member</h2>
      <ul className="list">
        <li>
          <Icon1 width="26px" height="23px" />
          <p>East access to order history, saved items and more.</p>
        </li>
        <li>
          <Icon2 width="20px" height="20px" />
          <p>Faster checkout with stored shipping and billing information.</p>
        </li>
        <li>
          {" "}
          <Icon3 width="21px" height="21.68px" />
          <p>Exclusive offers,discounts, and shipping upgrades.</p>
        </li>
        <li>
          <Icon4 width="28px" height="28px" />
          <p>
            With a Radix account, you can save time during checkout, access your
            shopping bag from any device and view your order history.
          </p>
        </li>
        <li>
          <Icon5 width="24px" height="24px" />
          <p>Receive 1.5% discount when paying by bank wire transfer.</p>
        </li>
        <li>
          <Icon6 width="21px" height="25px" />
          <p>100 Points Registration Bonus.</p>
        </li>
        <li>
          <Icon7 width="21px" height="22px" />
          <p>Accumulate points on every purchase</p>
        </li>
      </ul>
    </div>
  );
}
