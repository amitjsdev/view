import React from "react";
import { Col, Container, Form, FormGroup, Label, Row } from "reactstrap";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import { useDispatch } from "react-redux";
import * as Yup from "yup";
import * as actions from "../../../store/actions/index";
import Benefits from "../Benefits";

//css
import { CustomButton } from "../../../css/global";
import { LoginWrap } from "../../../css/login";
// Images
// import { ReactComponent as Fb } from "../../../assets/images/fb.svg";
// import { ReactComponent as Twitter } from "../../../assets/images/twitter.svg";
// import { ReactComponent as Google } from "../../../assets/images/google.svg";

const validationSchema = Yup.object().shape({
  firstName: Yup.string()
    .required("First Name is required")
    .min(2, "First Name must have more than 2 character")
    .max(20, "Maximun letters reached")
    .test("alphabets", "First Name must only contain alphabets", (value) => {
      return /^[A-Za-z]+$/.test(value);
    }),
  lastName: Yup.string()
    .required("Last Name is required")
    .min(2, "Minimun two letters")
    .max(20, "Maximun letters reached")
    .test("alphabets", "Last Name must only contain alphabets", (value) => {
      return /^[A-Za-z]+$/.test(value);
    }),
  email: Yup.string().required("Email is required").email("Email is invalid"),
  password: Yup.string()
    .required("Password is required")
    .matches(
      /^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/,
      "Password must contain one capital letter, one number, one special character and atleast eight characters."
    ),
  confirmPassword: Yup.string()
    .oneOf([Yup.ref("password"), null], "Passwords must match")
    .required("Confirm Password is required"),
  gender: Yup.string().min(1, "Please Select one value."),
});

const Register = (props) => {
  const dispatch = useDispatch();

  const { register, errors, handleSubmit, reset } = useForm({
    resolver: yupResolver(validationSchema),
  });

  // onSubmit
  const onSubmit = async (data) => {
    const body = {
      first_name: data.firstName,
      last_name: data.lastName,
      email: data.email,
      role_id: 2,
      gender: data.gender,
      password: data.password,
    };
    dispatch(actions.createForm(body));
  };

  return (
    <LoginWrap>
      <Container>
        <Row className="justify-content-between">
          <Col md={6} className="form register">
            <div className="formWrap">
              <h2>Create Your Account</h2>
              <Form
                onSubmit={handleSubmit(onSubmit)}
                noValidate
                autoComplete="off"
              >
                <FormGroup className="email">
                  <Label>
                    First Name <span>*</span>
                  </Label>
                  <div className="icon"></div>

                  <input type="text" name="firstName" ref={register} />
                  {errors.firstName && (
                    <span className="errorMessage">
                      {errors.firstName.message}
                    </span>
                  )}
                </FormGroup>
                <FormGroup className="email">
                  <Label>
                    Last Name <span>*</span>
                  </Label>
                  <div className="icon"></div>

                  <input type="text" name="lastName" ref={register} />
                  {errors.lastName && (
                    <span className="errorMessage">
                      {errors.lastName.message}
                    </span>
                  )}
                </FormGroup>
                <FormGroup className="my-4">
                  <Label className="d-flex">
                    Gender <span>*</span>
                    <FormGroup check>
                      <Label check className="d-flex">
                        <input
                          name="gender"
                          value="Male"
                          ref={register}
                          type="radio"
                        />
                        <span></span>
                        Male
                      </Label>
                    </FormGroup>
                    <FormGroup check>
                      <Label check className="d-flex">
                        <input
                          name="gender"
                          value="Female"
                          ref={register}
                          type="radio"
                        />
                        <span></span>
                        Female
                      </Label>
                    </FormGroup>
                    <FormGroup check>
                      <Label check className="d-flex">
                        <input
                          name="gender"
                          value="Others"
                          ref={register}
                          type="radio"
                        />
                        <span></span>
                        Others
                      </Label>
                    </FormGroup>
                  </Label>
                  {errors.gender && (
                    <span className="errorMessage">
                      Please select one value
                    </span>
                  )}
                </FormGroup>

                <FormGroup className="email">
                  <Label>
                    Email <span>*</span>
                  </Label>
                  <div className="icon"></div>

                  <input type="email" name="email" ref={register} />
                  {errors.email && (
                    <span className="errorMessage">{errors.email.message}</span>
                  )}
                </FormGroup>
                <Row>
                  <Col md={6}>
                    <FormGroup className="pass">
                      <Label>
                        Password <span>*</span>
                      </Label>
                      <div className="icon"></div>

                      <input type="password" name="password" ref={register} />
                      {errors.password && (
                        <span className="errorMessage">
                          {errors.password.message}
                        </span>
                      )}
                    </FormGroup>
                  </Col>
                  <Col md={6}>
                    <FormGroup className="pass">
                      <Label>
                        Confirm Password <span>*</span>
                      </Label>
                      <div className="icon"></div>

                      <input
                        type="password"
                        name="confirmPassword"
                        ref={register}
                      />
                      {errors.confirmPassword && (
                        <span className="errorMessage">
                          {errors.confirmPassword.message}
                        </span>
                      )}
                    </FormGroup>
                  </Col>
                </Row>

                <div className="d-flex justify-content-between pt-5">
                  <CustomButton dark type="submit">
                    Sign Up
                  </CustomButton>
                  {/* <ul className="list d-flex">
                    <li>
                      <Fb width="51px" height="51px" />{" "}
                    </li>
                    <li>
                      <Twitter width="51px" height="51px" />{" "}
                    </li>
                    <li>
                      <Google width="51px" height="51px" />{" "}
                    </li>
                  </ul> */}
                </div>
              </Form>
            </div>
          </Col>
          <Col md={5}>
            <Benefits />
          </Col>
        </Row>
      </Container>
    </LoginWrap>
  );
};

export default Register;
