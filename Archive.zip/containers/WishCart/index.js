import React, { useContext, useEffect, useState } from "react";
import { Container } from "reactstrap";
import { CartContext } from "../../context/CartContext";
import APIUtil from "../../api";
import { UserDetails } from "../../constant";
import Explore from "../../components/Explore";
// css
import { Wishlist } from "../../css/cart";
import { CustomButton } from "../../css/global";
//images
import { ReactComponent as Dustbin } from "../../assets/images/dustbin.svg";
import { ReactComponent as EmptyWish } from "../../assets/images/emptywish.svg";

const api = new APIUtil();

function WishCarts(props) {
  var userId = UserDetails();
  const [load, setLoad] = useState(false);
  const {
    wishLists,
    wishProduct,
    addProduct,
    wishListId,
    cartListId,
    wishListIdDel,
  } = useContext(CartContext);

  const isInCart = (id) => {
    if (cartListId.includes(id)) {
      return true;
    } else {
      return false;
    }
  };

  const addedToCart = async (price, id, category) => {
    if (isInCart(id)) {
      const del_data = {
        userId: userId._id.toString(),
        productId: id,
        productCategory: category,
      };

      await api.post("products/delWishlist", del_data).then((response) => {
        const filter = wishListId.filter(function (data) {
          return data !== id;
        });
        wishListIdDel(filter);
      });
      setLoad(!load);
    } else if (!isInCart(id)) {
      const body = {
        userId: userId._id.toString(),
        quantity: 1,
        price: price,
        productCategory: category,
        productId: id,
      };

      await api.post("products/addCart", body).then((response) => {});
      const del_data = {
        userId: userId._id.toString(),
        productId: id,
        productCategory: category,
      };
      await api.post("products/delWishlist", del_data).then((response) => {
        const filter = wishListId.filter(function (data) {
          return data !== id;
        });
        wishListIdDel(filter);
      });

      setLoad(!load);
    }
  };

  useEffect(() => {
    addProduct(userId._id.toString());
    wishProduct(userId._id.toString());
  }, [load]);

  const cartRemove = async (id, category) => {
    const del_data = {
      userId: userId._id.toString(),
      productId: id,
      productCategory: category,
    };

    await api.post("products/delWishlist", del_data).then((response) => {
      if (wishListId.includes(id)) {
        const filter = wishListId.filter(function (data) {
          return data !== id;
        });
        wishListIdDel(filter);
      }
    });
    setLoad(!load);
  };

  const addToCartButton = () => {
    return wishListId?.status !== 2 ? (
      !isInCart(wishListId?._id) && (
        <CustomButton
          light
          onClick={() =>
            addedToCart(
              wishListId?.price
                ? wishListId?.price.$numberDecimal
                  ? wishListId?.price.$numberDecimal
                  : wishListId?.price
                : wishListId?.totalPrice.$numberDecimal,
              wishListId?._id,
              wishListId?.productCategory
            )
          }
        >
          Add to cart
        </CustomButton>
      )
    ) : (
      <h2 className="out">Out of Stock</h2>
    );
  };

  const wishList = () => {
    return wishLists.map((val, index) => {
      let wishListId = {};
      let wishListImg = {};

      switch (val.productCategory) {
        case 1:
          wishListId = val.studId;
          break;
        case 2:
          wishListId = val.hoopsId;
          break;
        case 3:
          wishListId = val.dropsId;
          break;
        case 4:
          wishListId = val.fashionId;
          break;
        case 5:
          wishListId = val.looseDiamondId;
          break;
        case 6:
          wishListId = val.engagementRingId;
          break;
        default:
      }

      switch (val.productCategory) {
        case 1:
          wishListImg = wishListId?.images.studsImages;
          break;
        case 2:
          wishListImg = wishListId?.images.hoopsImages;
          break;
        case 3:
          wishListImg = wishListId?.images.dropsImages;
          break;
        case 4:
          wishListImg = wishListId?.images.fashionImages;
          break;
        case 5:
          wishListImg = wishListId?.images.diamondImages;
          break;
        case 6:
          wishListImg = wishListId?.images.productsPreviewImages;
          break;
        default:
      }
      return (
        <div
          className={`list position-relative d-flex flex-wrap ${
            wishListId?.status === 2 && "outof_stock"
          }`}
          key={index}
        >
          {isInCart(wishListId?._id) && <h6>Already in Cart</h6>}

          <div className="wishInfo">
            <span>
              {wishListImg?.map((image, index) => {
                return (
                  <img
                    style={{ width: 100, height: 75 }}
                    key={index}
                    src={image}
                    alt=""
                  />
                );
              })}
            </span>
            <h3>{wishListId?.suk}</h3>
            <h4>
              {wishListId?.name
                ? wishListId?.name
                : `${wishListId?.caratWeight?.$numberDecimal} - Carat ${wishListId?.shapeCut} Shaped Diamond`}
            </h4>

            {wishListId?.status !== 2 && (
              <h5>{`$${
                wishListId?.price
                  ? wishListId?.price.$numberDecimal
                    ? wishListId?.price.$numberDecimal
                    : wishListId?.price
                  : wishListId?.totalPrice.$numberDecimal
              }`}</h5>
            )}
          </div>
          <div className="d-flex align-items-center out justify-content-center w-100">
            <>
              <span
                onClick={(e) =>
                  cartRemove(wishListId?._id, wishListId?.productCategory)
                }
              >
                <Dustbin width="16px" height="19px" />
              </span>
              {wishListId.productCategory !== 6 ? addToCartButton() : ""}
            </>
          </div>
        </div>
      );
    });
  };

  return (
    <Wishlist>
      <Container>
        <div className="mainHeading">
          <h3 className="title pt-4"> My Wishlist</h3>
        </div>
        <div
          className={`d-grid grid-template-res pt-5 ${
            wishLists.length !== 0 ? "" : "empty"
          }`}
        >
          <h2 className="head">My Wishlist</h2>
          {wishLists.length !== 0 ? (
            wishList()
          ) : (
            <div className="empty-wish d-flex align-items-center">
              <span>
                <EmptyWish width="82.5px" height="98px" />
              </span>
              <div>
                <h4> Your Wish list is empty </h4>
                <p>Explore more and shortlist Products </p>
              </div>
            </div>
          )}
        </div>
      </Container>
      <Explore />
    </Wishlist>
  );
}

export default WishCarts;
