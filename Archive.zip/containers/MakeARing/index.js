import React, { useState, useContext, useEffect } from "react";
import { Container } from "reactstrap";
import APIUtil from "../../api";
import { useParams } from "react-router";
import { Authentication, UserDetails } from "../../constant";
import { CartContext } from "../../context/CartContext";
import ProgressStrip from "../../components/ProgressStrip";
import Help from "../../components/Help";
import ProductSlider from "../../components/ProductDetail/ProductSlider";
import BankWire from "../../components/ProductDetail/BankWire";

//css
import { ProductDetail } from "../../css/productDetail";
import { CustomButton } from "../../css/global";

//images
import { ReactComponent as Cart } from "../../assets/images/addcart.svg";
import { ReactComponent as Wishlist } from "../../assets/images/addwishlist.svg";
import { ReactComponent as EmailUs } from "../../assets/images/emailus.svg";
import { ReactComponent as HelpImg } from "../../assets/images/help.svg";
import LuxuryGift from "../../assets/images/detail/ring.png";
import { ReactComponent as Truck } from "../../assets/images/shippingTruck.svg";
import { ReactComponent as Diamond } from "../../assets/images/makearing/diamond.svg";
import { ReactComponent as Ring } from "../../assets/images/makearing/wedding-ring.svg";
import { ReactComponent as PreviewDummy } from "../../assets/images/looseDiamonds/diamond-preview-dummy.svg";

const api = new APIUtil();

const CompleteJewel = (props) => {
  const { id } = useParams();
  const isAuth = Authentication();
  const userId = UserDetails();
  const {
    addProduct,
    wishProduct,
    wishListId,
    wishListIdDel,
    cartListIdDel,
    cartListId,
  } = useContext(CartContext);

  const [load, setLoad] = useState(true);
  const [images, setImages] = useState([]);
  const [ringProduct, setRingProduct] = useState([]);
  const [diamondProduct, setDiamondProduct] = useState([]);

  //update total price
  useEffect(() => {
    api.get(`products/ringReview?id=${userId._id.toString()}`).then((res) => {
      const ringReviewData = res.data.data;
      ringReviewData?.map((item) => {
        if (item?.engagementRingId) {
          setRingProduct(item.engagementRingId);
          setImages(item?.engagementRingId?.productsPreviewImages);
        }
        if (item?.looseDiamondId) {
          setDiamondProduct(item.looseDiamondId);
        }
      });
    });
  }, []);

  // To check product is already in wishlist or not
  const isInWish = (id) => {
    if (isAuth) {
      if (wishListId.includes(id)) {
        return true;
      } else {
        return false;
      }
    }
  };

  // to check the product is already in cart or not
  const isInCart = (id) => {
    if (isAuth) {
      if (cartListId.includes(id)) {
        return true;
      } else {
        return false;
      }
    }
  };

  //Add multiple products for complete enagagement ring
  const addToCartMulti = async (ringId, diamondId) => {
    if (isAuth) {
      let totalPrice =
        +parseInt(ringProduct?.price?.$numberDecimal) +
        +parseInt(diamondProduct?.price?.$numberDecimal);
      let new_data = {
        looseDiamondId: diamondId,
        engagementRingId: ringId,
        userId: userId._id.toString(),
        quantity: 1,
        productCategory: 7,
        price: totalPrice,
      };
      await api.post("products/addCart", new_data).then((response) => {});
      props.history.push("/addtocart");
    }
  };

  // To Remove the product for cart
  const removeFromCart = async (ringId, diamondId) => {
    if (isAuth) {
      const del_data = {
        userId: userId._id.toString(),
        looseDiamondId: diamondId,
        engagementRingId: ringId,
        productCategory: 7,
      };
      await api.post("products/delCart", del_data).then((response) => {
        if (cartListId.includes(id)) {
          const filter = cartListId.filter(function (data) {
            return data !== id;
          });
          setLoad(!load);
          cartListIdDel(filter);
        }
      });
    }
  };

  // To remove the product from wishlist
  const wishListRemove = async (ringId, diamondId) => {
    if (isAuth) {
      const del_data = {
        userId: userId._id.toString(),
        looseDiamondId: diamondId,
        engagementRingId: ringId,
        productCategory: 7,
      };

      await api.post("products/delWishlist", del_data).then((response) => {
        if (wishListId.includes(id)) {
          const filter = wishListId.filter(function (data) {
            return data !== id;
          });
          setLoad(!load);
          wishListIdDel(filter);
        }
      });
    }
  };

  const toWishClick = async (ringId, diamondId) => {
    if (isAuth) {
      const body = [
        {
          userId: userId._id.toString(),
          looseDiamondId: diamondId,
          engagementRingId: ringId,
          productCategory: 7,
        },
      ];

      await api.post("products/addWishlist", body).then((response) => {});
      setLoad(!load);
    }
  };

  useEffect(() => {
    if (isAuth) {
      addProduct(userId._id.toString());
      wishProduct(userId._id.toString());
    }
  }, [load]);

  return (
    <ProductDetail looseDiamond make>
      <Container>
        <div className="product-card">
          <ProductSlider images={images} />
          <div className="product-details">
            <h2>
              Engagement Ring <span>(Completed)</span>
            </h2>
            <div className="selected-filter d-flex align-items-center justify-content-between">
              <div class="productDivs">
                <Ring width="24px" height="35px" />
                <div>
                  <h6 className="productTile">
                    {ringProduct?.name}-Carat {diamondProduct?.shapeCut} cut
                  </h6>
                  <h5>SUK {ringProduct?.suk}</h5>
                </div>
                <p className="productPrice">
                  ${ringProduct.price?.$numberDecimal}
                </p>
              </div>
            </div>
            <div className="selected-filter d-flex align-items-center justify-content-between">
              <div class="productDivs">
                <Diamond width="30px" height="30px" />
                <div>
                  <h6 className="productTile">
                    {diamondProduct?.caratWeight?.$numberDecimal}-Carat{" "}
                    {diamondProduct?.shapeCut} cut
                  </h6>
                  <h5>SUK {diamondProduct?.suk}</h5>
                </div>
                <p className="productPrice">
                  ${diamondProduct?.price?.$numberDecimal}
                </p>
              </div>
            </div>
            <div className="product-price">
              <h3 className="product-price-original">
                $
                {+diamondProduct?.price?.$numberDecimal +
                  +ringProduct?.price?.$numberDecimal}
              </h3>
              <h5>
                Bankwire -{" "}
                <BankWire
                  diamondProduct={diamondProduct}
                  ringProduct={ringProduct}
                />
              </h5>
              <h5>
                Welcome offer on first purchase, use <span>WELCOME21</span> code
              </h5>
            </div>
            <div className="d-flex justify-content-start btn-grp">
              {isInWish(diamondProduct?._id, ringProduct?._id) && (
                <CustomButton
                  dark
                  onClick={() =>
                    wishListRemove(diamondProduct?._id, ringProduct?._id)
                  }
                  className="customButton black"
                >
                  <Wishlist width="19px" height="19px" fill="#ff5000" />
                </CustomButton>
              )}

              {!isInWish(diamondProduct?._id, ringProduct?._id) && (
                <CustomButton
                  dark
                  onClick={() =>
                    toWishClick(diamondProduct?._id, ringProduct?._id)
                  }
                  className="customButton black"
                >
                  <Wishlist width="19px" height="19px" fill="#fff" />
                </CustomButton>
              )}

              {isInCart(diamondProduct?._id, ringProduct?._id) && (
                <CustomButton
                  dark
                  onClick={() =>
                    removeFromCart(diamondProduct?._id, ringProduct?._id)
                  }
                  className="customButton cart black"
                >
                  <Cart width="25px" height="21px" fill="#fff" /> Remove From
                  Cart
                </CustomButton>
              )}
              {!isInCart(diamondProduct?._id, ringProduct?._id) && (
                <>
                  <CustomButton
                    dark
                    className="customButton cart black"
                    onClick={() =>
                      addToCartMulti(ringProduct._id, diamondProduct?._id)
                    }
                  >
                    <Cart width="25px" height="21px" fill="#fff" /> Add to cart
                  </CustomButton>
                </>
              )}
            </div>
            <div className="shippingInfo position-relative d-flex align-items-center">
              <Truck width="57px" height="32px" />
              <p>Get Free ship by 21 Aug, If ordered Before 10:30 PM </p>
            </div>
            {/* <div className="helpUs">
              <ul className="list d-flex justify-content-start">
                <li>
                  <a href="mailto:info@radixdiamond.co">
                    <EmailUs width="20px" height="15px" />
                    <p> Email Us</p>
                  </a>
                </li>
                <li>
                  <a href="tel:+1-800-242-2728">
                    <h4>
                      <HelpImg width="19px" height="19px" /> Need Help ?
                    </h4>
                    <p>+1-800-242-2728</p>
                  </a>
                </li>
              </ul>
            </div> */}
          </div>
        </div>
        <div className="diamond-details-wrap ring">
          <h2>Product Details</h2>
          <h2>Diamond Details</h2>
          <h2>Ring Details</h2>
          <div className="d-flex w-100">
            <span className="diamond-skeleton">
              <PreviewDummy width="327px" height="299px" />
            </span>
            <ul className="list">
              <li>
                <label>Shape</label>
                <h4>{diamondProduct?.shapeCut}</h4>
              </li>
              <li>
                <label>Cut</label>
                <h4>{diamondProduct?.cutGrade}</h4>
              </li>
              <li>
                <label>Color</label>
                <h4>{diamondProduct?.colorGrade}</h4>
              </li>
              <li>
                <label>Clarity</label>
                <h4>{diamondProduct?.clarityGrade}</h4>
              </li>
              <li>
                <label>Carat Weight</label>
                <h4>{diamondProduct?.caratWeight?.$numberDecimal}</h4>
              </li>
              <li>
                <label>Depth</label>
                <h4>{diamondProduct?.totalDepth}</h4>
              </li>
              <li>
                <label>Table</label>
                <h4>{diamondProduct?.tableSize}</h4>
              </li>
              <li>
                <label>Polish</label>
                <h4>{diamondProduct?.polish}</h4>
              </li>
              <li>
                <label>Symmentry</label>
                <h4>{diamondProduct?.symmetry}</h4>
              </li>
              <li>
                <label>Girdle</label>
                <h4>{diamondProduct?.girdleThickness}</h4>
              </li>
              <li>
                <label>Culet</label>
                <h4>{diamondProduct?.culet}</h4>
              </li>
              <li>
                <label>Measurements</label>
                <h4>{diamondProduct?.measurements}</h4>
              </li>
              <li>
                <label>Stock Number</label>
                <h4>{diamondProduct?.suk}</h4>
              </li>
            </ul>
            <ul className="list">
              <li>
                <label>Stock Number</label>
                <h4>{ringProduct?.suk}</h4>
              </li>
              <li>
                <label>Collection</label>
                <h4>{ringProduct?.ringCategory}</h4>
              </li>
              <li>
                <label>Gemstone Shape</label>
                <h4>{ringProduct?.diamondShape}</h4>
              </li>
              <li>
                <label>Total Carat Weight</label>
                <h4>{ringProduct?.totalCaratWeightRing?.$numberDecimal}</h4>
              </li>
              <li>
                <label>Gemstone Type</label>
                <h4>Lab Created Diamond</h4>
              </li>
              <li>
                <label>Setting Type</label>
                <h4>{ringProduct?.settingType}</h4>
              </li>
              <li>
                <label>Ring Width</label>
                <h4>{ringProduct?.ringWidth}</h4>
              </li>
            </ul>
          </div>
        </div>
      </Container>
      <Help />
      <section className="feel-luxury">
        <Container>
          <div className="feel-luxury-inner">
            <div className="feel-luxury-caption">
              <h2>
                <span>F</span>eel Luxury
              </h2>
              <p>
                Radix Provides you a Real Luxury Experience For Special Family
                members just like you and makes Purchase for specials and more
                Royal{" "}
              </p>
            </div>

            <div className="feel-luxury-img">
              <img className="img-fluid" src={`${LuxuryGift}`} alt="" />
            </div>
          </div>
        </Container>
      </section>
    </ProductDetail>
  );
};

export default CompleteJewel;
