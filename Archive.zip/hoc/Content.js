import React, { Suspense, memo, useState, useEffect } from "react";
import { Redirect, Route, Switch } from "react-router-dom";
import Loader from "../common/Loader";
import routes from "../routes";

const loading = (
  <div className="pt-3 text-center">
    <div className="sk-spinner sk-spinner-pulse"></div>
  </div>
);

const Content = () => {
  const [loader, setLoader] = useState(false);

  useEffect(() => {
  }, [loader]);

  const allRouter = routes.map((route, i) => {
    return (
      route.component && (
        <Route
          key={i}
          path={route.path}
          exact={route.exact}
          name={route.name}
          render={(props) => {
            const crumbs = routes
              // Get all routes that contain the current one.
              .filter(({ path }) => props.match.path.includes(path))
              // Swap out any dynamic routes with their param values.
              // E.g. "/pizza/:pizzaId" will become "/pizza/1"
              .map(({ path, ...rest }) => ({
                path: Object.keys(props.match.params).length
                  ? Object.keys(props.match.params).reduce(
                      (path, param) =>
                        path.replace(`:${param}`, props.match.params[param]),
                      path
                    )
                  : path,
                ...rest,
              }));
            crumbs.map(({ name, path }) => console.log({ name, path }));
            return (
              <div>
                <route.component {...props} />{" "}
              </div>
            );
          }}
        />
      )
    );
  });
  return (
    <>
      <Suspense fallback={Loader}>
        <Switch>
          {loader ? <Loader /> : allRouter}
          <Redirect from="/" to="/" />
        </Switch>
      </Suspense>
    </>
  );
};

export default memo(Content);
