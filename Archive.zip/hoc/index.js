import React, { useContext, useEffect } from "react";
import Footer from "../common/Footer";
import Header from "../common/Header";
import Content from "./Content";
import { Authentication, UserDetails } from "../constant";
import { CartContext } from "../context/CartContext";

const Layout = () => {
  const isAuth = Authentication();
  const userId = UserDetails();

  const { addProduct, wishProduct } = useContext(CartContext);

  // useEffect(() => {
  //   if (isAuth && userId && userId._id) {
  //     addProduct(userId._id.toString());
  //     wishProduct(userId._id.toString());
  //   }
  // }, []);

  return (
    <>
      <div className="topbar text-center">
        <p>
          Welcome offer on first purchase .Use code WELCOME21 to avail grab this
          offer
        </p>
      </div>
      <Header />
      <Content />
      <Footer />
    </>
  );
};

export default Layout;
