export const StoneShape = [
  {
    value: "Round",
    label: "Round",
    shouldBeDisplayed: "false",
    key: "stoneshape",
  },
  {
    value: "Princess",
    label: "Princess",
    key: "stoneshape",
  },
  {
    value: "Emerald",
    label: "Emerald",
    key: "stoneshape",
  },
  {
    value: "Marquise",
    label: "Marquise",
    key: "stoneshape",
  },
  {
    value: "Pear",
    label: "Pear",
    key: "stoneshape",
  },
  {
    value: "Baguette",
    label: "Baguette",
    key: "stoneshape",
  },
];

export const EarringStyle = [
  { value: "Drop/Dangle", label: "Drop/Dangle", key: "earringstyle" },
  { value: "Halo", label: "Halo", key: "earringstyle" },
  { value: "Hoop", label: "Hoop", key: "earringstyle" },
  { value: "Knot", label: "Knot", key: "earringstyle" },
  { value: "Stud", label: "Stud", key: "earringstyle" },
];

export const HoopSizes = [
  {
    value: "Huggie Diamond Hoops",
    label: "Huggie Diamond Hoops",
    key: "hoopsizes",
  },
  { value: "Small Hoops", label: "Small Hoops", key: "hoopsizes" },
  {
    value: "Medium Diamond Hoops",
    label: "Medium Diamond Hoops",
    key: "hoopsizes",
  },
  {
    value: "Large Diamond Hoops",
    label: "Large Diamond Hoops",
    key: "hoopsizes",
  },
];

export const HoopProngs = [
  { value: "Standard Prongs", label: "Standard Prongs", key: "hoopprongs" },
  { value: "Shared Prongs", label: "Shared Prongs", key: "hoopprongs" },
  { value: "Channel Settings", label: "Channel Settings", key: "hoopprongs" },
  { value: "Pave Prongs", label: "Pave Prongs", key: "hoopprongs" },
  { value: "Bazel Settings", label: "Bazel Settings", key: "hoopprongs" },
];

export const BackType = [
  {
    value: "Screw On",
    label: "Screw On",
    key: "backtype",
  },
  {
    value: "Push Back",
    label: "Push Back",
    key: "backtype",
  },
  {
    value: "hinged snap back",
    label: "Hinged & Snap Back",
    key: "backtype",
  },
  {
    value: "Hinged & Lock",
    label: "Hinged & Lock",
    key: "backtype",
  },
  {
    value: "Hinged",
    label: "Hinged",
    key: "backtype",
  },
];
export const Designs = [
  {
    value: "Screw On",
    label: "Screw On",
    key: "backtype",
  },
  {
    value: "Push Back",
    label: "Push Back",
    key: "backtype",
  },
  {
    value: "hinged snap back",
    label: "Hinged & Snap Back",
    key: "backtype",
  },
  {
    value: "Hinged & Lock",
    label: "Hinged & Lock",
    key: "backtype",
  },
  {
    value: "Hinged",
    label: "Hinged",
    key: "backtype",
  },
];

export const ringShape = [
  {
    value: "3 Stone",
    label: "3 Stone",
    key: "ringShape",
  },
  {
    value: "Channel Set",
    label: "Channel Set",
    key: "ringShape",
  },
  {
    value: "Designer",
    label: "Designer",
    key: "ringShape",
  },
  {
    value: "Engravable",
    label: "Engravable",
    key: "ringShape",
  },
  {
    value: "Marquise",
    label: "Marquise",
    key: "ringShape",
  },
  {
    value: "Eternity",
    label: "Engravable",
    key: "ringShape",
  },
  {
    value: "Radiant",
    label: "Radiant",
    key: "ringShape",
  },
  {
    value: "Halo",
    label: "Halo",
    key: "ringShape",
  },
  {
    value: "Has matching Band",
    label: "Has matching Band",
    key: "ringShape",
  },
  {
    value: "Infinity",
    label: "Infinity",
    key: "ringShape",
  },
  {
    value: "Matching Cureved",
    label: "Matching Cureved",
    key: "ringShape",
  },
  {
    value: "Pave",
    label: "Pave",
    key: "ringShape",
  },
  {
    value: "Sidestone",
    label: "Sidestone",
    key: "ringShape",
  },
  {
    value: "Solitaire",
    label: "Solitaire",
    key: "ringShape",
  },
  {
    value: "Unique",
    label: "Unique",
    key: "ringShape",
  },
  {
    value: "Vintage",
    label: "Vintage",
    key: "ringShape",
  },
];

export const cut = [
  {
    value: "Ideal",
    label: "ideal",
  },
  {
    value: "Astor Ideal",
    label: "astorIdeal",
  },
  {
    value: "Good",
    label: "good",
  },
  {
    value: "Very Good",
    label: "veryGood",
  },
];

export const diamondShape = [
  {
    value: "Round",
    label: "round",
    src: "roundShape.svg",
    clicked: true,
  },
  {
    value: "Princess",
    label: "princess",
    src: "princessshape.svg",
    clicked: false,
  },
  {
    value: "Emerald",
    label: "emerald",
    src: "emeraldShape.svg",
    clicked: false,
  },
  {
    value: "Asscher",
    label: "asscher",
    src: "asscherShape.svg",
    clicked: false,
  },
  {
    value: "Cushion",
    label: "cushion",
    src: "cushionshape.svg",
    clicked: false,
  },
  {
    value: "Marquise",
    label: "marquise",
    src: "marquiseShape.svg",
    clicked: false,
  },
  {
    value: "Radiant",
    label: "radiant",
    src: "radiantShape.svg",
    clicked: false,
  },
  {
    value: "Oval",
    label: "oval",
    src: "ovalShape.svg",
    clicked: false,
  },
  {
    value: "Pear",
    label: "pear",
    src: "pearShape.svg",
    clicked: false,
  },
  {
    value: "Heart",
    label: "heart",
    src: "radiantShape.svg",
    clicked: false,
  },
];
