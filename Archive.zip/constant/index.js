import { useSelector } from "react-redux";

export const UserDetails = () => {
  const userId = useSelector((state) => state.auth.user);
  return userId;
};

export const Authentication = () => {
  const isAuth = useSelector((state) => state.auth.isAuthenticated);
  return isAuth;
};

export const Colors = [
  {
    color: "D-F",
    value: "D-F",
    name: "D-F",
    clicked: true,
  },
  {
    color: "G-H",
    value: "G-H",
    name: "G-H",
    clicked: false,
  },
  {
    color: "I-k",
    value: "I-K",
    name: "I-K",
    clicked: false,
  },
];

export const Clarities = [
  {
    clarity: "FL-IF",
    value: "FL-IF",
    name: "FL-IF",
    clicked: true,
  },
  {
    clarity: "VVS1-VVS2",
    value: "VVS1-VVS2",
    name: "VVS1-VVS2",
    clicked: false,
  },
  {
    clarity: "VS1-VS2",
    value: "VS1-VS2",
    name: "VS1-VS2",
    clicked: false,
  },
  {
    clarity: "SI1-SI3",
    value: "SI1-SI3",
    name: "SI1-SI3",
    clicked: false,
  },
];

export const metalColors = [
  {
    value: "Rose-14",
    id: "roseGold",
    className: "four",
    clicked: false,
  },
  {
    value: "White-14",
    id: "whiteGold",
    className: "four",
    clicked: false,
  },
  {
    value: "Yellow-14",
    id: "yellowGold",
    className: "four",
    clicked: false,
  },
  {
    value: "Rose-18",
    id: "roseGold",
    className: "eight",
    clicked: false,
  },
  {
    value: "White-18",
    id: "whiteGold",
    className: "eight",
    clicked: false,
  },
  {
    value: "Yellow-18",
    id: "yellowGold",
    className: "eight",
    clicked: false,
  },
  { value: "Platinum-0", className: "pt", id: "platinum", clicked: false },
];

export const caratWeights = [
  {
    value: "0.25",
    text: "0.25",
    clicked: false,
  },

  {
    value: "0.5",
    text: "0.5",
    clicked: false,
  },
  // {
  //   value: "0.75",
  //   text: "0.75",
  //   clicked: false,
  // },
  {
    value: "1",
    text: "1",
    clicked: false,
  },
  {
    value: "1.5",
    text: "1.5",
    clicked: false,
  },
  {
    value: "2",
    text: "2",
    clicked: false,
  },
  {
    value: "2.5",
    text: "2.5",
    clicked: false,
  },
  {
    value: "3",
    text: "3",
    clicked: false,
  },
  {
    value: "3.5",
    text: "3.5",
    clicked: false,
  },
  {
    value: "4",
    text: "4",
    clicked: false,
  },
];
