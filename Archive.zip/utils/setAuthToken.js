import axios from "axios";
import config from "../config";
import History from "../store/helpers/history";
import { logout } from "../store/actions/authActions";

const setAuthToken = (store) => {
  axios.interceptors.request.use(
    function (config) {
      if (config.config.parse) {
        // adding token to the authorization header only
        const token = localStorage.getItem("token");
        if (token) {
          config.headers = {
            authorization: `Bearer ${token}`,
          };
        }
        return config;
      }
    },
    function (error) {
      // Do something with request error
      return Promise.reject(error);
    }
  );

  // Add a response interceptor
  axios.interceptors.response.use(
    function (response) {
      if (response.config.parse) {
        // Do something with response data
        return response;
      }
    },
    function (error) {
      // Do something with response error

      if (error.response && parseInt(error.response.status, 10) === 401) {
        // store.dispatch(unauthenticate());
        if (
          error.response.config.url === `${config.config().baseUrl}/auth/login`
        ) {
          return Promise.reject(error);
        }

        // redirect('/logout');
        store.dispatch(logout());
        History.push("/login");
        throw error;
      }
    }
  );
};

export default setAuthToken;
