import { lazy } from "react";
import Loadable from "react-loadable";
import Loader from "./common/Loader";
import UsersOrder from "./components/Account/Orders";

const Home = lazy(() => import("./containers/Home"));

const Login = lazy(() => import("./containers/Auth"));
const ResetPassword = lazy(() => import("./containers/Auth/ResetPassword"));
const Register = lazy(() => import("./containers/Auth/Register"));
const BillingAndShipping = lazy(() =>
  import("./containers/BillingAndShipping")
);
const Payment = lazy(() => import("./containers/Payment"));
const AddToCart = lazy(() => import("./containers/AddToCart"));
const Wishlist = lazy(() => import("./containers/WishCart"));
const PaymentSuccess = lazy(() =>
  import("./containers/Payment/PaymentSuccess")
);
const UserAccount = lazy(() => import("./containers/UserAccount"));
const MyOrders = lazy(() => import("./containers/UserOrders"));

// Studs
const Earring = Loadable({
  loader: () => import("./containers/Earrings/Studs/Landing"),
  loading: Loader,
});
const ProductDetail = lazy(() => import("./containers/ProductDetail"));

// hoops
const HoopsLanding = lazy(() => import("./containers/Earrings/Hoops/Landing"));
const HoopsListing = lazy(() => import("./containers/Earrings/Hoops/Listing"));
const HoopsProduct = lazy(() =>
  import("./containers/Earrings/Hoops/ProductCategory")
);

// drops
const DropsListing = lazy(() => import("./containers/Earrings/Drops/Listing"));
const DropsProduct = lazy(() =>
  import("./containers/Earrings/Drops/ProductCategory")
);

// fashion earrings
const FashionListing = lazy(() =>
  import("./containers/Earrings/Fashion/Listing")
);
const FashionProduct = lazy(() =>
  import("./containers/Earrings/Fashion/ProductCategory")
);

// Loose Diamonds
const DiamondLoose = lazy(() => import("./containers/LooseDiamond/Landing"));
const DiamondLooseList = lazy(() =>
  import("./containers/LooseDiamond/Listing")
);
const DiamondDetails = lazy(() =>
  import("./containers/LooseDiamond/ProductDetail")
);

// Ring
const EngagementRingLanding = lazy(() =>
  import("./containers/EngagementRing/Landing")
);
const EngagementRingListing = lazy(() =>
  import("./containers/EngagementRing/Listing")
);

const EngagementDetails = lazy(() =>
  import("./containers/EngagementRing/ProductDetail")
);

const CompleteJewel = lazy(() => import("./containers/MakeARing"));

const routes = [
  { path: "/", exact: true, component: Home },

  { path: "/addtocart", exact: true, component: AddToCart },
  { path: "/wishcart", exact: true, component: Wishlist },
  { path: "/register", exact: true, component: Register },
  { path: "/login", exact: true, component: Login },

  { path: "/paysuccess", exact: true, component: PaymentSuccess },
  { path: "/payment", exact: true, component: Payment },

  {
    path: "/resetpassword/:userId",
    exact: true,
    component: ResetPassword,
  },
  { path: "/shipping", exact: true, component: BillingAndShipping },

  // ****** Earrings ******

  // Studs
  { path: "/earring", exact: true, component: Earring },
  {
    path: "/productDetail/:id/:metalWeight/:metal/:secondId",
    exact: true,
    component: ProductDetail,
  },
  // hoops
  { path: "/hoops", name: "Hoops", exact: true, component: HoopsLanding },
  {
    path: "/hoops/listing",
    name: "Hoops",
    exact: true,
    component: HoopsListing,
  },
  {
    path: "/productDetail/:id/:metalWeight/:metal",
    exact: true,
    component: HoopsProduct,
  },

  // drops
  {
    path: "/drops/listing",
    name: "Drops",
    exact: true,
    component: DropsListing,
  },
  {
    path: "/dropsDetail/:id/:metalWeight/:metal",
    exact: true,
    component: DropsProduct,
  },

  // fashion
  {
    path: "/fashion/listing",
    name: "Fashion",
    exact: true,
    component: FashionListing,
  },
  {
    path: "/fashionDetail/:id/:metalWeight/:metal",
    exact: true,
    component: FashionProduct,
  },
  // ****** Earrings ******

  // Diamond Loose
  {
    path: "/diamonds",
    name: "Diamonds",
    exact: true,
    component: DiamondLoose,
  },
  {
    path: "/diamond-search",
    exact: true,
    component: DiamondLooseList,
  },
  {
    path: "/diamond-details/:id",
    exact: true,
    component: DiamondDetails,
  },

  // ring
  { path: "/engagement-rings", exact: true, component: EngagementRingLanding },
  {
    path: "/build-your-own-ring/settings",
    exact: true,
    component: EngagementRingListing,
  },
  {
    path: "/engagement-rings-details/:id/:carat/:color",
    exact: true,
    component: EngagementDetails,
  },

  {
    path: "/complete-jewel/:id",
    exact: true,
    component: CompleteJewel,
  },

  { path: "/account", exact: true, component: UserAccount },

  { path: "/orders", exact: true, component: MyOrders },
];

export default routes;
